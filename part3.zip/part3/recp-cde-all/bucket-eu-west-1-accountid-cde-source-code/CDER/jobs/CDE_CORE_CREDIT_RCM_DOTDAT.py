import sys
import os
from config import setup_module_config_path
from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import *
import job_option_config
from job_option_config import *
import cde99_x_batchdt_mac
import pandas as pd
from logger import create_logger, xdpLogger
from datetime import datetime
import time
import update_running_status
import configfile
import Upload_Ouput_s3


def main():
    spark = SparkSession \
    .builder \
     .appName("CDE_CORE_CREDIT_RCM_DOTDAT") \
     .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
     .config('hive.exec.dynamic.partition', 'true') \
     .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
     .config('hive.exec.max.dynamic.partitions','20000') \
     .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
     .config('fs.s3.maxRetries', '20') \
     .enableHiveSupport() \
     .getOrCreate()


    spark.sparkContext.setLogLevel("ERROR")
    create_logger('CDE_CORE_CREDIT_RCM_DOTDAT')
    xdpLogger('xDP-INF-013',comment="Job has started")
###   /****************************************************************************
###   * Job:             CDE_CORE_CREDIT_RCM_DOTDAT                               *
###   * Description:     This job generate header, data and trailer which then    * 
###                      merged to generate dotdat file which is consumed by Core *
###                      Credit team                                              *
###   * Version          1. 04-02-2021 - Rahul Ranjan/ranjarz                     *
###   ****************************************************************************/

    SYSPARM = sys.argv[1]
    job_name = sys.argv[2]
    flow_name = sys.argv[3]    
    table_name = sys.argv[4].upper()

    path = setup_module_config_path.path   #Used this variable to call fixed width length csv file
 
    ts_start = pd.Timestamp('today')
    #Update start time
    try:
        update_running_status.update_start_time(spark,job_name,flow_name,ts_start)
    except Exception as e:
        xdpLogger('xDP-WAR-005',comment=e)
    
    job_option_config.read_job_config(SYSPARM)
    S3_OUT = job_option_config.CDE_DATAIN_BUCKET
    

    tddb_inst = job_option_config.TDDB_INST # TDDB_INST and INST are same in ourcase

    cde99_x_batchdt_mac.get_date_config(tddb_inst,SYSPARM,spark)
    curr_day=ts_start.strftime('%Y%m%d')  

    # Getting file name of corresponding table from config file  

    FILENAME = configfile.CDE_FILENAME["{TABLE_NAME}".format(TABLE_NAME=table_name)] 
    header_filler = configfile.HEADER_FILLER["{TABLE_NAME}".format(TABLE_NAME=table_name)]
    trailer_filler = configfile.TRAILER_FILLER["{TABLE_NAME}".format(TABLE_NAME=table_name)]
    ### /*Create the S3 CSV file for Output Mapper Including Header,Data and Tailer*/

    header_key='data-in/cde/output_intermediate/{sysparm}_{TABLE_NAME}/header/'.format(sysparm=SYSPARM,TABLE_NAME=table_name)
    data_key='data-in/cde/output_intermediate/{sysparm}_{TABLE_NAME}/data/'.format(sysparm=SYSPARM,TABLE_NAME=table_name)
    tailer_key='data-in/cde/output_intermediate/{sysparm}_{TABLE_NAME}/trailer/'.format(sysparm=SYSPARM,TABLE_NAME=table_name)
    
    #Creation fo Header and write it to s3 bucket
    
    query1 = "select count(*) from {TDDB_INST}.{TABLE_NAME}".format(TDDB_INST=tddb_inst,TABLE_NAME=table_name)
    try:
        total_count = spark.sql(query1).collect()[0][0]
        total_count = str(total_count).rjust(8,'0')
        print("total-count",total_count)

    except Exception as e:         
        print("Exception while taking count of table {TDDB_INST}.{TABLE_NAME}".format(TDDB_INST=tddb_inst,TABLE_NAME=table_name))
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-111',comment=e)
        sys.exit(1) 

    query2="select concat('HEADER','{}','{}','{}')".format(FILENAME,curr_day,header_filler)
    
    try:    
        df_header = spark.sql(query2)
        df_header.show() 
        df_header.coalesce(1).write.mode('overwrite').option("ignoreLeadingWhiteSpace","false").option("ignoreTrailingWhiteSpace","false").csv("s3://{s3_out}/{s3_key}".format(s3_out=S3_OUT,s3_key=header_key))  
        print("Header successfully created on S3")
    except Exception as e:         
        print("Header creation on s3 failed")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-111',comment=e)
        sys.exit(1)        

    
    #Creation fo Trailer and write it to s3 bucket
    
    query3="select concat('TRAILER','{}','{}')".format(total_count,trailer_filler)
    try:
        df_trailer = spark.sql(query3)
        df_trailer.show()
        df_trailer.coalesce(1).write.mode('overwrite').option("ignoreLeadingWhiteSpace","false").option("ignoreTrailingWhiteSpace","false").csv("s3://{s3_out}/{s3_key}".format(s3_out=S3_OUT,s3_key=tailer_key))
        print("Trailer successfully created on S3")
    except Exception as e:         
        print("Trailer creation on s3 failed")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-111',comment=e)
        sys.exit(1)        
    
    # Copy Fixed width Lenght file to HDFS
    
    try:
        mkdir_fwl = "hdfs dfs -mkdir /user/hadoop/fwl/"
        os.system(mkdir_fwl)
        copy_fwl = "hdfs dfs -put -f {PATH}/module-udf/fixed_width_length.csv /user/hadoop/fwl/".format(PATH=path)
        list_hdfs_file = """hdfs dfs -ls /user/hadoop/fwl/fixed_width_length.csv | awk '{FILTER}' | grep {FILTER_COND}""".format(FILTER='{print $8}',FILTER_COND='fixed_width_length.csv')
        hdfs_file_list=sorted(os.popen(list_hdfs_file).read().strip().split('\n'))[-1].split('/')[-1]
        if hdfs_file_list.lower()=='fixed_width_length.csv'.lower():
            print("Fixed width configuration file available on hdfs")
        else:
            os.system(copy_fwl)
            print("Fixed width Lenght file copied to HDFS location:/user/hadoop/fwl/")
    except Exception as e:         
        print("Failed to copy Fixed width Lenght file to HDFS location:/user/hadoop/fwl/")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-111',comment=e)
        sys.exit(1)

    #Creation of Data with fixed width length and write it to s3 bucket

    try:  
        FIXED_WIDTH_ATTRIBUE=spark.read.csv('/user/hadoop/fwl/fixed_width_length.csv',header=True)
        FIXED_WIDTH_ATTRIBUE.createOrReplaceTempView('FIXED_WIDTH_ATTRIBUE')
    except Exception as e:         
        print("FIXED_WIDTH_ATTRIBUE temp table creation failed")
        print("EXCEPTION :",str(e))
        sys.exit(1)              

    #Selecting columnname & fixedwidthlength of respective table

    try:
        df_column=spark.sql("""Select columnname,fixedwidthlength, datatype, paddingtype, paddingvalue, dateformat , decimalpoint from FIXED_WIDTH_ATTRIBUE where Tablename = '{tbl}'""".format(tbl=table_name))
        print("Dataframe having columnname & fixedwidthlength of table {TDDB_INST}.{TABLE_NAME} created".format(TDDB_INST=tddb_inst,TABLE_NAME=table_name))
    except Exception as e:         
        print("Dataframe having columnname & fixedwidthlength creation failed")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-111',comment=e)
        sys.exit(1) 

    # Creation of list
    colname = df_column.select('columnname').rdd.map(lambda row : row[0]).collect()      
    fwl = df_column.select('fixedwidthlength').rdd.map(lambda row : row[0]).collect()   
    padtyp = df_column.select('paddingtype').rdd.map(lambda row : row[0]).collect()     
    padval = df_column.select('paddingvalue').rdd.map(lambda row : row[0]).collect() 
    padval_new = []
    for i in padval:
        if i == None:
            i = ''
            padval_new.append(i)
        else:
            padval_new.append(i)
    
    
    datefor = df_column.select('dateformat').rdd.map(lambda row : row[0]).collect()
    datefor_new = []
    for i in datefor:
        if i == None:
            i = ''
            datefor_new.append(i)
        else:
            datefor_new.append(i)
    
    decipnt = df_column.select('decimalpoint').rdd.map(lambda row : row[0]).collect()
    decipnt_new = []
    for i in decipnt:
        if i == None:
            i = ''
            decipnt_new.append(i)
        else:
            decipnt_new.append(i)    

    dtype = df_column.select('datatype').rdd.map(lambda row : row[0]).collect()
    dtype_new = []
    for i in dtype:
        if i.strip() == 'signedint':
            dtype_new.append(i)
        else:
            i=''
            dtype_new.append(i)    

    # Creation of columns with RPAD clause 

    emp_list = []
    i = 0
    
    for col in colname:
        if datefor_new[i] != '':
            val = """UPPER(CAST(from_unixtime (UNIX_TIMESTAMP({C},'yyyy-MM-dd'), '{datefor}') AS String)) as {C}""".format(C=col,datefor=datefor_new[i])
            #val = """CASE WHEN LENGTH({C}) = 7 then UPPER({C}) ELSE UPPER(CAST(DATE_FORMAT({C},"{datefor}") AS string)) end as {C}""".format(C=col,datefor=datefor_new[i],L=fwl[i])
            emp_list.append(val) 

        elif decipnt_new[i] != '':
            val = """CAST(CAST ({C} as decimal ({L},{dp})) AS string) as {C}""".format(C=col,L=fwl[i],dp=decipnt_new[i])
            emp_list.append(val)

        elif dtype_new[i] != '':
            val = """CAST(CASE WHEN {C} <= 0 THEN {C} ELSE CONCAT('+',{C}) END AS string) as {C}""".format(C=col)
            emp_list.append(val)

        else:
            val = """CAST({C} AS string)  as {C}""".format(C=col)
            emp_list.append(val)
        i = i + 1               


        '''

        if padval_new[i] != '':
            val = """CAST({pt}({C},{L},'{Z}') AS string) as {C}""".format(pt=padtyp[i],C=col,L=fwl[i],Z=padval_new[i])
            emp_list.append(val)
        
        elif datefor_new[i] != '':
            #val = """{pt}(DATE_FORMAT({C},"{datefor}"),{L},' ')""".format(pt=padtyp[i],C=col,datefor=datefor_new[i],L=fwl[i])
            val = """CAST(DATE_FORMAT({C},"{datefor}") AS string) as {C}""".format(C=col,datefor=datefor_new[i],L=fwl[i])
            emp_list.append(val)
        
        elif decipnt_new[i] != '':
            val = """CAST({pt}(CAST ({C} as decimal ({L},{dp})),{L},' ') AS string) as {C}""".format(pt=padtyp[i],C=col,L=fwl[i],dp=decipnt_new[i])
            emp_list.append(val)
            
        else:
            val = """CAST({pt}({C},{L},' ') AS string)  as {C}""".format(pt=padtyp[i],C=col,L=fwl[i])
            emp_list.append(val)
        i = i + 1

        '''
    
    join_col = ','.join(emp_list)
    

    # Creation of view for table 
     
    try:
        df_data=spark.sql("""select {JOIN_COL} from {TDDB_INST}.{TABLE_NAME}""".format(JOIN_COL=join_col,TDDB_INST=tddb_inst,TABLE_NAME=table_name))
        #Removing all NULL values 
        df_data1=df_data.na.fill('')    
        df_data1.cache()             
        df_data1.createOrReplaceTempView("{TABLE_NAME}_view".format(TABLE_NAME=table_name))
        #df_data1.show(1,truncate=False)
        print("View {TABLE_NAME}_view is successfully created with formatted column and datatype as string".format(TABLE_NAME=table_name))
    except Exception as e:
        print("View Creation of table {TABLE_NAME} failed ".format(TABLE_NAME=table_name))
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-111',comment=e)
        sys.exit(1)
       
    # Selecting columns from above view and providing Order By Clause
    
    pad_emp_list = []
    j=0
    for col in colname:
        if padval_new[j] != '':
            val = """{pt}({C},{L},'{Z}')""".format(pt=padtyp[j],C=col,L=fwl[j],Z=padval_new[j])
            pad_emp_list.append(val)
        else:
            val = """{pt}({C},{L}," ")""".format(pt=padtyp[j],C=col,L=fwl[j])
            pad_emp_list.append(val)
        j=j+1

    join_pad_col = ','.join(pad_emp_list)

    #print("join_pad_col",join_pad_col) 

    order_by = configfile.COLUMN_ORDER_BY["{TABLE_NAME}".format(TABLE_NAME=table_name)]   

    try:
        df_data_concat=spark.sql("""select CONCAT({JOIN_PAD_COL}) from {TABLE_NAME}_view order by {ORDER_BY} """.format(JOIN_PAD_COL=join_pad_col,TABLE_NAME=table_name,ORDER_BY=order_by))
        #df_data_concat.show(1,truncate=False)
        print("DataFrame with concatenation of columns created & is ready to write on S3")
    except Exception as e:         
        print("Failed to create DataFrame with concatenation of columns")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-111',comment=e)
        sys.exit(1) 

    # Saving the final data to s3 bucket

    try:
        df_data_concat.coalesce(1).write.mode('overwrite').option("ignoreLeadingWhiteSpace","false").option("ignoreTrailingWhiteSpace","false").option("quote", "").option("delimiter", "\001").csv("s3://{s3_out}/{s3_key}".format(s3_out=S3_OUT,s3_key=data_key))             
        print("Data is successfully written on S3")
    except Exception as e:         
        print("Data failed to write on s3")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-111',comment=e)
        sys.exit(1)         

    # Mergering header,data & trailer & uploading the final file to s3
    
    try:
        Upload_Ouput_s3.Merge_Upload_File_s3(flow_name,table_name,SYSPARM,spark)
        print("The file .dat has successfully generated")
    except Exception as e:
        print("Failed to create final .dat file on S3")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-111',comment=e)
        sys.exit(1)

    try:
        update_running_status.update_end_time(spark,job_name,flow_name,ts_start)
    except Exception as e:
        xdpLogger('xDP-WAR-005',comment=e)

    spark.stop()


if __name__ == "__main__":
    """ Description: This is the entry point for execution of this script.
        The steps in sequence define the logical flow of the code
    """
    main()    

