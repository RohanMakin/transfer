from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as f
import sys
import os
import subprocess
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import create_logger, xdpLogger, get_logger
from datetime import datetime, date
import get_latest_partition_coldata


def main():
    spark = SparkSession \
    .builder \
    .appName("CDE01_M_G_EXP_PROCESS_LOAD") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate() 

    spark.sparkContext.setLogLevel("ERROR")
    conflist = spark.sparkContext.getConf().getAll()
    for i in conflist:
        if 'spark.app.id' in i[0]:
            application_id = i[1]


    ###   /***********************************************************************************
    ###   * Job:             CDE01_M_G_EXP_PROCESS_LOAD                                      *
    ###   * Description:     READING EXPERIAN DATA FROM CDL_EXPERIAN TABLE, ADDING           *
    ###   *                  DERIVED COLUMNS AND INSERTING RECORDS IN CDE_PROCESS TABLE      *
    ###   * Created by:      Rohan Makin (makinr)                                            *
    ###   ***********************************************************************************/

    '''
    Reading required parameters passed as arguments
    '''

    SYSPARM = sys.argv[1].upper()
    JOB_NAME = sys.argv[2].upper() 
    FLOW_NAME = sys.argv[3].upper()
    CDE_CONTROL=job_option_config.cde_databases["CONTROL"]
    CDE_PROCESS=job_option_config.cde_databases["CDE_PROCESS"]
    CDL_EXPERIAN=job_option_config.cde_databases["CDL_EXPERIAN"]


    create_logger('CDE01_M_G_EXP_PROCESS_LOAD')


    try:
        PARTITION_COLDATA1=get_latest_partition_coldata.get_latest_partition(CDL_EXPERIAN,'DCM_BATCH_M',spark)


    except Exception as e:
        print("Exception while fetching the partition column data ")
        print(str(e))    
        xdpLogger('xDP-ERR-111',comment=e)    
        sys.exit(1)


    '''
    Extracting batch information from cde source batch id control table.
    '''

    query1="""
                SELECT
                    BATCH_DATE,
                    CASE 
                        WHEN 'RBS'=='{sysparm}' THEN RBS_BATCH_ID
                        WHEN 'NWB'=='{sysparm}' THEN NWB_BATCH_ID
                        WHEN 'UBN'=='{sysparm}' THEN UBN_BATCH_ID
                        WHEN 'UBS'=='{sysparm}' THEN UBR_BATCH_ID
                        ELSE GRP_BATCH_ID
                        END AS BATCH_ID
                FROM
                    {cde_control}.SOURCING_BATCH_ID_CONTROL_TABLE
                """.format(cde_control=CDE_CONTROL,sysparm=SYSPARM)


    try:
            batch_info=spark.sql(query1).collect()
            BATCH_DATE = batch_info[0][0]
            BATCH_ID = batch_info[0][1]


    except Exception as e:
            print("Exception while extracting batch information from control table cde_control.SOURCING_BATCH_ID_CONTROL_TABLE")
            print("EXCEPTION :",str(e))
            xdpLogger('xDP-ERR-117',comment=e)            
            sys.exit(1)


    '''
    Adding derived columns 
    '''

    DERIVED_FIELDS='EFFECTIVE_START_DT|EFFECTIVE_END_DT|LAST_UPDATED_DT|LAST_UPDATED_TM|LOADED_BATCH_ID'
    DERIVED_COLUMNS=DERIVED_FIELDS.split('|')
    SQL_STR=''
    for col in DERIVED_COLUMNS:
            if col.upper()=="EFFECTIVE_START_DT":
                SQL_STR+="from_unixtime(UNIX_TIMESTAMP('{batch_date}','yyyy-MM-dd'),'yyyy-MM-01') AS {COL},".format(batch_date=BATCH_DATE,COL=col)        
            elif col.upper()=="EFFECTIVE_END_DT":
                SQL_STR+="LAST_DAY('{batch_date}') AS {COL},".format(batch_date=BATCH_DATE,COL=col)    
            elif col.upper()=="LAST_UPDATED_DT":
                SQL_STR+="CURRENT_DATE() AS {COL},".format(COL=col)        
            elif col.upper()=="LAST_UPDATED_TM":
                SQL_STR+="SUBSTR(NOW(),12,8) AS {COL},".format(COL=col)    
            elif col.upper()=="LOADED_BATCH_ID":
                SQL_STR+="{batch_id}".format(batch_id=BATCH_ID,COL=col) 
            elif col.upper()=="UPDATED_BATCH_ID":
                SQL_STR+=",NULL".format(COL=col) 
    xdpLogger('xDP-INF-025',comment="Derived column string : {sql_str}".format(sql_str=SQL_STR))    


    '''
    Insert overwriting current month data into final table
    '''

    query2="""
            INSERT OVERWRITE TABLE {cde_process}.PGFM_NEXPRIAN_RISK_DCM_BR_V11
            SELECT
                source_of_data,
                REPLACE(account_number,'TSS','') AS prty_idntfctn_num,
                CASE WHEN account_number RLIKE 'TSS' THEN 4085 ELSE 4083 END AS prty_idntfctn_type_cd,
                CASE WHEN account_number RLIKE 'TSS' THEN 'TSYS' ELSE 'CustDB' END AS source_system,
                customer_reference,
                rmc,
                title AS person_title,
                forenames,
                other_initials,
                surname,
                flat_number,
                house_name,
                house_number,
                street_name,
                district,
                postcode,
                date_of_score,
                score_id_1,
                score_1,
                risk_code_1,
                sub_population_indicator_1,
                score_id_2,
                score_2,
                risk_code_2,
                sub_population_indicator_2,
                score_id_3,
                score_3,
                risk_code_3,
                e1_a_01_sp,
                e1_a_02_sp,
                e1_a_03_sp,
                e1_a_04_sp,
                e1_a_05_sp,
                e1_a_06_sp,
                e1_a_08_sp,
                e1_a_09_sp,
                e1_a_10_sp,
                e1_a_11_sp,
                e1_b_01_sp,
                e1_b_02_sp,
                e1_b_03_sp,
                e1_b_04_sp,
                e1_b_05_sp,
                e1_b_06_sp,
                e1_b_07_sp,
                e1_b_08_sp,
                e1_b_09_sp,
                e1_b_10_sp,
                e1_b_11_sp,
                e1_b_12_sp,
                e1_b_13_sp,
                e1_c_01_sp,
                e1_c_02_sp,
                e1_c_03_sp,
                e1_c_04_sp,
                e1_c_05_sp,
                e1_c_06_sp,
                e1_d_01_sp,
                e1_d_03_sp,
                e1_d_04_sp,
                e1_e_01_sp,
                e1_e_02_sp,
                e2_g_01_spa,
                e2_g_02_spa,
                e2_g_03_spa,
                e2_g_04_spa,
                e2_g_05_spa,
                e2_g_06_spa,
                e2_g_08_spa,
                e2_g_09_spa,
                e2_g_10_spa,
                e2_g_11_spa,
                e2_h_01_spa,
                e2_h_02_spa,
                e2_h_03_spa,
                e2_h_04_spa,
                e2_h_05_spa,
                e2_h_06_spa,
                e2_h_07_spa,
                e2_h_08_spa,
                e2_h_09_spa,
                e2_h_10_spa,
                e2_h_11_spa,
                e2_h_12_spa,
                e2_h_13_spa,
                e2_i_01_spa,
                e2_i_02_spa,
                e2_i_03_spa,
                e2_i_04_spa,
                e2_i_05_spa,
                e2_i_06_spa,
                e2_j_01_spa,
                e2_j_03_spa,
                e2_j_04_spa,
                e2_k_01_spa,
                e2_k_02_spa,
                nd_g_02_n_a,
                nd_g_03_n_a,
                nd_g_04_n_a,
                nd_g_05_n_a,
                nd_g_06_n_a,
                nd_g_07_n_a,
                nd_g_08_n_a,
                nd_g_09_n_a,
                nd_g_10_n_a,
                nd_g_11_n_a,
                nd_g_12_n_a,
                e4_q_04_sp,
                nd_si24_n_a,
                e5_s_04_4_n_a,
                e5_s_05_4_all,
                e4_q_17_sp,
                e4_q_18_sp,
                e4_r_02_sp,
                ea1_a_01_sp,
                nd_ecc_01_sp,
                nd_ecc_02_sp,
                nd_ecc_03_sp,
                ea1_b_01_sp,
                ea1_b_02_sp,
                nd_ecc_04_sp,
                nd_hac_01_sp,
                nd_hac_02_sp,
                nd_hac_03_sp,
                nd_hac_04_sp,
                nd_hac_05_sp,
                nd_inc_01_sp,
                ea1_c_01_sp,
                nd_psd_01_sp,
                nd_psd_02_sp,
                nd_psd_03_sp,
                nd_psd_04_sp,
                nd_psd_05_sp,
                nd_psd_06_sp,
                ea1_d_01_sp,
                ea1_d_02_sp,
                ea1_d_03_sp,
                nd_erl_01_sp,
                ea1_e_01_sp,
                ea1_e_02_sp,
                ea1_e_03_sp,
                ea1_e_04_sp,
                nd_pa_pa,
                ea1_f_01_sp,
                ea1_f_02_sp,
                ea1_f_03_sp,
                ea1_f_04_sp,
                ea4_q_07_all,
                ea4_q_08_all,
                sp_br_present_sp,
                spa_br_present_spa,
                ea2_g_01_spa,
                nd_psd_07_spa,
                nd_psd_08_spa,
                nd_psd_09_spa,
                nd_psd_10_spa,
                ea4_q_09_all,
                ea2_h_01_spa,
                ea2_h_02_spa,
                nd_ecc_07_sp,
                nd_ecc_08_sp,
                nd_erl_02_sp,
                nd_ecc_09_spa,
                nd_ecc_10_spa,
                ea2_i_01_spa,
                nd_si21_n_a,
                ea2_j_01_spa,
                ea2_j_02_spa,
                ea2_j_03_spa,
                nd_hac_09_sp,
                ea2_k_01_spa,
                ea2_k_02_spa,
                ea2_k_03_spa,
                ea2_k_04_spa,
                nd_hac_10_spa,
                ea2_l_01_spa,
                ea2_l_02_spa,
                ea2_l_03_spa,
                ea2_l_04_spa,
                nd_ecc_05_spa,
                nd_hac_06_spa,
                nd_hac_07_spa,
                nd_hac_08_spa,
                nd_inc_02_spa,
                nd_si22_n_a,
                nd_dob_sp,
                nd_ecc_06_all,
                nd_inc_03_all,
                nd_psd_11_all,
                nd_g_01_n_a,
                nd_sp_ccl_sp,
                nd_sp_cii_sp,
                nd_spa_cii_spa,
                ea4_p_01_all,
                ea4_q_02_all,
                ea4_q_03_all,
                ea4_q_04_all,
                ea4_q_05_all,
                ea4_q_06_all,
                nd_sp_ocue_sp,
                ea4_s_03_sp,
                ea4_s_04_sp,
                ea4_s_05_sp,
                ea4_s_06_sp,
                ea4_s_07_sp,
                ea4_s_08_sp,
                ea5_s_01_sp,
                e5_s_01_all,
                e5_s_02_all,
                e5_s_04_1_n_a,
                e5_s_05_1_all,
                e5_s_04_2_n_a,
                e5_s_05_2_all,
                forward_address_link_flag,
                main_ich,
                main_sec_arr,
                main_unsec_arr,
                main_ccj,
                main_iva,
                main_bankrupt,
                sp_a_01,
                sp_a_02,
                sp_a_03,
                sp_a_04,
                sp_a_05,
                sp_a_06,
                sp_a_07,
                sp_a_08,
                sp_a_09,
                sp_a_10,
                sp_b1_11,
                sp_b1_12,
                sp_b1_13,
                sp_b1_14,
                sp_b1_15,
                sp_b1_16,
                sp_b1_17,
                sp_b2_18,
                sp_b2_19,
                sp_b2_20,
                sp_b2_21,
                sp_b3_22,
                sp_b3_23,
                sp_c_24,
                sp_e1_26,
                sp_e1_27,
                sp_e1_28,
                sp_f1_29,
                sp_f1_30,
                sp_f1_31,
                sp_f2_32,
                sp_f2_33,
                sp_f3_34,
                sp_f3_35,
                sp_f3_36,
                sp_g_37,
                sp_g_38,
                spa_a_01,
                spa_a_02,
                spa_a_03,
                spa_a_04,
                spa_a_05,
                spa_a_06,
                spa_a_07,
                spa_a_08,
                spa_a_09,
                spa_a_10,
                spa_b1_11,
                spa_b1_12,
                spa_b1_13,
                spa_b1_14,
                spa_b1_15,
                spa_b1_16,
                spa_b1_17,
                spa_b2_18,
                spa_b2_19,
                spa_b2_20,
                spa_b2_21,
                spa_b3_22,
                spa_b3_23,
                spa_c_24,
                spa_e1_26,
                spa_e1_27,
                spa_e1_28,
                spa_f1_29,
                spa_f1_30,
                spa_f1_31,
                spa_f2_32,
                spa_f2_33,
                spa_f3_34,
                spa_f3_35,
                spa_f3_36,
                spa_g_37,
                spa_g_38,
                {sql_str},
                CAST(FROM_UNIXTIME(UNIX_TIMESTAMP(snap_dt,'YYYY-MM-DD'), 'YYYYMM') AS INT) AS batch_mth
            FROM 
                {cdl_experian}.DCM_BATCH_M
            WHERE snap_dt = (SELECT cast('{partition_coldata}' as date))
            """.format(cdl_experian=CDL_EXPERIAN,cde_process=CDE_PROCESS,sql_str=SQL_STR,partition_coldata=PARTITION_COLDATA1)


    try:
            xdpLogger('xDP-INF-017',comment="Data load process for {cde_process}.PGFM_NEXPRIAN_RISK_DCM_BR_V11 has started".format(cde_process=CDE_PROCESS))
            spark.sql(query2)
            xdpLogger('xDP-INF-018',comment="Data load process for {cde_process}.PGFM_NEXPRIAN_RISK_DCM_BR_V11 has completed".format(cde_process=CDE_PROCESS))

    except Exception as e: 
            print("Exception while inserting into {cde_process}.PGFM_NEXPRIAN_RISK_DCM_BR_V11".format(cde_process=CDE_PROCESS))
            print("EXCEPTION :",str(e)) 
            xdpLogger('xDP-ERR-117',comment=e)            
            sys.exit(1)


    spark.stop()

if __name__ == "__main__":
    """ 
    Description: This is the entry point for execution of this script.
    The steps in sequence define the logical flow of the code
    """
    main()
