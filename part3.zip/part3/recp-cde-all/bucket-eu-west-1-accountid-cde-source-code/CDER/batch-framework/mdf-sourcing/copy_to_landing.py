#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from importlib import reload
reload(sys)
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import subprocess
import botocore.session
from datetime import datetime,timedelta
from datetime import date
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import get_logger,create_logger,xdpLogger
from pyspark.sql.utils import CapturedException
import boto3
from datetime import datetime
from botocore.session import Session
import pandas as pd
from botocore.exceptions import ClientError

def get_spark():
    """
    Get a spark session for processiong
    """
    new_spark = SparkSession \
    .builder \
    .appName("XDP_File_Movement_to_landing") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .config("spark.sql.broadcastTimeout", "3600") \
    .config("spark.dynamicAllocation.executorIdleTimeout ", "300").enableHiveSupport() \
    .getOrCreate()
    new_spark.sparkContext.setLogLevel("ERROR")
    return new_spark

def writeStatus2FileVersioning(input_list,spark):
    try:
        get_logger()
        sc = spark.sparkContext
        result_df = sc.parallelize(input_list).toDF(["file_name","version_id","s3_landing_date"]).select("file_name","version_id","s3_landing_date")
        if result_df.count()>0:
            result_df.write.mode('append').insertInto(job_option_config.sourcing_file_versioning,overwrite=False)
            xdpLogger('xDP-INF-111',comment='Status updated in sourcing_file_versioning table')
            return True
    except Exception as e:
        xdpLogger('xDP-ERR-117',comment=e)
        pass

if __name__ == "__main__":

    spark = get_spark()
    create_logger('XDP_File_Movement_to_landing')
    final_list=[]
    bucket_name=job_option_config.CDE_DATAIN_BUCKET
    key='data-in/cde/feeds/mdf/'
    session = Session()
    #client = session.create_client('s3')
    client = boto3.client('s3')
    obj_dict = client.list_objects(Bucket=bucket_name,Prefix=key)
    listOfobjects = obj_dict['Contents']
    #print(listOfobjects)
    source_bucket_name=job_option_config.CDE_DATAIN_BUCKET
    target_bucket_name=job_option_config.CDE_DATAIN_BUCKET
    # Destination Bucket to Copy To
    path="data-in/cde/feeds/feeds_time_stamp/"
    transformation_bucket_name=job_option_config.CDE_BUCKET
    sourcing_file_loc="/transformation/cde/cde_control/mainframe_feeds_master_info/mainframe_feeds_master_info.csv"
    sourcing_file_path='s3://'+transformation_bucket_name+sourcing_file_loc
    sourcing_tgt_path='/mnt/mainframe_feeds_master_info.csv'
    print(sourcing_file_path)
    a = subprocess.call(['aws','s3','cp',sourcing_file_path, sourcing_tgt_path])
    if a==0:
        print("CDE sourciing Master file info transferred successfully")
    else:
        print("CDE sourciing Master file info transferred failed")
        sys.exit(1)
    df_master = pd.read_csv("/mnt/mainframe_feeds_master_info.csv", header=None)
    cde_sourcing_files=df_master.iloc[:, 0].to_list()

    #Added for DMTP
    dmtp_list=job_option_config.DMTP_bkp_srcing_list

    df=spark.sql("select * from {sourcing_file_versioning}".format(sourcing_file_versioning=job_option_config.sourcing_file_versioning))
    df.createOrReplaceTempView('df')
    df.cache()
    mk=job_option_config.file_versioning_max_keys
    for object in listOfobjects :
        break_check=2
        name = (object['Key'])
        key=name
        print("####@@@@@@$$$$$$")
        print("key is --------------",key)
        key_file_name=key.split('/')[-1]
        if '.CSV' not in key:
            file_path1='s3://' + source_bucket_name + '/' + key
            c = subprocess.call(['aws','s3','rm',file_path1])
            continue

        if key_file_name not in cde_sourcing_files:
            print('Current file is not a CDE sourcing file')
            continue

       #added for DMTP
        if key_file_name.upper() in dmtp_list:
            file_path = 's3://' + source_bucket_name + '/' + key
            dmtp_path=job_option_config.DMTP_staging_bkp +key_file_name
            resp=subprocess.call(['aws','s3','cp',file_path,dmtp_path])

        copy_source_object = {'Bucket': source_bucket_name, 'Key': name}


        obj_version=client.list_object_versions(Bucket=source_bucket_name,Prefix=key,MaxKeys=mk)
        #print(obj_version)
        print("#########")

        for i in obj_version['Versions'] :
            Key =i['Key']
            print("version key is :",Key)
            VersionId=i['VersionId']
            print("version id is :",VersionId)
            last_mod=i['LastModified']
            last_modified=last_mod.strftime("%d-%m-%Y_%H:%M:%S")
            s3_landing_date=last_mod.strftime("%Y%m%d")
            print("version modified date is :",last_modified)    
            version_processed=df.select(df.version_id).where((df.file_name).like("%{file_name}%".format(file_name=key_file_name)) & (df.version_id=="{version_id}".format(version_id=VersionId)))
            file_path = 's3://' + source_bucket_name + '/' + key
            print(file_path)
            if version_processed.count()>0:
                print(VersionId, "version is already processed")
            else:
                file_key_name_dest=name+"_"+last_modified
                dest_file_name=file_key_name_dest.split("/")
                n=len(dest_file_name)
                dest_file_name=dest_file_name[n-1]
                full_dest_file_path = path+dest_file_name
                file_dest_path = 's3://' +target_bucket_name + '/' + full_dest_file_path
                print(file_dest_path)
                Source = {'Bucket': source_bucket_name, 'Key': key, 'VersionId': VersionId}
                print(Source)
                try:
                    x=client.copy(Bucket=target_bucket_name,Key=full_dest_file_path,CopySource=Source)
                    new_version_list= (dest_file_name,str(VersionId),str(s3_landing_date))
                    final_list.append(new_version_list)    
                except ClientError as e:
                    print(e)
                    xdpLogger('xDP-ERR-117',comment=e)
                    break_check=1
                    break
        if break_check==1:                
            print("Do not remove file as versioning was not retreived", file_path)
        else:
            subprocess.call(['aws','s3','rm',file_path])
    if len(final_list) >=1:
        writeStatus2FileVersioning(final_list,spark)
    else:
        print("No files were transferred. Nothing to insert in versioning table")
    spark.stop()