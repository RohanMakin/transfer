from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import *
import pandas as pd
import sys
import os
import re
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import create_logger, xdpLogger
import subprocess
import update_running_status
import csv
from datetime import datetime, timedelta


#spark-submit cde_teradata_tactical_feed_pre_processor.py
#Get most recently arrived file name as per file_prefix.  
def getLatestArrivedFileName(file_prefix, file_db_name, file_table_name, s3_path):
    try: 
        print("file_prefix: {FILE_PREFIX}{FILE_DB_NAME}.{FILE_TABLE_NAME}, s3_path: {S3_PATH}".format(FILE_PREFIX=file_prefix, FILE_DB_NAME=file_db_name, FILE_TABLE_NAME=file_table_name,S3_PATH=s3_path))
        
        out = subprocess.Popen(" \
        aws s3 ls {S3_PATH} | awk '{{print $4}}' | grep '\.dat.gz$' | grep '^{FILE_PREFIX}{FILE_DB_NAME}.{FILE_TABLE_NAME}' | sort -r | head -1".format(BUCKET=bucket,S3_PATH=s3_path,FILE_PREFIX=file_prefix,FILE_DB_NAME=file_db_name, FILE_TABLE_NAME=file_table_name), \
        shell=True, \
        stdout=subprocess.PIPE, \
        stderr=subprocess.STDOUT)
        
        stdout,stderr = out.communicate()
        
        print(stdout)
        #print(stderr)
        if str(stderr).strip() == "None": 
            print("getLatestArrivedFileName() successful.")
            return stdout
        else:
            raise Exception("getLatestArrivedFileName() call has failed." )
    except Exception as e: 
        print("Exception in function call : getLatestArrivedFileName()")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-117',comment=e)
        raise Exception(e)        
   

def moveFileToDestination(from_location, arrived_file_name, to_location, destination_file_name ):
    try: 
        print(" \
        from_location: {FROM_LOCATION}, \
        arrived_file_name: {ARRIVED_FILE_NAME}, \
        to_location: {TO_LOCATION}, \
        destination_file_name: {DESTINATION_FILE_NAME} \
        ".format(FROM_LOCATION=from_location,ARRIVED_FILE_NAME=arrived_file_name, TO_LOCATION=to_location, DESTINATION_FILE_NAME=destination_file_name) )
        
        out = subprocess.Popen(" \
        aws s3 cp {FROM_LOCATION}{ARRIVED_FILE_NAME} {TO_LOCATION}{DESTINATION_FILE_NAME}".format(FROM_LOCATION=from_location,ARRIVED_FILE_NAME=arrived_file_name,TO_LOCATION=to_location,DESTINATION_FILE_NAME=destination_file_name), \
        shell=True, \
        stdout=subprocess.PIPE, \
        stderr=subprocess.STDOUT)
        
        stdout,stderr = out.communicate()
        
        print(stdout)
        #print(stderr)
        if str(stderr).strip() == "None": 
            print("moveFileToDestination() call was successful.")
            return stdout
        else:
            raise Exception("moveFileToDestination() call has failed.")
    except Exception as e: 
        print("Exception in function call : moveFileToDestination()")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-117',comment=e)
        raise Exception(e)   

#getFileDate(latest_file_name,"%Y%m%d")   
#getFileDate("cde_con_acs_edw_tier1_cpb_sec01.ava_partyrelated_20210801190210.dat.gz","%Y%m%d")   
#latest_file_name = cde_con_acs_edw_tier1_cpb_sec01.ava_partyrelated_20210801190210.dat.gz
# should return in "20210802" format in above example
def getFileDate(latest_file_name, return_date_format):
    try: 
        print("latest_file_name: " + latest_file_name)
        file_name_date = latest_file_name[len(latest_file_name)-21:len(latest_file_name)-13]
        fl_hr =  latest_file_name[len(latest_file_name)-13:len(latest_file_name)-11]
        #formatted_file_date=datetime.strptime(file_name_date, '%Y%m%d').strftime('%Y%m%d')
        if int(fl_hr) >= 20 and int(fl_hr) <= 23: 
            return_date = (datetime.strptime(file_name_date,'%Y%m%d')).strftime('%Y%m%d')
        else:
            return_date = (datetime.strptime(file_name_date,'%Y%m%d')+timedelta(days=-1)).strftime('%Y%m%d')    
        #return_file_name=latest_file_name[0:len(latest_file_name)-21] + return_date + latest_file_name[len(latest_file_name)-13:len(latest_file_name)]
        return return_date 
    except Exception as e: 
        print("Exception in function call : getFileDate()")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-117',comment=e)
        raise Exception(e)  


def main():
    global job_name
    global flow_name
    global ts_start

    job_name = "CDE_TERADATA_TACTICAL_FEED_PRE_PROCESSOR"
    flow_name = "TERADATA_DATA_INGESTION"
    ts_start = pd.Timestamp('today')
    
    spark = SparkSession \
    .builder \
    .appName("CDE_TERADATA_TACTICAL_FEED_PRE_PROCESSOR") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .enableHiveSupport() \
    .getOrCreate() 

    spark.sparkContext.setLogLevel("ERROR")
    create_logger('CDE_TERADATA_TACTICAL_FEED_PRE_PROCESSOR')
    xdpLogger('xDP-INF-013',comment="Job has started")
    
    #Update start time
    try:
        update_running_status.update_start_time(spark,job_name,flow_name,ts_start)
        print("update_running_status.update_start_time() call was successful")
    except Exception as e:
        print("update_running_status.update_start_time() call failed. Logger will log the exception")
        xdpLogger('xDP-WAR-005',comment=e)
    
    try: 
        global bucket
        global database
        bucket=job_option_config.CDE_DATAIN_BUCKET  #'bucket-eu-west-1-{}-landing-zone'.format(account_id)
        print ("bucket = {BUCKET}".format(BUCKET=bucket))
        
        #create_logger('CDE_TERADATA_TACTICAL_FEED_PRE_PROCESSOR')
        #xdpLogger('xDP-INF-013',comment="Job has started")	
        
        the_path = os.path.join(os.path.dirname(__file__), 'config/cder_ssv2_files/cder_ssv2_files.csv')
        print("the_path: " + the_path)
        with open(the_path) as f:
            for row in csv.DictReader(f, skipinitialspace=True):
                print (row["file_table_name"] + "," + row["file_prefix"] + "," + row["file_db_name"] + "," + row["ssv2_arrival_location"] + "," + row["destination_location"])
                
                #Get from config file 
                file_prefix = row["file_prefix"]                                       #"cde_con_"
                td_database = row["file_db_name"]                                      #"acs_edw_tier1_cpb_sec01" 
                table_name = row["file_table_name"]                                    #"ava_partyrelated"
                arrival_location=row["ssv2_arrival_location"].format(BUCKET=bucket)    #"s3://{BUCKET}/data-in/cde/feeds/ssv2/"
                destination_location=row["destination_location"].format(BUCKET=bucket) #"s3://{BUCKET}/data-in/cde/migration/teradata/pre-prod/SUCCESS/whd01_edw_cpb_sec01/ava_partyrelated/"
                
                #Obtain the latest file which has arrived. 
                latest_file_name=getLatestArrivedFileName( \
                file_prefix, \
                td_database, \
                table_name, \
                arrival_location)
                latest_file_name=latest_file_name.decode('utf-8').rstrip("\n")
               
                if len(latest_file_name.strip())>0:
                    print("latest_file_name: {LATEST_FILE_NAME}".format(LATEST_FILE_NAME=latest_file_name))
                    #Obtain the corresponding AWS db
                    aws_database=job_option_config.cde_databases[td_database.upper()]
                    print("AWS database: {AWS_DATABASE}".format(AWS_DATABASE=aws_database))
                    
                    #if file_prefix is not the first few characters, then raise an exception. File prefix on SSV2 config != File prefix on AWS config.
                    #file_prefix_length = len(file_prefix)
                    if latest_file_name[0:len(file_prefix)] != file_prefix:
                        e="Config problem: File prefix on SSV2 config != File prefix on AWS config for this file."
                        print("EXCEPTION :",str(e))
                        #xdpLogger('xDP-ERR-117',comment=e)
                        raise Exception(e)
                    else:
                        print("File prefix on arrived file matches with file prefix in AWS config for this file.")    
                    #cde_con_acs_edw_tier1_cpb_sec01.ava_partyrelated_20210801190210.dat.gz
                    destination_file_name = (latest_file_name[len(file_prefix):len(latest_file_name) - 13] + ".csv.gz") # cde_con_acs_edw_tier1_cpb_sec01.ava_partyrelated_20210801.csv.gz
                    file_date = getFileDate(latest_file_name,"%Y%m%d")   # should return in "20210802" format
                    #destination_file_name = destination_file_name[0:len(destination_file_name)-16] + "." + \
                    #destination_file_name[len(destination_file_name)-15:len(destination_file_name)]
                    #get file date and name the destination file according to that date.
                    destination_file_name = destination_file_name[0:len(destination_file_name)-16] + "." + \
                    file_date  + \
                    ".csv.gz"
    
                    destination_file_name=destination_file_name.replace(td_database, aws_database, 1)
                    print("destination_file_name: " + destination_file_name)
    
                    #Move the file to the location, where it will be processed.
                    moveFileToDestination( \
                    arrival_location, \
                    latest_file_name, \
                    destination_location, \
                    destination_file_name)
                else: 
                    print("No matching file found for file_prefix: {FILE_PREFIX}, td_database: {TD_DATABASE}, table_name: {TABLE_NAME}, arrival_location: {ARRIVAL_LOCATION}, ending with: dat.gz".format(FILE_PREFIX=file_prefix, TD_DATABASE=td_database, TABLE_NAME=table_name, ARRIVAL_LOCATION=arrival_location))

    except Exception as e: 
        print("An exception has occured. The program is terminated now.")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-117',comment=e)
        ts_start = pd.Timestamp('today')
        update_running_status.update_error(spark,job_name,flow_name,table_name,ts_start)
        sys.exit(1) 		    
    
    ts_start = pd.Timestamp('today')
    try:
        update_running_status.update_end_time(spark,job_name,flow_name,ts_start)
    except Exception as e:
        xdpLogger('xDP-WAR-005',comment=e)
    xdpLogger('xDP-INF-014',comment="Job has completed") 
    spark.stop()
    sys.exit(0)
    
    
if __name__ == "__main__":
    """ Description: This is the entry point for execution of this script.
        The steps in sequence define the logical flow of the code
    """
    main()