from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as f
import sys
import os
import subprocess
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import create_logger, xdpLogger, get_logger
from datetime import datetime, date


def main():
    spark = SparkSession \
    .builder \
    .appName("MAINFRAME SOURCING TABLE MAINTANENCE JOB: "+PROCESS_TABLE_NAME) \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate() 

    spark.sparkContext.setLogLevel("ERROR")

    create_logger('MAINFRAME SOURCING TABLE MAINTANENCE JOB : {FEED_NAME}'.format(FEED_NAME=PROCESS_TABLE_NAME))
    xdpLogger('xDP-INF-013',comment="CDER sourcing process layer table maintainence for {FEED_NAME} has started".format(FEED_NAME=PROCESS_TABLE_NAME))
    ###   /*********************************************************************************** 
    ###   * Job:             CDE_MAINFRAME_FEED_PROCESS_LOAD_IV_TABLE_MAINTAINENCE           * 
    ###   * Description:     Deleting Multiple records from flag N and keeping 1 entry with  *
    ###   *                  min effective start dt and max effective end dt                 * 
    ###   * Created by:      Rahul Ranjan(ranjarz)/Accenture                                 *
    ###   ************************************************************************************/ 

    '''
    Reading required parameters passed as arguments
    '''

    PATH=setup_module_config_path.path 

    CDE_PROCESS=job_option_config.cde_databases["CDE_PROCESS"]
    ENV = job_option_config.CDE_ENV.upper()
    DATA_IN_BUCKET=job_option_config.CDE_DATAIN_BUCKET
    BUCKET=job_option_config.CDE_BUCKET

    '''
    Defined s3 buckets path based on environment variable
    '''
    
    S3_STAGING_ZONE='s3://'+BUCKET+'/transformation/cde'

    query1 ="""
                DESC {cde_process}.{PROCESS_TABLE}_TEMP
            """.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
    
    try:
        TABLE_DESC = spark.sql(query1)
        TABLE_DESC.createOrReplaceTempView("TABLE_DESC")
    except Exception as e: 
        print("Exception while describing table {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
        print("EXCEPTION :",str(e))  
        xdpLogger('xDP-ERR-117',comment=e)
        spark.stop()
        sys.exit(1)
  
    '''
    Creating sql statement string for handling delta records
    '''

    query2 = """
            SELECT 
                case when col_name = 'effective_start_dt' then "min("||col_name||") as effective_start_dt"
			         when col_name = 'effective_end_dt' then "max(" ||col_name||") as effective_end_dt"
                     when col_name = 'last_updated_dt' then "max("||col_name||") as last_updated_dt"
                     when col_name = 'last_updated_tm' then "max("||col_name||") as last_updated_tm"
                     when col_name = 'loaded_batch_id' then "min("||col_name||") as loaded_batch_id"
                     when col_name = 'updated_batch_id' then "max("||col_name||") as updated_batch_id"
                     else col_name end as tcol_name 
        FROM TABLE_DESC 
        """
    
    try:
        SELECT_STATEMENT = spark.sql(query2)
        DATA = SELECT_STATEMENT.rdd.map(lambda x : x.tcol_name)
        STR1 = DATA.collect()
        STR2 = ','.join(map(str,STR1))
        split_string=STR2.split(",min(effective_start_dt)", 1)
        STR3=split_string[0]
        print("Select String : ", STR2)
        print("Group By Clause: ", STR3)
    except Exception as e: 
        print("Exception while creating select statement for table {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
        print("EXCEPTION :",str(e))   
        xdpLogger('xDP-ERR-117',comment=e)
        spark.stop()
        sys.exit(1)    

    '''
    Creating TMP table
    '''

    spark.sql("DROP TABLE IF EXISTS {cde_process}.{PROCESS_TABLE}_INTERIM".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))

    query3 ="""
            CREATE TABLE IF NOT EXISTS {cde_process}.{PROCESS_TABLE}_INTERIM LIKE {cde_process}.{PROCESS_TABLE}
        """.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
    try:
        spark.sql(query3)
    except Exception as e: 
        print("Exception while creating tmp table {cde_process}.{PROCESS_TABLE}_INTERIM".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
        print("EXCEPTION :",str(e)) 
        xdpLogger('xDP-ERR-117',comment=e)
        spark.stop()
        sys.exit(1)
    
    '''
    Inserting delta updated records in temporary table
    '''

    COUNT_Y=spark.sql("SELECT COUNT(*) FROM {cde_process}.{PROCESS_TABLE} WHERE FLAG='N'".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)).collect()[0][0]
    
    if int(COUNT_Y/5000000) == 0:
        PART_Y=1
    else:
        PART_Y = int(COUNT_Y/5000000)
    print(PART_Y)

    query4 = """ 
            SELECT {STR} FROM {cde_process}.{PROCESS_TABLE} WHERE flag='N' group by {STR3}
                """.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME,STR=STR2,STR3=STR3) 

    try:
        xdpLogger('xDP-INF-017',comment="Data load process for {cde_process}.{PROCESS_TABLE}_INTERIM has started".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))  
        Delta_df=spark.sql(query4)
        Delta_df.coalesce(PART_Y).createOrReplaceTempView("DELTA_DF")
        spark.sql("Insert overwrite table {cde_process}.{PROCESS_TABLE}_INTERIM select *,'N' as flag from DELTA_DF".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
        xdpLogger('xDP-INF-018',comment="Data load process for {cde_process}.{PROCESS_TABLE}_INTERIM has completed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
    except Exception as e: 
        print("Exception while inserting delta records in table {cde_process}.{PROCESS_TABLE}_INTERIM".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
        print("EXCEPTION :",str(e))   
        xdpLogger('xDP-ERR-117',comment=e)
        spark.stop()
        sys.exit(1) 

    '''
    Refreshing temporary table partition
    ''' 
    
    spark.sql("ALTER TABLE {cde_process}.{PROCESS_TABLE}_INTERIM RECOVER PARTITIONS".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)) 
        
    '''
    Inserting data to final table from temporary table
    '''   
    
    xdpLogger('xDP-INF-017',comment="Active Data load process for {cde_process}.{PROCESS_TABLE} has started".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
    DELETE_INACTIVE_DATA="{s3_out}/{cde_process}/{PROCESS_TABLE}/flag=N/".format(s3_out=S3_STAGING_ZONE,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
    INACTIVE_DELTA_SRC="{s3_out}/{cde_process}/{PROCESS_TABLE}_interim/flag=N/".format(s3_out=S3_STAGING_ZONE,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
    INACTIVE_DELTA_TGT="{s3_out}/{cde_process}/{PROCESS_TABLE}/flag=N/".format(s3_out=S3_STAGING_ZONE,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
    retries = 6
    for i in range(retries):
        print('i',i)
        delete_inactive_data=subprocess.call(['aws','s3','rm',DELETE_INACTIVE_DATA,'--recursive'])
        if delete_inactive_data==0:
            print("InActive data deleted from {cde_process}.{PROCESS_TABLE} ".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            xdpLogger('xDP-INF-018',comment="InActive Data deleted from {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
        else:
            if i < retries-1 :
                print("InActive data deletion failed from {cde_process}.{PROCESS_TABLE} ...... Retrying the operation".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                xdpLogger('xDP-INF-018',comment="InActive Data deletion failed from {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                continue 
            else:
                print("Exception while deleting InActive data deleted from {cde_process}.{PROCESS_TABLE} . Check InActive partition in table before rerunning the load".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                list_2 = (snap_dt,str(BATCH_DATE).replace('-',''),file_nm,JOB_NAME,'ProcessLayerLoad', CDE_PROCESS+'.'+PROCESS_TABLE_NAME, 'Fail',str(datetime.now())[:-7],application_id,date.today())
                fail_list.append(list_2)
                writeStatus2FileIngestion(fail_list,spark)
                xdpLogger('xDP-ERR-117',comment='Exception while deleting Active data deleted from {cde_process}.{PROCESS_TABLE} . Check active partition in table before rerunning the load'.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                spark.stop()
                sys.exit(1)                    
        break

    for k in range(retries):                
        inactive_data_movement=subprocess.call(['aws','s3','cp',INACTIVE_DELTA_SRC,INACTIVE_DELTA_TGT,'--recursive'])
        if inactive_data_movement==0:
            print("InActive Data load process for {cde_process}.{PROCESS_TABLE} has completed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))    
            xdpLogger('xDP-INF-018',comment="InActive Data load process for {cde_process}.{PROCESS_TABLE} has completed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))

        else:
            if k < retries-1 :
                print("INActive Data load process for {cde_process}.{PROCESS_TABLE} has failed.... retrying the operation".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))                
                xdpLogger('xDP-INF-018',comment="InActive Data load process for {cde_process}.{PROCESS_TABLE} has failed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                continue
            else:
                print("Exception while Overwriting inactive partition in table {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                xdpLogger('xDP-ERR-117',comment='Exception while Overwriting inactive partition in table {cde_process}.{PROCESS_TABLE}'.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                spark.stop()
                sys.exit(1)
        break


    '''
    Refreshing final table partition
    ''' 

    spark.sql("ALTER TABLE {cde_process}.{PROCESS_TABLE} RECOVER PARTITIONS".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))

    '''
    Dropping temporary table
    '''

    spark.sql("DROP TABLE IF EXISTS {cde_process}.{PROCESS_TABLE}_INTERIM".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))

    xdpLogger('xDP-INF-013',comment="CDER sourcing process layer table maintainence for {FEED_NAME} has comleted".format(FEED_NAME=PROCESS_TABLE_NAME))
    spark.stop()

if __name__ == "__main__":
    """ 
    Description: This is the entry point for execution of this script.
    The steps in sequence define the logical flow of the code
    """
    PROCESS_TABLE_NAME = sys.argv[1].lower()
    main()
