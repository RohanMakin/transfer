from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import *
import sys
import os
import re
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import create_logger, xdpLogger, get_logger
import subprocess
from datetime import datetime, date
import time

def main():
    spark = SparkSession \
    .builder \
    .appName("MAINFRAME SPLIT FEED COUNT CHECK") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate() 

    spark.sparkContext.setLogLevel("ERROR")


    ###   /*********************************************************************************** 
    ###   * Job:             split File Count check for each batch                           * 
    ###   * Description:     CHECKING FEED FILE COUNT FOR SPLIT FILES RECEVIED FROM MAINFRAME*
    ###   *                                                                                  * 
    ###   * Created by:      Rahul Ranjan(ranjarz)/Accenture                                 *
    ###   *                                                                                  *
    ###   ************************************************************************************/ 

    '''
    Reading required parameters passed as arguments
    '''

    PATH=setup_module_config_path.path
    JOB_NAME = sys.argv[1].upper() 
    FILE_NAME = sys.argv[2].upper()
    SYSPARM = sys.argv[3].upper()
    CDE_CONTROL=job_option_config.cde_databases["CONTROL"]
    ENV = job_option_config.CDE_ENV.upper()
    DATA_IN_BUCKET=job_option_config.CDE_DATAIN_BUCKET
    BUCKET=job_option_config.CDE_BUCKET
    create_logger('MAINFRAME SPLIT FEED COUNT CHECK : {FEED_NAME}'.format(FEED_NAME=FILE_NAME)) 

    staging_layer_query = """select file_ingestion_ft.batch_dt, file_ingestion_ft.file_prefix_nm,count(*) as file_count from
                                      (select distinct file_nm, file_prefix_nm, batch_dt,snap_dt from {} where file_prefix_nm = '{}' and action_type='File Arrival' and action_typ_details = 'File Arrived' and status='Pass' order by file_nm,file_prefix_nm, batch_dt,snap_dt) file_ingestion_ft
                                      left join
                                      (select distinct file_nm, file_prefix_nm, batch_dt,snap_dt from {} where file_prefix_nm = '{}' and action_type = 'StageLayerLoad' and status='Pass' ) file_ingestion_sll
                                       on file_ingestion_ft.file_prefix_nm = file_ingestion_sll.file_prefix_nm and file_ingestion_ft.snap_dt = file_ingestion_sll.snap_dt and file_ingestion_ft.file_nm = file_ingestion_sll.file_nm
                                       where file_ingestion_sll.file_prefix_nm is null group by file_ingestion_ft.batch_dt,file_ingestion_ft.file_prefix_nm order by file_ingestion_ft.batch_dt""".format(job_option_config.file_ingestion_detail,JOB_NAME,job_option_config.file_ingestion_detail,JOB_NAME)

    expected_count = spark.sql("""select count(*) from {TBBD_INST}.mainframe_feeds_master_info where file_prefix='{job_name}' """.format(job_name=JOB_NAME,TBBD_INST=CDE_CONTROL)).collect()[0][0]
    create_logger('MAINFRAME FEED FILE CHECK : {FEED_NAME}'.format(FEED_NAME=JOB_NAME)) 
    retries = 25
    for i in range(retries):
        print("i iteration {}".format(i))
        stage_file_df = spark.sql(staging_layer_query)
        stage_file_df.show()
        if stage_file_df.count() == 0:
            xdpLogger('xDP-INF-111',comment="No files to process for staging layer load for:  {}".format(JOB_NAME))
            if i < retries - 1: # i is zero indexed
                xdpLogger('xDP-WAR-005',comment="No files to process for staging layer load for:  {}".format(JOB_NAME))
                time.sleep(900)
                spark.sql("refresh table {}""".format(job_option_config.file_ingestion_detail))
                continue
            else:
                xdpLogger('xDP-ERR-117',comment="No files to process for staging layer load for:  {}".format(JOB_NAME))
                spark.stop()
                sys.exit(1)
        else:
            xdpLogger('xDP-INF-111',comment="files received for process for staging layer load for:  {}".format(JOB_NAME))
            break
    count_check_retry=1
    j=1
    while j <= 2:
        print("j iteration {}".format(j))
        for item in stage_file_df.collect():
            file_item = item['file_prefix_nm']
            batch_dt = item['batch_dt']
            file_count = item['file_count']
            if int(file_count) == int(expected_count):
                xdpLogger('xDP-INF-013',comment="CDER sourcing file for feed {FEED_NAME} has been received for batch {BATCH_DT}".format(FEED_NAME=file_item,BATCH_DT=batch_dt))
                print("Process to check feed count for split files has been Completed")
                xdpLogger('xDP-INF-014',comment="CDER sourcing file count check for feed {FEED_NAME} has completed".format(FEED_NAME=file_item))
                j=3
            else :
                xdpLogger('xDP-WAR-005',comment="Issue with CDER sourcing file count for feed {FEED_NAME} and  batch {BATCH_DT}. No of files recieved = {FILE_COUNT} and expected count is {EXPECTED_COUNT}".format(FEED_NAME=file_item,FILE_COUNT=file_count,EXPECTED_COUNT=expected_count,BATCH_DT=batch_dt))
                print("No of feed count mismatch...Process to check feed count for split files is in progress")
                time.sleep(900)
                spark.sql("refresh table {}""".format(job_option_config.file_ingestion_detail))
                stage_file_df = spark.sql(staging_layer_query)
                stage_file_df.show()
                j=2
                count_check_retry += 1
                if count_check_retry < retries - 1:
                    continue
                else:
                    xdpLogger('xDP-ERR-117',comment="Issue with CDER sourcing file count for feed {FEED_NAME} and  batch {BATCH_DT}. No of files recieved = {FILE_COUNT} and expected count is {EXPECTED_COUNT}".format(FEED_NAME=file_item,FILE_COUNT=file_count,EXPECTED_COUNT=expected_count,BATCH_DT=batch_dt))
                    spark.stop()
                    sys.exit(1)


    xdpLogger('xDP-INF-014',comment="CDER sourcing file count check for feed {FEED_NAME} has completed".format(FEED_NAME=file_item))
    spark.stop()

if __name__ == "__main__":
    """ 
    Description: This is the entry point for execution of this script.
    The steps in sequence define the logical flow of the code
    """
    main()
