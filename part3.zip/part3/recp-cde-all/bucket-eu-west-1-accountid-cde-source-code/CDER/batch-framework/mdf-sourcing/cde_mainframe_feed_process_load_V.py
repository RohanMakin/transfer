from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as f
import sys
import os
import subprocess
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import create_logger, xdpLogger, get_logger
from datetime import datetime, date
from pyspark.sql.utils import AnalysisException

def writeStatus2FileIngestion(input_list,spark):
    try:
        get_logger()
        sc = spark.sparkContext
        result_df = sc.parallelize(input_list).toDF(["snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt"]).select("snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt")
        if result_df.count()>0:
            result_df.write.mode('append').insertInto(job_option_config.file_ingestion_detail,overwrite=False)
            xdpLogger('xDP-INF-111',comment='Status updated in File Ingestion detail table')
            return True
    except Exception as e:
        xdpLogger('xDP-ERR-117',comment='Error while updating File Ingestion detail table')
        xdpLogger('xDP-ERR-117',comment=e)
        pass


def main():
    spark = SparkSession \
    .builder \
    .appName("MAINFRAME PROCESS LAYER V LOADING") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate() 

    spark.sparkContext.setLogLevel("ERROR")
    conflist = spark.sparkContext.getConf().getAll()
    for i in conflist:
        if 'spark.app.id' in i[0]:
            application_id = i[1]


    ###   /*********************************************************************************** 
    ###   * Job:             CDE_MAINFRAME_FEED_PROCESS_LOAD_V                         * 
    ###   * Description:     TYPE V HANDLING FOR FULL ACTIVE FILES                          *
    ###   *                  READING MAINFRAME FIXED WIDTH, PIPE DELIMITED ,COMMA DELIMITED  *
    ###   *                  FILES DATA FROM CDE STAGING LAYER AND INSERTING ACTIVE RECORDS  *
    ###                         AND DEACTIVATING PREVIOUS RECORDS IN CDE PROCESS LAYER TABLE    * 
    ###   * Created by:      Bharath GVS(gvshrs)/Accenture                                 *
    ###   *                  Rahul Ranjan(ranjarz)/Accenture                                 *
    ###   ************************************************************************************/ 

    '''
    Reading required parameters passed as arguments
    '''

    PATH=setup_module_config_path.path    
    JOB_NAME = sys.argv[1].upper() 
    FILE_NAME = sys.argv[2].upper()
    SYSPARM = sys.argv[3].upper()
    CDE_CONTROL=job_option_config.cde_databases["CONTROL"]
    ENV = job_option_config.CDE_ENV.upper()
    DATA_IN_BUCKET=job_option_config.CDE_DATAIN_BUCKET
    BUCKET=job_option_config.CDE_BUCKET
    create_logger('MAINFRAME PROCESS LAYER V LOADING')
    process_layer_query = """select file_ingestion_sll.* from
                                      (select * from {} where file_prefix_nm = '{}' and action_type='StageLayerLoad' and status='Pass' and file_nm like '{}%' order by file_nm) file_ingestion_sll
                                      left join
                                      (select * from {} where file_prefix_nm = '{}' and action_type = 'ProcessLayerLoad' and status='Pass' and file_nm like '{}%' ) file_ingestion_pll
                                       on file_ingestion_sll.file_prefix_nm = file_ingestion_pll.file_prefix_nm and file_ingestion_sll.snap_dt = file_ingestion_pll.snap_dt and file_ingestion_sll.file_nm = file_ingestion_pll.file_nm
                                       where file_ingestion_pll.file_prefix_nm is null order by batch_dt asc""".format(job_option_config.file_ingestion_detail,JOB_NAME,FILE_NAME,job_option_config.file_ingestion_detail,JOB_NAME,FILE_NAME)
    process_file_df = spark.sql(process_layer_query)
    process_file_df.show()
    if process_file_df.count() == 0:
        xdpLogger('xDP-INF-111',comment="No files to process for staging layer load for:  {}".format(JOB_NAME))
        sys.exit(0)
    for file_item in process_file_df.collect():
        success_list = []
        fail_list = []
        snap_dt = file_item['snap_dt']
        batch_dt = file_item['batch_dt']
        BATCH_DATE = str(batch_dt)[0:4]+'-'+str(batch_dt)[4:6]+'-'+str(batch_dt)[6:8]
        file_nm = file_item['file_nm']
        print("snap_dt", snap_dt, "file_nm", file_nm, "batch_dt", batch_dt, "BATCH_DT", BATCH_DATE)
        create_logger('MAINFRAME PROCESS LAYER FILE TYPE V LOADING : {FEED_NAME}'.format(FEED_NAME=file_nm))
        xdpLogger('xDP-INF-013',comment="CDER sourcing data loading process till staging layer for feed {FEED_NAME} has started".format(FEED_NAME=file_nm))

        '''
        Process to check if interim .ok file is present or not. Fail the load to manually validate the pre data required for updates.
        ''' 
        try:
            print("Checking interim ok file")
            full_ok_file_interim_nm = job_option_config.interim_file_location+JOB_NAME+'_'+snap_dt+'_'+str(BATCH_DATE).replace('-','')+'_PROCESS_LOAD_STARTED.ok'
            list_s3_file = subprocess.call(['aws','s3','ls','{file_path}'.format(file_path=full_ok_file_interim_nm),'--recursive'])

            if list_s3_file == 0:
                print('Process load was executed . Check the pre cut data required for update and rerun the job after removing the file : {}'.format(full_ok_file_interim_nm))
                xdpLogger('xDP-ERR-117',comment='Process load was executed . Check the pre cut required for update and rerun the job after removing the file : {}'.format(full_ok_file_interim_nm))
                spark.stop()
                sys.exit(1)
            else:
                print('First iteration to load process layer') 
                xdpLogger('xDP-INF-010',comment='First iteration to load load process layer')      
        except Exception as exp:
            xdpLogger('xDP-ERR-117',comment=exp)
            spark.stop()
            sys.exit(1)  

        '''
        Extracting required information from master table for file information 
        '''

        try:
            info=spark.sql("""
                    SELECT
                        FILE_NAME,
                        FILE_TYPE,
                        STAGING_TABLE_NAME,
                        PROCESS_TABLE_NAME,
                        CDE_SOURCE_FIELDS,
                        DERIVED_FIELDS,
                        HIVE_SCHEMA_NAME,
                        KEY_FIELDS,
                        SECT_CODE_SELECT_STR,
                        DML_FLAG,
                        DATE_STR,
                        STG_DB,
                        PROCESS_DB
                    FROM 
                        {cde_control}.MAINFRAME_FEEDS_MASTER_INFO
                    WHERE
                        FILE_NAME='{FILENAME}'
                    """.format(FILENAME=FILE_NAME,cde_control=CDE_CONTROL)).collect()
                    
            FILE_TYPE , STAGING_TABLE_NAME , PROCESS_TABLE_NAME, CDE_SOURCE_FIELDS, DERIVED_FIELDS , HIVE_SCHEMA_NAME , KEY_FIELDS , SECT_CODE_SELECT_STR , DML_FLAG ,DATE_STR, CDE_STAGING , CDE_PROCESS = info[0][1],info[0][2].lower(),info[0][3].lower(),info[0][4],info[0][5],info[0][6],info[0][7],info[0][8],info[0][9],info[0][10],info[0][11].lower(),info[0][12].lower()
            VAR_STR="FILE_TYPE : "+FILE_TYPE + " , STAGING_TABLE_NAME : "+STAGING_TABLE_NAME+ " , PROCESS_TABLE_NAME : "+PROCESS_TABLE_NAME+ ", CDE_SOURCE_FIELDS : "+CDE_SOURCE_FIELDS+" , DERIVED_FIELDS : "+DERIVED_FIELDS+" , HIVE_SCHEMA_NAME : "+HIVE_SCHEMA_NAME+" , KEY_FIELDS : "+KEY_FIELDS+" , SECT_CODE_SELECT_STR : " + SECT_CODE_SELECT_STR+" , DML_FLAG : " + DML_FLAG
            xdpLogger('xDP-INF-025',comment=VAR_STR)
        except Exception as e:
            print("Exception while extracting information from master control table cde_control.MAINFRAME_FEEDS_MASTER_INFO")
            print("EXCEPTION :",str(e))
            xdpLogger('xDP-ERR-117',comment=e) 
            sys.exit(1)

        '''
        Defined s3 buckets path based on environment variable
        '''
    
        S3_STAGING_ZONE='s3://'+BUCKET+'/transformation/cde'

        '''
        Extracting batch information from cde source batch id control table.
        '''

        try:
            batch_info=spark.sql("""
                                SELECT
                                    BATCH_DATE,
                                    CASE 
                                        WHEN 'RBS'=='{sysparm}' THEN RBS_BATCH_ID
                                        WHEN 'NWB'=='{sysparm}' THEN NWB_BATCH_ID
                                        WHEN 'UBN'=='{sysparm}' THEN UBN_BATCH_ID
                                        WHEN 'UBS'=='{sysparm}' THEN UBR_BATCH_ID
                                    ELSE GRP_BATCH_ID
                                    END AS BATCH_ID
                                FROM
                                    {cde_control}.SOURCING_BATCH_ID_CONTROL_TABLE
                            """.format(cde_control=CDE_CONTROL,sysparm=SYSPARM)).collect()
        
            BATCH_ID = batch_info[0][1]         
        except Exception as e:
            print("Exception while extracting batch information from control table cde_control.SOURCING_BATCH_ID_CONTROL_TABLE")
            print("EXCEPTION :",str(e))
            xdpLogger('xDP-ERR-117',comment=e) 
            spark.stop()
            sys.exit(1)

        '''
        Extratcting derived columns info from master table
        '''

        DERIVED_COLUMNS=DERIVED_FIELDS.split('|')
        SQL_STR=DATE_STR
        for col in DERIVED_COLUMNS:
            if col.upper()=="EFFECTIVE_START_DT":
                SQL_STR+="'{batch_date}' AS {COL},".format(batch_date=BATCH_DATE,COL=col)   
            elif col.upper()=="EFFECTIVE_END_DT":
                SQL_STR+="'9999-12-31' AS {COL},".format(COL=col)    
            elif col.upper()=="LAST_UPDATED_DT":
                SQL_STR+="CURRENT_DATE() AS {COL},".format(COL=col)        
            elif col.upper()=="LAST_UPDATED_TM":
                SQL_STR+="SUBSTR(NOW(),12,8) AS {COL},".format(COL=col)    
            elif col.upper()=="LOADED_BATCH_ID":
                SQL_STR+="{batch_id},".format(batch_id=BATCH_ID,COL=col)        
            elif col.upper()=="UPDATED_BATCH_ID":
                SQL_STR+="NULL".format(COL=col)

        xdpLogger('xDP-INF-025',comment="Derived column string : {sql_str}".format(sql_str=SQL_STR))   

        '''
        Inserting temp table for handling delta file type
        '''
        if DML_FLAG.upper() == 'F':
            query3="""
                INSERT OVERWRITE TABLE {cde_process}.{PROCESS_TABLE}_TEMP
                SELECT
                    {file_fields},
                    {sql_str}
                FROM 
                    {cde_staging}.{STAGING_TABLE} where ACC_LAST_CHANGE_DT = {batch_date} AND batch_dt = '{batch_dt}'
                """.format(cde_staging=CDE_STAGING,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME,STAGING_TABLE=STAGING_TABLE_NAME,file_fields=CDE_SOURCE_FIELDS,sql_str=SQL_STR,batch_date=BATCH_DATE,batch_dt=batch_dt)
        elif DML_FLAG.upper() == 'S':
            SELECT_STRING=SECT_CODE_SELECT_STR.format(cde_staging=CDE_STAGING,sql_str=SQL_STR,batch_dt=batch_dt,batch_date=BATCH_DATE,file_fields=CDE_SOURCE_FIELDS)
            query3="""
                INSERT OVERWRITE TABLE {cde_process}.{PROCESS_TABLE}_TEMP
                {SPLIT_SELECT_STR}
                """.format(cde_staging=CDE_STAGING,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME,SPLIT_SELECT_STR=SELECT_STRING)  
        else:
            query3="""
                INSERT OVERWRITE TABLE {cde_process}.{PROCESS_TABLE}_TEMP
                SELECT
                    {file_fields},
                    {sql_str}
                FROM 
                    {cde_staging}.{STAGING_TABLE}
                    WHERE batch_dt = '{batch_dt}'
                """.format(cde_staging=CDE_STAGING,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME,STAGING_TABLE=STAGING_TABLE_NAME,file_fields=CDE_SOURCE_FIELDS,sql_str=SQL_STR,batch_date=BATCH_DATE,batch_dt=batch_dt)
        try:
            xdpLogger('xDP-INF-017',comment="Data load process for {cde_process}.{PROCESS_TABLE}_TEMP has started".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            spark.sql(query3)
            xdpLogger('xDP-INF-018',comment="Data load process for {cde_process}.{PROCESS_TABLE}_TEMP has completed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
        except AnalysisException:
            subprocess.call(['sudo','aws','s3api','put-object','--bucket','{BUCKET}'.format(BUCKET=BUCKET),'--key','transformation/cde/{cde_process}/{PROCESS_TABLE}_temp/'.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)])
            spark.sql(query3)
        except Exception as e: 
            print("Exception while inserting into {cde_process}.{PROCESS_TABLE}_TEMP".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            print("EXCEPTION :",str(e))    
            xdpLogger('xDP-ERR-117',comment=e) 
            spark.stop()
            sys.exit(1)

        query4 ="""
                DESC {cde_process}.{PROCESS_TABLE}_TEMP
            """.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
    
        try:
            TABLE_DESC = spark.sql(query4)
            TABLE_DESC.createOrReplaceTempView("TABLE_DESC")
        except Exception as e: 
            print("Exception while describing table {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            print("EXCEPTION :",str(e))  
            xdpLogger('xDP-ERR-117',comment=e) 
            spark.stop()
            sys.exit(1)
        
        '''
        Creating sql statement string for handling delta records
        '''

        query5 = """
                SELECT col_name tcol_name 
                FROM TABLE_DESC 
            """
    
        try:
            SELECT_STATEMENT = spark.sql(query5)
            DATA = SELECT_STATEMENT.rdd.map(lambda x : x.tcol_name)
            STR1 = DATA.collect()
            STR2 = ','.join(map(str,STR1))
            split_string = STR2.split(",effective_end_dt", 1)
            STR3 = split_string[0]
            STR3 = 'TGT.'+STR3.replace(',',',TGT.')
            split_string = STR2.split(",effective_start_dt", 1)
            STR4 = split_string[0]
        except Exception as e: 
            print("Exception while creating select statement for table {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            print("EXCEPTION :",str(e))   
            xdpLogger('xDP-ERR-117',comment=e) 
            spark.stop()
            sys.exit(1)    

        '''
        Creating primary key col check and join condition string
        '''

        JOIN_COLUMNS=STR4.split(',')
        JOIN_CONDTN=[]
        for col in JOIN_COLUMNS:
            JOIN_CONDTN.append("COALESCE(CAST(SRC.{COL} AS STRING),'DUMMY')=COALESCE(CAST(TGT.{COL} AS STRING),'DUMMY')".format(COL=col))
        JOIN_CONDITION=" AND ".join(JOIN_CONDTN)
    
        xdpLogger('xDP-INF-025',comment="JOIN_CONDITION STRING : {JOIN}".format(JOIN=JOIN_CONDITION))
        print("JOIN_CONDITION:",JOIN_CONDITION)
        
        '''
        Creating TMP table
        '''

        spark.sql("DROP TABLE IF EXISTS {cde_process}.{PROCESS_TABLE}_TMP".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))

        query6 ="""
                CREATE TABLE IF NOT EXISTS {cde_process}.{PROCESS_TABLE}_TMP LIKE {cde_process}.{PROCESS_TABLE}
            """.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
        try:
            spark.sql(query6)
        except Exception as e: 
            print("Exception while creating tmp table {cde_process}.{PROCESS_TABLE}_tmp".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            print("EXCEPTION :",str(e)) 
            xdpLogger('xDP-ERR-117',comment=e)
            spark.stop()
            sys.exit(1)
        
        '''
        Inserting delta updated records in temporary table
        '''

        COUNT_Y=spark.sql("SELECT COUNT(*) FROM {cde_process}.{PROCESS_TABLE} WHERE FLAG='Y'".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)).collect()[0][0]
    
        if int(COUNT_Y/5000000) == 0:
            PART_Y=1
        else:
            PART_Y = int(COUNT_Y/5000000)
        print(PART_Y)

        query7 = """ 
                SELECT distinct TGT.* FROM {cde_process}.{PROCESS_TABLE} TGT INNER JOIN {cde_process}.{PROCESS_TABLE}_TEMP SRC ON {JOIN_CONDTN} WHERE TGT.flag = 'Y'
                UNION
                SELECT SRC.*,'Y' FROM {cde_process}.{PROCESS_TABLE}_TEMP SRC LEFT ANTI JOIN (SELECT * FROM {cde_process}.{PROCESS_TABLE} WHERE flag = 'Y') TGT ON {JOIN_CONDTN}
                UNION
                SELECT {str3},date_sub('{batch_date}',1),current_date(),substr(now(),12,8),TGT.loaded_batch_id,{batch_id},'N' FROM (SELECT * FROM {cde_process}.{PROCESS_TABLE} WHERE flag = 'Y') TGT LEFT ANTI JOIN {cde_process}.{PROCESS_TABLE}_TEMP SRC ON {JOIN_CONDTN}
                """.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME,JOIN_CONDTN=JOIN_CONDITION,str3=STR3,batch_date=BATCH_DATE,batch_id=BATCH_ID)

        try:
            xdpLogger('xDP-INF-017',comment="Data load process for {cde_process}.{PROCESS_TABLE}_TMP has started".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))  
            Delta_df=spark.sql(query7)
            Delta_df.coalesce(PART_Y).createOrReplaceTempView("DELTA_DF")
            spark.sql("Insert overwrite table {cde_process}.{PROCESS_TABLE}_TMP select * from DELTA_DF".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            xdpLogger('xDP-INF-018',comment="Data load process for {cde_process}.{PROCESS_TABLE}_TMP has completed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
        except Exception as e: 
            print("Exception while inserting delta records in table {cde_process}.{PROCESS_TABLE}_TMP".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            print("EXCEPTION :",str(e))   
            xdpLogger('xDP-ERR-117',comment=e)
            spark.stop()
            sys.exit(1)

        '''
        Refreshing temporary table partition
        ''' 
        try:
            xdpLogger('xDP-INF-017',comment="TMP Table recover partitions")
            print("Before")
            spark.sql("ALTER TABLE {cde_process}.{PROCESS_TABLE}_TMP RECOVER PARTITIONS".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            print("After")
        except Exception as e: 
            print("Exception:",e)


        '''
        Creating intermediate ok file to prevent rerunning of job without having pre data required for update logic
        ''' 
        try:
            print("writing ok file")
            ok_file_interim_nm = JOB_NAME+'_'+snap_dt+'_'+str(BATCH_DATE).replace('-','')+'_PROCESS_LOAD_STARTED.ok'
            print(ok_file_interim_nm)
            interim_file = subprocess.call(['touch', ok_file_interim_nm])
            print(interim_file)
            if interim_file == 0:
                xdpLogger('xDP-INF-010',comment='Process load interim File created successfully: {}'.format(ok_file_interim_nm))
                try:
                    copy_to_s3 = subprocess.call(['aws','s3','mv', ok_file_interim_nm, job_option_config.interim_file_location])
                    xdpLogger('xDP-INF-010',comment='Process load interim File moved successfully: {}'.format(ok_file_interim_nm))
                except Exception as e:
                    xdpLogger('xDP-WAR-040',comment='Process load interim File moved failed: {}'.format(ok_file_interim_nm))
                    xdpLogger('xDP-ERR-117',comment=e)
                    spark.stop()
                    sys.exit(1) 
            else:
                xdpLogger('xDP-ERR-117',comment='Error while creating .completed file: {}'.format(ok_file_interim_nm))
                spark.stop()
                sys.exit(1)        
        except Exception as exp:
            xdpLogger('xDP-ERR-117',comment=exp)
            spark.stop()
            sys.exit(1)  
            
        '''
        Inserting data to final table from temporary table
        '''   
    
        xdpLogger('xDP-INF-017',comment="Active Data load process for {cde_process}.{PROCESS_TABLE} has started".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
        DELETE_ACTIVE_DATA="{s3_out}/{cde_process}/{PROCESS_TABLE}/flag=Y/".format(s3_out=S3_STAGING_ZONE,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
        ACTIVE_DELTA_SRC="{s3_out}/{cde_process}/{PROCESS_TABLE}_tmp/flag=Y/".format(s3_out=S3_STAGING_ZONE,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
        ACTIVE_DELTA_TGT="{s3_out}/{cde_process}/{PROCESS_TABLE}/flag=Y/".format(s3_out=S3_STAGING_ZONE,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
        INACTIVE_DELTA_SRC="{s3_out}/{cde_process}/{PROCESS_TABLE}_tmp/flag=N/".format(s3_out=S3_STAGING_ZONE,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
        INACTIVE_DELTA_TGT="{s3_out}/{cde_process}/{PROCESS_TABLE}/flag=N/".format(s3_out=S3_STAGING_ZONE,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)
        retries = 6
        for i in range(retries):
            print('i',i)
            delete_active_data=subprocess.call(['aws','s3','rm',DELETE_ACTIVE_DATA,'--recursive'])
            if delete_active_data==0:
                print("Active data deleted from {cde_process}.{PROCESS_TABLE} ".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                xdpLogger('xDP-INF-018',comment="Active Data deleted from {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            else:
                if i < retries-1 :
                    print("Active data deletion failed from {cde_process}.{PROCESS_TABLE} ...... Retrying the operation".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                    xdpLogger('xDP-INF-018',comment="Active Data deletion failed from {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                    continue 
                else:
                    print("Exception while deleting Active data deleted from {cde_process}.{PROCESS_TABLE} . Check active partition in table before rerunning the load".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                    list_2 = (snap_dt,str(BATCH_DATE).replace('-',''),file_nm,JOB_NAME,'ProcessLayerLoad', CDE_PROCESS+'.'+PROCESS_TABLE_NAME, 'Fail',str(datetime.now())[:-7],application_id,date.today())
                    fail_list.append(list_2)
                    writeStatus2FileIngestion(fail_list,spark) 
                    xdpLogger('xDP-ERR-117',comment='Exception while deleting Active data deleted from {cde_process}.{PROCESS_TABLE} . Check active partition in table before rerunning the load'.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                    spark.stop()
                    sys.exit(1)                    
            break

        
        for j in range(retries) :            
            active_data_movement=subprocess.call(['aws','s3','cp',ACTIVE_DELTA_SRC,ACTIVE_DELTA_TGT,'--recursive'])
            if active_data_movement==0:  
                print("Active Data load process for {cde_process}.{PROCESS_TABLE} has completed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))                
                xdpLogger('xDP-INF-018',comment="Active Data load process for {cde_process}.{PROCESS_TABLE} has completed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            else:
                if j < retries-1 :
                    print("Active Data load process for {cde_process}.{PROCESS_TABLE} has failed.... retrying the operation".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                    xdpLogger('xDP-INF-018',comment="Active Data load process for {cde_process}.{PROCESS_TABLE} has failed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                    continue 
                else: 
                    print("Exception while Inserting Active data into {cde_process}.{PROCESS_TABLE}.Check active partition in table before rerunning the load".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))  
                    list_2 = (snap_dt,str(BATCH_DATE).replace('-',''),file_nm,JOB_NAME,'ProcessLayerLoad', CDE_PROCESS+'.'+PROCESS_TABLE_NAME, 'Fail',str(datetime.now())[:-7],application_id,date.today())
                    fail_list.append(list_2)
                    writeStatus2FileIngestion(fail_list,spark) 
                    xdpLogger('xDP-ERR-117',comment='Exception while Inserting Active data into {cde_process}.{PROCESS_TABLE}.Check active partition in table before rerunning the load'.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                    spark.stop()
                    sys.exit(1)
            break

        for k in range(retries):                
            inactive_data_movement=subprocess.call(['aws','s3','cp',INACTIVE_DELTA_SRC,INACTIVE_DELTA_TGT,'--recursive'])
            if inactive_data_movement==0:
                print("InActive Data load process for {cde_process}.{PROCESS_TABLE} has completed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))    
                xdpLogger('xDP-INF-018',comment="InActive Data load process for {cde_process}.{PROCESS_TABLE} has completed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                list_1= (snap_dt,str(BATCH_DATE).replace('-',''),file_nm,JOB_NAME,'ProcessLayerLoad', CDE_PROCESS+'.'+PROCESS_TABLE_NAME, 'Pass',str(datetime.now())[:-7],application_id,date.today())
                success_list.append(list_1)
                writeStatus2FileIngestion(success_list,spark)
                #write ok file
                try:
                    print("writing ok file")
                    ok_file_nm = JOB_NAME+'_'+snap_dt+'_'+str(BATCH_DATE).replace('-','')+'_COMPLETED.ok'
                    print(ok_file_nm)
                    completed_file = subprocess.call(['touch', ok_file_nm])
                    print(completed_file)
                    if completed_file == 0:
                        xdpLogger('xDP-INF-010',comment='Done File created successfully: {}'.format(ok_file_nm))
                        try:
                            copy_to_s3 = subprocess.call(['aws','s3','mv', ok_file_nm, job_option_config.done_file_location])
                            remove_from_s3 = subprocess.call(['aws','s3','rm', full_ok_file_interim_nm])
                            xdpLogger('xDP-INF-010',comment='Done File moved successfully: {}'.format(ok_file_nm))
                            xdpLogger('xDP-INF-010',comment='interim File removed successfully: {}'.format(full_ok_file_interim_nm))
                        except Exception as e:
                            xdpLogger('xDP-WAR-040',comment='Done File moved failed: {}'.format(ok_file_nm))
                            xdpLogger('xDP-ERR-117',comment=e)
                    else:
                        xdpLogger('xDP-ERR-117',comment='Error while creating .completed file: {}'.format(ok_file_nm))
            
                except Exception as exp:
                    xdpLogger('xDP-ERR-117',comment=exp)
                    spark.stop()
                    sys.exit(0)
            else:
                if k < retries-1 :
                    print("INActive Data load process for {cde_process}.{PROCESS_TABLE} has failed.... retrying the operation".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))                
                    xdpLogger('xDP-INF-018',comment="InActive Data load process for {cde_process}.{PROCESS_TABLE} has failed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                    continue
                else:
                    print("Exception while overwriting table {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
                    list_2 = (snap_dt,str(BATCH_DATE).replace('-',''),file_nm,JOB_NAME,'ProcessLayerLoad', CDE_PROCESS+'.'+PROCESS_TABLE_NAME, 'Fail',str(datetime.now())[:-7],application_id,date.today())
                    fail_list.append(list_2)
                    writeStatus2FileIngestion(fail_list,spark)
                    xdpLogger('xDP-ERR-117',comment='Exception while appending inactive partition in table {cde_process}.{PROCESS_TABLE}.Check pre data cut required for update.'.format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME)) 
                    spark.stop()
                    sys.exit(1)
            break


        '''
        Refreshing final table partition
        ''' 

        spark.sql("ALTER TABLE {cde_process}.{PROCESS_TABLE} RECOVER PARTITIONS".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))

        '''
        Dropping temporary table
        '''

        spark.sql("DROP TABLE IF EXISTS {cde_process}.{PROCESS_TABLE}_TMP".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))

        '''
        updating source batch control  table for cde batch
        '''
        spark.sql("""INSERT INTO TABLE {cde_control}.SOURCE_BATCH_CONTROL_TABLE 
                    PARTITION (LOAD_DATE)
                    SELECT
                        '{file_name}', 
                        '{brand}', 
                        '{db_name}', 
                        '{table_name}',
                        '{batch_dt}',
                        {batch_id},
                        'S' as status, 
                        current_timestamp()  as load_datetime,
                        current_date()
                    """.format(cde_control=CDE_CONTROL,file_name=file_nm,brand=SYSPARM,db_name=CDE_PROCESS,table_name=PROCESS_TABLE_NAME,batch_dt=BATCH_DATE,batch_id=BATCH_ID))

        xdpLogger('xDP-INF-014',comment="CDER sourcing data loading process for feed {FEED_NAME} till cde_process layer has completed".format(FEED_NAME=file_nm))

    spark.stop()

if __name__ == "__main__":
    """ 
    Description: This is the entry point for execution of this script.
    The steps in sequence define the logical flow of the code
    """
    main()
