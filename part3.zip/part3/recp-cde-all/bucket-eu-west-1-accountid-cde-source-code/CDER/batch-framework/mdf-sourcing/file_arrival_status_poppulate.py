#!/usr/bin/env python
# -*- coding: utf-8 -*- 
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession
from datetime import timedelta, datetime, date
from pyspark.sql import Window
from pyspark.sql.functions import *
from config import setup_module_config_path
from pyspark.sql import functions
from pyspark.sql import functions as f
from pyspark.sql.types import *
#from new import *
#import botocore.session
from pyspark.sql.functions import lit
from pyspark.sql.utils import CapturedException
import sys
import subprocess
import multiprocessing as mp
import re
import os
import fnmatch
import hashlib
import codecs
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import get_logger,create_logger,xdpLogger
import csv, codecs, json
import traceback
mount_path = "/mnt/cksum_cde/"
from File_Column_count_dict import File_Expected_Column_count
#file_arrival_status = 'cde_control.file_arrival_status_nj'
#file_ingestion_detail = 'cde_control.file_ingestion_detail_nj'

def list_s3_file_details(file_path):
        """Description: This function lists all details of the file present in the landing zone path
        :param file path of the landing zone
        :return the list of file details
        """
        try:
            get_logger()
            file_ls = subprocess.check_output(['aws', 's3', 'ls', file_path])
            
            file_split= file_ls.decode().split('\n')
            file_list = []
            [file_list.append(re.split(' +', i)) for i in file_split]
            valid_list=[]
            print("file_list is ----------", file_list)
            reject_list=[]
            for i in file_list :
                if len(i) < 4 :
                    reject_list.append(i)
                else :
                    valid_list.append(i)
            xdpLogger('xDP-INF-001',comment='Valid file list'.format(str(valid_list)))
            xdpLogger('xDP-INF-001',comment='Rejected file list'.format(str(reject_list)))
            return valid_list
            
        
        except Exception as e:
            tb = traceback.format_exc()
            print(tb)
            xdpLogger('xDP-ERR-117',comment=e)
            spark.stop() #Changes for Jira::WMIT-5794 | graceful exit
            sys.exit(0)


def filterOutDups(file_df):
    """ this function filters out  files which already have entry in file_arrival_status based on
        [file_nm,business_date ,arrival_date, arrival_time] but could not be processed before,
        in order to avoid duplicate entries in file_arrival_status table  """
    get_logger()
    xdpLogger('xDP-INF-001')
    file_list = file_df.collect()
    if len(file_list) == 0:
        xdpLogger('xDP-WAR-031',comment='No new files at landing zone to process')
        sys.exit(0)
    query = "select * from {}".format(job_option_config.file_arrival_status)
    status_df = spark.sql(query)

    join_condition = [file_df["file_nm"]==status_df["file_nm"],file_df["arrival_date"]==status_df["arrival_date"],file_df["arrival_time"]==status_df["arrival_time"]]
    to_be_processed_df = file_df.join(status_df,join_condition,"left_anti")
    return to_be_processed_df

def delimiter_check(mount_path,file_name,Expected_col_count):
    mnt_file_loc=mount_path+file_name
    print(mnt_file_loc)
### Remove header and Trailor from mount file
    MV_CMD ="sudo sed -i '1d;$d;s/\r//g' " + mnt_file_loc
    os.system(MV_CMD)
    file1 = open(mnt_file_loc,'r',encoding='latin-1')     
    while True: 
        line = file1.readline()   
        if not line: 
            break
        delimiter_count=line.count('\u001F')
        if (delimiter_count==Expected_col_count-1):
            continue
        else:
            print("deleimiter found in Data")
            return False
    
    return True

def get_spark():
    """
    Get a spark session for processiong
    """
    new_spark = SparkSession \
    .builder \
    .appName("XDP_FileIngestion") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .enableHiveSupport() \
    .config("spark.sql.broadcastTimeout", "3600") \
    .config("spark.dynamicAllocation.executorIdleTimeout ", "300").enableHiveSupport() \
    .getOrCreate()
    new_spark.sparkContext.setLogLevel("ERROR")
    return new_spark

if __name__=="__main__":
    """Description: This is the entry point for execution of this script
       The steps in sequence define the logical flow of the code
    """
    #landing_zone_path = 's3://bucket-eu-west-1-897144472116-user/data_support_cde/namit/Landing_Zone_Data/'
    try:
        create_logger("CDE_INGESTION_FILE_ARRIVAL_STATUS")
        spark=get_spark()
        sc = spark.sparkContext
        spark.sparkContext.setLogLevel("ERROR")
        xdpLogger('xDP-INF-001')
        conflist = spark.sparkContext.getConf().getAll()
        for i in conflist:
            if 'spark.app.id' in i[0]:
                application_id = i[1]


        #btch_date query
        #batch_date_sql = "select batch_date from {}".format(job_option_config.sourcing_batch_id_control)
        #batch_date_detail = spark.sql(batch_date_sql)
        #batch_date = str(batch_date_detail.collect()[0][0]).replace('-','')
        #mainframe master info
        mainframe_master_sql = "select * from {}".format(job_option_config.cder_mainframe_sourcing_master)
        mainframe_master_df = spark.sql(mainframe_master_sql)

        file_list_raw = list_s3_file_details(job_option_config.landing_zone)
        print(file_list_raw)
        file_list_raw_df = sc.parallelize(file_list_raw).toDF(['arrival_date', 'arrival_time', 'file_size', 'file_nm'])
        file_list_df = filterOutDups(file_list_raw_df)
        file_list_df = file_list_df.orderBy('arrival_time')
        file_size_agg = file_list_df.agg(f.sum('file_size')).collect()[0][0]
        file_size_agg = int(file_size_agg/1073741824)
        capable_file_size = int(job_option_config.file_transfer_size)
        if (file_size_agg > capable_file_size):
            file_size_list = file_list_df.select("file_size").collect()
            curr_size = 0
            no_of_rec = 0
            for row in file_size_list:
                curr_val = int(int(row[0])/1073741824)
                if ((curr_size + curr_val) > capable_file_size):
                    break
                curr_size = curr_size + curr_val
                no_of_rec = no_of_rec + 1
            file_list_df.createOrReplaceTempView("file_list_df")
            print("curr_size", curr_size, "no_of_rec", no_of_rec)
            file_list_df = spark.sql("select * from file_list_df order by arrival_time asc limit {}".format(no_of_rec))
        #########################################
        file_list_df = file_list_df.withColumn('file_nm_val', f.split(col('file_nm'),'\\.')[0])
        file_list_df = file_list_df.withColumn('file_nm_join', f.concat('file_nm_val', lit('.CSV'))).drop('file_nm_val')

        file_list_df = file_list_df.join(mainframe_master_df, [file_list_df["file_nm_join"]==mainframe_master_df["file_name"]], 'left')
        #file_list_df = file_list_df.withColumn('arrival_hour',f.split('arrival_time',':')[0]).withColumn('change_batch_dt',when((col('arrival_hour')>=job_option_config.batch_range_start) & (col('arrival_hour')<=job_option_config.batch_range_end),"Y").otherwise("N"))

        file_list_df = file_list_df.withColumn('file_size_bytes', round(col('file_size')/10576,4)).drop(col('file_size')).withColumnRenamed('file_size_bytes', 'file_size').withColumnRenamed('job_name', 'file_prefix').withColumn('file_status', lit('ARRIVED')).withColumn('application_id',lit(application_id)).withColumn('run_dt', lit(date.today()))

        if file_list_df.count() == 0:
            xdpLogger('xDP-INF-025',comment='No files at landing zone to process')
            spark.stop() #Changes for Jira::WMIT-5794 | graceful exit
            sys.exit(0)


        #checksum calculation
        name_cksum_list = []
        fail_list=[]
        pass_list=[]
        for file_item in file_list_df.collect():
            file_name = file_item['file_nm']
            print(job_option_config.landing_zone+file_name)
            if file_name == '' or '.CSV' not in file_name.upper():
                continue
            file_prefix = file_item['file_prefix']
            if file_prefix is None or file_prefix == '':
                xdpLogger('xDP-WAR-043',comment='Invalid file {} placed at landing zone'.format(file_name))
                continue
            FILE_DATE = ''
            a = subprocess.call(['sudo', 'aws', 's3', 'cp', job_option_config.landing_zone+file_name, mount_path])
            if a ==0:
                xdpLogger('xDP-INF-010',comment='File {} coppied to mount folder'.format(file_name))
            else:
                xdpLogger('xDP-WAR-040',comment='File {} movement to mount folder failed'.format(file_name))
                continue

            try:
                print("checksum started")
                cksum_result = subprocess.check_output(['cksum',mount_path+file_name])
                if len(cksum_result) > 0:
                    cksum_result_split = cksum_result.decode().split(' ')
                    cksum_value = cksum_result_split[0]
            except CapturedException as exp:
                xdpLogger('xDP-ERR-117',comment='Error while calculating checksum')
                xdpLogger('xDP-ERR-117',comment=exp)
                spark.stop()
                sys.exit(1)

            try:
                out=subprocess.Popen(['head', '-n', '1', '{mount_loc}{file_name}'.format(mount_loc=mount_path,file_name=file_name)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT)
                stdout,stderr = out.communicate()
                print(stdout)
                print(stderr)
                if re.search(r'\d{4}-\d{2}-\d{2},\d{2}:\d{2}:\d{2}', str(stdout)):
                    FILE_DATE=re.search(r'\d{4}-\d{2}-\d{2},\d{2}:\d{2}:\d{2}', str(stdout)).group().replace(',',' ')
                    FILE_DATE = FILE_DATE.replace('-','')
                elif re.search(r'\d{4}-\d{2}-\d{2}', str(stdout)):
                    FILE_DATE=re.search(r'\d{4}-\d{2}-\d{2}', str(stdout)).group()
                    FILE_DATE = FILE_DATE.replace('-','')
                elif re.search(r'\d{8}', str(stdout)):
                    FILE_DATE=re.search(r'\d{8}', str(stdout)).group()
                else:
                    FILE_DATE= str(stdout)

    
                if re.search(r'\d{2}:\d{2}:\d{2}', str(stdout)):
                    FILE_TIME=re.search(r'\d{2}:\d{2}:\d{2}', str(stdout)).group()
                else:
                    FILE_TIME = ''

            except CapturedException as exp:
                xdpLogger('xDP-ERR-117',comment=exp)
                spark.stop()
                sys.exit(1)
#####################################Delimiter Check on File   #######################################################
            file_prefix_nm=file_name.split('.CSV')[0]
            if file_prefix_nm in File_Expected_Column_count.keys():
                column_count=File_Expected_Column_count[file_prefix_nm]
                print("Expected Col Count :",column_count)
                delim_check_flag=delimiter_check(mount_path,file_name,column_count)
                if delim_check_flag:
#                    pass_list.append([file_name,cksum_value,FILE_DATE,FILE_TIME])
                    pass_list.append([file_name,file_prefix_nm])
                else:
#                    fail_list.append([file_name,cksum_value,FILE_DATE,FILE_TIME])
                    fail_list.append([file_name,file_prefix_nm])
                    source = job_option_config.landing_zone+file_name
                    target = job_option_config.rejected_zone+file_name
                    xdpLogger('xDP-ERR-117',comment=file_name+" has delimiter in data")
                    try:
                        copy_to_rejected = subprocess.call(['aws','s3','mv', source, target])
                    except Exception as e:
                        print("Error while copying an extra Delimiter containing file :  ",e)
                        xdpLogger('xDP-ERR-117',comment="Error while copying an extra Delimiter containing file : "+e)
                        sys.exit(1)
            else:
                print("Table Not delimited, No Schema Check required")         
######################################################################################################################
            name_cksum_list.append([file_name,cksum_value,FILE_DATE,FILE_TIME])

            try:
                rm_file_flag = subprocess.call(['rm',mount_path+file_name])
                if rm_file_flag == 0:
                    xdpLogger('xDP-INF-010',comment='File removed successfully from mount location,File is {}'.format(file_name))
                else:
                    xdpLogger('xDP-ERR-117',comment='Error while removing file to mount location')
                    sys.exit(0)

            except CapturedException as exp:
                spark.stop()
                sys.exit(1)

        xdpLogger('xDP-DBG-001', comment='File checksum list: {}'.format(str(name_cksum_list)))
        xdpLogger('xDP-DBG-001', comment='File Delimiter Check Fail list: {}'.format(str(fail_list)))
        xdpLogger('xDP-DBG-001', comment='File Delimiter Check Pass list: {}'.format(str(pass_list)))


        if len(name_cksum_list)>0:
            name_cksum_list_df = sc.parallelize(name_cksum_list).toDF(['file_nm', 'cksum_value','snap_dt','file_creation_time'])
            file_list_cksum_df = name_cksum_list_df.join(file_list_df,['file_nm'],'left').select("snap_dt","src_sys","file_nm","cksum_value","arrival_date","arrival_time","file_size","file_prefix","file_status","application_id","run_dt","file_creation_time")
            file_list_cksum_df = file_list_cksum_df.withColumn('arrival_or_creation',when(col('file_creation_time')=='',"ARRIVAL").otherwise("CREATION"))
            file_list_cksum_df = file_list_cksum_df.withColumn('arrival_hour',when(col('arrival_or_creation')=='ARRIVAL',f.split('arrival_time',':')[0]).otherwise(f.split('file_creation_time',':')[0])).withColumn('change_batch_dt',when((col('arrival_hour')>=job_option_config.batch_range_start) & (col('arrival_hour')<=job_option_config.batch_range_end),"Y").otherwise("N"))
            file_list_cksum_df = file_list_cksum_df.withColumn('batch_dt',when((col('change_batch_dt')=='Y') & (col('src_sys')=='MDF'),date_format(date_sub(to_date(col("snap_dt"),"yyyyMMdd"),job_option_config.batch_dt_delta),"yyyyMMdd").cast('int')).otherwise(col('snap_dt')))
            file_list_cksum_df = file_list_cksum_df.select("snap_dt","batch_dt","file_nm","cksum_value","arrival_date","arrival_time","file_size","file_prefix","file_status","application_id","run_dt")

            for file_item in file_list_cksum_df.collect():
                snap_dt = file_item['snap_dt']
                batch_dt = file_item['batch_dt']
                file_prefix = file_item['file_prefix']
                try:
                    ok_file_nm = file_prefix+'_'+str(snap_dt)+'_'+str(batch_dt)+'_ARRIVED.ok'
                    arrived_file = subprocess.call(['touch', ok_file_nm])
                    if arrived_file == 0:
                        xdpLogger('xDP-INF-010',comment='ok file {} generated'.format(ok_file_nm))
                        try:
                            copy_to_s3 = subprocess.call(['aws','s3','mv', ok_file_nm, job_option_config.done_file_location])
                        except Exception as e:
                            xdpLogger('xDP-ERR-117',comment=e)
                    else:
                        xdpLogger('xDP-ERR-117',comment='Error while creating arrived file')
                        sys.exit(0)
                except CapturedException as exp:
                    xdpLogger('xDP-ERR-117',comment=exp)
                    spark.stop()
                    sys.exit(1)


            file_ingestion_df = file_list_cksum_df.withColumn('action_type', lit('File Arrival')).withColumn('action_typ_details',lit('File Arrived')).withColumn('status',lit('Pass')).withColumn('time',lit(str(datetime.now())[:-7])).withColumn('application_id',lit(application_id)).select("snap_dt","batch_dt","file_nm","file_prefix","action_type","action_typ_details","status","time","application_id","run_dt")
            #file_ingestion_df.show()

            #write to file ingestion table
            #file_ingestion_df.show()
            file_ingestion_df.write.mode('append').insertInto(job_option_config.file_ingestion_detail,overwrite=False) #defined above, to be pulled via app config
            xdpLogger('xDP-INF-111',comment='Status updated in File Ingestion detail table')

            #write to file arrival status table
            file_list_cksum_df.write.mode('append').insertInto(job_option_config.file_arrival_status,overwrite=False)
            xdpLogger('xDP-INF-111',comment='Status updated in File Arrival Status table')
            xdpLogger('xDP-INF-999')
        else:
            xdpLogger('xDP-INF-025',comment='No valid files at landing zone to process')
            spark.stop() #graceful exit
            sys.exit(0)
            # #write to Delimited Check status to File Ingestion
        if len(pass_list)>0:
            name_cksum_pass_list_df = sc.parallelize(pass_list).toDF(['file_nm','file_prefix_nm'])
            file_list_pass_df = name_cksum_pass_list_df.join(file_list_cksum_df,['file_nm'],'left').select("snap_dt","batch_dt","file_nm","file_prefix_nm").withColumn('run_dt',lit(date.today()))
            file_ingestion_df_delim_pass_chk = file_list_pass_df.withColumn('action_type', lit('DelimiterCheck')).withColumn('action_typ_details',lit('Delimiter Count Validated')).withColumn('status',lit('Pass')).withColumn('time',lit(str(datetime.now())[:-7])).withColumn('application_id',lit(application_id)).select("snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt")
            file_ingestion_df_delim_pass_chk.write.mode('append').insertInto(job_option_config.file_ingestion_detail,overwrite=False)
            xdpLogger('xDP-INF-111',comment='Status updated in File Ingestion detail table')
        if len(fail_list)>0:
            name_cksum_fail_list_df = sc.parallelize(fail_list).toDF(['file_nm','file_prefix_nm'])
            file_list_fail_df = name_cksum_fail_list_df.join(file_list_cksum_df,['file_nm'],'left').select("snap_dt","batch_dt","file_nm","file_prefix_nm").withColumn('run_dt',lit(date.today()))
            file_ingestion_df_delim_fail_chk = file_list_fail_df.withColumn('action_type', lit('DelimiterCheck')).withColumn('action_typ_details',lit('Delimiter Count Validated')).withColumn('status',lit('Fail')).withColumn('time',lit(str(datetime.now())[:-7])).withColumn('application_id',lit(application_id)).select("snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt")
            file_ingestion_df_delim_fail_chk.write.mode('append').insertInto(job_option_config.file_ingestion_detail,overwrite=False)
            xdpLogger('xDP-INF-111',comment='Status updated in File Ingestion detail table')

    except Exception as e:
        xdpLogger('xDP-ERR-117',comment=e)
        spark.stop()
        sys.exit(1)
