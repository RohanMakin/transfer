from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import *
import sys
import os
import re
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import create_logger, xdpLogger
import subprocess
from datetime import datetime, timedelta
import pandas as pd
import update_running_status


def main():
    spark = SparkSession \
    .builder \
    .appName("CDE_EDH_DATA_INGESTION") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate() 
    
    #  /home/hadoop/cde/CDER/batch-framework/mdf-sourcing/edh_stg_to_main_load.py cde_process.ava_agreement_ss_stg cde_process.ava_agreement_ss 
    awsStgDbTableName = sys.argv[1]
    awsDbTableName = sys.argv[2]

    print ("awsStgDbTableName: " + awsStgDbTableName)
    print ("awsDbTableName: " + awsDbTableName)

    
    flow_name = "CDE_EDH_DATA_INGESTION"
    job_name = "EDH_STG_TO_MAIN_LOAD"
	
    ts_start = pd.Timestamp('today')
    spark.sparkContext.setLogLevel("ERROR")
    create_logger('EDH_STG_TO_MAIN_LOAD')
    xdpLogger('xDP-INF-013',comment="Job has started")	

    #Update start time
    try:
        update_running_status.update_start_time(spark,awsDbTableName,flow_name,ts_start)
    except Exception as e:
        xdpLogger('xDP-WAR-005',comment=e) 	
    
    stgToMainQuery="""INSERT OVERWRITE TABLE {AWSDBTABLENAME}
           SELECT * FROM {AWSSTGDBTABLENAME}
    """.format(AWSSTGDBTABLENAME=awsStgDbTableName,AWSDBTABLENAME=awsDbTableName)
   
    print("stgToMainQuery : " + stgToMainQuery)    
   
    try:
        xdpLogger('xDP-INF-019',comment="Data movement from {AWSSTGDBTABLENAME} to {AWSDBTABLENAME} about to start.".format(AWSSTGDBTABLENAME=awsStgDbTableName,AWSDBTABLENAME=awsDbTableName))
        spark.sql("SET spark.sql.hive.caseSensitiveInferenceMode=INFER_ONLY")
        spark.sql(stgToMainQuery)
        xdpLogger('xDP-INF-020',comment="Data movement from {AWSSTGDBTABLENAME} to {AWSDBTABLENAME} about to start.".format(AWSSTGDBTABLENAME=awsStgDbTableName,AWSDBTABLENAME=awsDbTableName))
    except Exception as e:
        print("Exception while executing the query: {stgToMainQuery}.".format(stgToMainQuery=stgToMainQuery))
        print("EXCEPTION :",str(e)) 
        xdpLogger('xDP-ERR-111',comment=e) 
        sys.exit(1)    
    
    ts_end = pd.Timestamp('today')
    try:
        update_running_status.update_end_time(spark,awsDbTableName,flow_name,ts_end)
    except Exception as e:
        xdpLogger('xDP-WAR-005',comment=e)
    xdpLogger('xDP-INF-014',comment="Job has completed") 

    spark.stop()


if __name__ == "__main__":
    """ 
    Description: This is the entry point for execution of this script.
    The steps in sequence define the logical flow of the code
    """
    main()
