from pyspark.sql import SparkSession
import sys
import os
import re
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import create_logger, xdpLogger


def main():
    spark = SparkSession \
    .builder \
    .appName("UPDATE SOURCING BATCH ID") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate()

    spark.sparkContext.setLogLevel("ERROR")

    ###   /*********************************************************************************** 
    ###   * Job:             UPDATE_SOURCING_BATCH_ID                                        * 
    ###   * Description:     INCREMENT SOURCING BATCH ID CONTROL TABLE DATA BY 1             *
    ###   *                  SOURCING_BATCH_ID_CONTROL_TABLE WILL CONTAIN ONLY 1 ROW         * 
    ###   * Created by:      Divya Shukla(shuksda)/Accenture                                 *
    ###   ************************************************************************************/   

    create_logger('UPDATE_SOURCING_BATCH_ID')
    xdpLogger('xDP-INF-013',comment="Process for updating source batch control table has started")

    control_db = job_option_config.cde_databases["CONTROL"] 
    sourcing_batch_control_table = 'SOURCING_BATCH_ID_CONTROL_TABLE' 

    insert_query="""
                    INSERT OVERWRITE TABLE {db_name}.{table_name}
                    SELECT
                        RBS_BATCH_ID + 1 AS  RBS_BATCH_ID, 
                        NWB_BATCH_ID + 1 AS  NWB_BATCH_ID, 
                        UBN_BATCH_ID + 1 AS  UBN_BATCH_ID,
                        UBR_BATCH_ID + 1 AS  UBR_BATCH_ID,
                        GRP_BATCH_ID + 1 AS  GRP_BATCH_ID,
                        case when (substring(current_timestamp ,12,2) >= 20 and substring(current_timestamp ,12,2) <= 23) then CURRENT_DATE() else date_add(CURRENT_DATE(),-1) end AS BATCH_DATE
                    FROM 
                        {db_name}.{table_name}
                 """.format(db_name=control_db,table_name=sourcing_batch_control_table)

    try:
        spark.sql(insert_query)
    except Exception as e: 
        print("Exception while inserting into control table {db_name}.{table_name}".format(db_name=control_db,table_name=sourcing_batch_control_table))
        print("EXCEPTION :",str(e))   
        xdpLogger('xDP-ERR-115',comment=e)
        sys.exit(1)  

    xdpLogger('xDP-INF-014',comment="Process for updating source batch control table has completed")

    spark.stop()


if __name__ == "__main__":
    """ Description: This is the entry point for execution of this script. 
        The steps in sequence define the logical flow of the code 
    """
    main()