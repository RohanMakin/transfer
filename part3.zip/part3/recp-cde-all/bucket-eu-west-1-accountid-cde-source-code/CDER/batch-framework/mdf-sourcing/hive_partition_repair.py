import subprocess


def tables_repair_command(database):
    cmd = """hive -e "use {db}; show tables" """.format(db=database)
    file_check_process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    file_check_process.wait()

    tables_list = ["msck repair table {db}.{table};".format(db=database, table=x) for x in file_check_process.communicate()[0].splitlines()]

    return tables_list


def trigger_repair_command(hive_command):
    repair_table_cmd = """hive -e "{cmd}" """.format(cmd=" ".join(hive_command))
    repair_process = subprocess.Popen(repair_table_cmd, shell=True, stdout=subprocess.PIPE)
    repair_process.wait()

    return repair_process.returncode


def repair_partitions():
    databases_list = ["CDE_BAC_RISK_DECISIONING_MART", "CDE_WHD01_TAC_DB01_DATA"] #Add DB Names as required
    for database in databases_list:
        tables_repair_hive_command = tables_repair_command(database)
        return_code = trigger_repair_command(tables_repair_hive_command)
        if return_code == 0:
            print("Repair Completed for DB {db} sucessfully".format(db=database))
        else:
            print("Something went wrong while repairing DB")


if __name__ == '__main__':
    repair_partitions()
