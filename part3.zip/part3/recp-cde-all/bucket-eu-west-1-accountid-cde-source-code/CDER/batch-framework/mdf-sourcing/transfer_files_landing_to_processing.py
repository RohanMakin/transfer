from pyspark.sql.functions import *
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession
import os
import subprocess
import re
import sys
from datetime import datetime, date
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import get_logger,create_logger,xdpLogger
import socket
#from shared.aws import get_listofObject_at_path
from operator import itemgetter
import botocore.session
import math
import collections
from pyspark.sql import functions as f
from pyspark.sql.utils import CapturedException
import time


def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return botocore.session.get_session().create_client('s3')


def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key


def get_spark():
    """
    Get a spark session for processiong
    """
    #new_spark = SparkSession.builder.master("yarn").config('hive.exec.dynamic.partition.mode', 'nonstrict').enableHiveSupport().getOrCreate()
    new_spark = SparkSession \
    .builder.master("yarn") \
    .appName("Transfer_Files") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config("spark.sql.broadcastTimeout", "3600") \
    .config("spark.dynamicAllocation.executorIdleTimeout ", "300").config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate()
    new_spark.sparkContext.setLogLevel("ERROR")
    return new_spark



def extractConfigInfo(size):
    """Description : This function will return memory and core required to process a specific size (which we will receive as input) 
    And reference table xdp_spark_config_table will be used to get required info
    """
    try:
        get_logger()
        size_ingb = size/1073741824
        fetch_configinfo_query = "select label,lowerbound,upperbound,coresperexecutor,numofexec,executormem,drivermem,executoroverheadratio,driveroverheadratio from {}".format(job_option_config.spark_config_tbl) # defined above | to be used from app config
        xdpLogger('xDP-INF-009',comment='Query to fetch Spark Params : {}'.format(fetch_configinfo_query))
        df_fetch_configinfo = spark.sql(fetch_configinfo_query) #Changes for Jira::WMIT-5794 | to reduce number of partitions in dataframe
        if len(df_fetch_configinfo.head(1)) == 0 :
           xdpLogger('xDP-ERR-117',comment='Spark config not provided in control table')
           spark.stop # graceful exit with spark stops -WMIT-5794
           sys.exit(1)
        else :
             configinfo_list = df_fetch_configinfo.collect()

        for value in configinfo_list :
            if size_ingb >= int(value[1]) and size_ingb < int(value[2]) :
                label = value[0]
                print("label -------",label)
                exememoverhead = value[7] * int(str(value[5]).replace('g','').replace('G',''))
                drivermemoverhead = value[8] * int(str(value[6]).replace('g','').replace('G',''))
                memforfile = int(math.ceil((int(value[4]) * (int(str(value[5]).replace('g','').replace('G',''))) + (exememoverhead)) + ((int(str(value[6]).replace('g','').replace('G',''))) + (drivermemoverhead))))
                coresforfile = (int(value[3]) * int(value[4])) + 1
                # for drivercore default value 1 has been added in above line
                break
        print("inside extractconfig",memforfile,coresforfile)
        return memforfile,coresforfile

    except Exception as e:
        xdpLogger('xDP-ERR-117',comment=e)
        spark.stop()            
        sys.exit(1)

def extractClusterInfo(h_name):
    """ Description : This function will receive resource manager host name (194-208-10-6) as input 
    And will return Available Memory and available cores for resource manager 
    """
    try:
        new_env = dict(os.environ)
        new_env['LC_ALL'] = 'C'
        cluster_string = 'http://ip-' + h_name + ':8088/ws/v1/cluster/metrics'
        dict_result = eval(subprocess.check_output(['GET',cluster_string],env=new_env))
        availMem_glob = dict_result['clusterMetrics']['availableMB']
        availCores_glob=dict_result['clusterMetrics']['availableVirtualCores']
        totalCores_glob=dict_result['clusterMetrics']['totalVirtualCores']
        totalMB_glob = dict_result['clusterMetrics']['totalMB']

        return availMem_glob,totalMB_glob,availCores_glob,totalCores_glob
    except Exception as e:
        xdpLogger('xDP-ERR-117',comment=e)
        spark.stop()
        sys.exit(1)



def writeStatus2FileIngestion(input_list):
        try:
                get_logger()
                sc = spark.sparkContext
                result_df = sc.parallelize(input_list).toDF(["snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt"]).select("snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt")
                if result_df.count()>0:
                    result_df.write.mode('append').insertInto(job_option_config.file_ingestion_detail,overwrite=False)
                    xdpLogger('xDP-INF-111',comment='Status updated in File Ingestion detail table')
                    return True
        except Exception as e:
                xdpLogger('xDP-ERR-117',comment='Error while updating File Ingestion detail table')
                xdpLogger('xDP-ERR-117',comment=e)
                pass




def moveFile(file_name, source_file_dir, dest_file_path):
    """Description: This function moves files from source path to destination path
    :param file name of the files to be moved
    :param source path of the files to be moved from
    :param destination path of the files to be moved into
    :return
    """
    get_logger()
    xdpLogger('xDP-INF-001')
    source_file_path = "%s%s" %(source_file_dir, file_name)
    try:
        a = subprocess.call(['aws', 's3', 'mv', source_file_path, dest_file_path])
        if a == 0:
            xdpLogger('xDP-INF-010',comment="File moved successfully,File name: {}".format(file_name))
            return True
        else:
            xdpLogger('xDP-WAR-031',comment="File name{} is not valid or doesnt exist ".format(file_name))
            return False
            spark.stop()
            sys.exit()
    except Exception:
        xdpLogger('xDP-WAR-040',comment="File movement call failed,File name: {}".format(file_name))
        xdpLogger('xDP-ERR-117',comment=exp)
        return False

def get_listofObject_at_path(filepath):
    """
    retrieve files object present at S3 path
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)

    objects = client.list_objects(Bucket=bucket, Prefix=key)
    list_objects = objects['Contents']
    return list_objects



def extractFileProcessingList(valid_file_list,df_file_details):
    """ Description : This function will receive a list of files which are ready to move from Landing Zone to Processing Zone
    And will return list of files which will be moved at end from Landing to Processing Zone.
    To decide which files should move, cluster capacity is being considered and ordering is done based on  file_priority and arrival_time
    """
    try:
        get_logger()
        host_name = subprocess.check_output(['hdfs', 'getconf', '-confKey', 'yarn.resourcemanager.hostname']).decode().replace('\n','').replace('.','-')
        print(host_name)
        availablemem_glob,totalMB_glob,availableCores_glob,totalCores_glob = extractClusterInfo(host_name)
        availablemem_glob_gb = int(availablemem_glob) / 1024
        totalMB_glob_gb = int(totalMB_glob) / 1024
        xdpLogger('xDP-INF-111',comment='Available mem glob gb: {} total mb glob gb: {} available coresglob: {} totalcores glob: {}'.format(availablemem_glob_gb,totalMB_glob_gb,availableCores_glob,totalCores_glob))

        pending_threshold = job_option_config.cluster_max_capacity - totalMB_glob_gb
        pending_cores = job_option_config.cluster_max_core -  totalCores_glob
        xdpLogger('xDP-INF-111',comment='Pendeing Threshold: {} Pendig Cores: {}'.format(pending_threshold,pending_cores))

        peak_mem_limit = pending_threshold + availablemem_glob_gb
        peak_core_limit = pending_cores + availableCores_glob
        xdpLogger('xDP-INF-111',comment='Available stats {} {} {} {}'.format(pending_threshold,pending_cores,peak_mem_limit,peak_core_limit))

        try:
            listOfobjects = get_listofObject_at_path(job_option_config.landing_zone)
        except KeyError:
            xdpLogger('xDP-INF-111',comment="No files in Landing Zone")
            spark.stop()
            sys.exit(0)
        except Exception as exp:
            xdpLogger('xDP-ERR-117',comment=e)
            spark.stop()
            sys.exit(1)

        listOfobjects_filtered = [i for i in listOfobjects if i['Key'].split('/')[-1] in valid_file_list]
        xdpLogger('xDP-INF-111',comment='Valid file list after filter is {}'.format(str(listOfobjects_filtered)))

        priority_info_query = "select file_name from {} where upper(priority_flag) = 'Y' ".format(job_option_config.cder_mainframe_sourcing_master)
        df_priority_info = spark.sql(priority_info_query)
        #df_priority_info.show()
        priority_info_list = [row.file_name for row in df_priority_info.collect()]


        #print("priority_info_list ", priority_info_list)
        listOfobjects_p = [i for i in listOfobjects_filtered if (i['Key'].split('/')[-1]) in priority_info_list]
        listOfobjects_np = [i for i in listOfobjects_filtered if (i['Key'].split('/')[-1]) not in priority_info_list]

        listOfobjects_p_sorted = sorted(listOfobjects_p, key = itemgetter('LastModified'))
        xdpLogger('xDP-INF-111',comment='List of Priority files to be processed: {}'.format(str(listOfobjects_p_sorted)))
        listOfobjects_np_sorted = sorted(listOfobjects_np, key = itemgetter('LastModified'))
        xdpLogger('xDP-INF-111',comment='List of Non Priority files to be processed: {}'.format(str(listOfobjects_np_sorted)))
        listOfobjects_filtered_sorted = listOfobjects_p_sorted + listOfobjects_np_sorted
        xdpLogger('xDP-INF-111',comment='Final list of Files to be processed: {}'.format(str(listOfobjects_filtered_sorted)))

        #listOfobjects_sorted = sorted(listOfobjects_filtered, key = itemgetter('LastModified'))
        #print("sorted list", listOfobjects_sorted)

        processing_list_max_size=[]
        for object in listOfobjects_filtered_sorted :
            size = (object['Size'])
            name = (object['Key']).split('/')[-1]
            print("name - ",name,"size - ",size)
            print("Available Memory : {}  ,AvailableCores : {} , Peak memory limit : {} , Peak core limit : {} , when picking file name : {} ".format(availablemem_glob_gb,availableCores_glob,peak_mem_limit,peak_core_limit,name))
            if peak_mem_limit > 2 and peak_core_limit > 2 :
                memforfile,coreforfile = extractConfigInfo(size)
                print("mem and core for file are -", memforfile,coreforfile)
                peak_mem_limit = peak_mem_limit - int(memforfile)
                peak_core_limit = peak_core_limit  - int(coreforfile)
                availablemem_glob_gb = availablemem_glob_gb - int(memforfile)
                availableCores_glob = availableCores_glob - int(coreforfile)

                if peak_mem_limit > 0 and peak_core_limit > 0: 
                    processing_list_max_size.append(name)
                else :
                    xdpLogger('xDP-INF-111',comment="Memory not available in the cluster,file{} would be picked in next iteration of File or DAG run".format(name)) 
                    peak_mem_limit = peak_mem_limit + int(memforfile)
                    peak_core_limit = peak_core_limit  + int(coreforfile)
                    availablemem_glob_gb = availablemem_glob_gb + int(memforfile)
                    availableCores_glob = availableCores_glob + int(coreforfile)
                    continue
            else :
                xdpLogger('xDP-INF-111',comment="Memory not available in the cluster for processing file {} attempting the next set of files in the list".format(name))
                continue
        xdpLogger('xDP-INF-111',comment="Processing List of files a/q to max size : {}".format(str(processing_list_max_size)))
        #final_proc_list = []
        #for x in processing_list_max_size:
            #final_proc_list.append((x['Key']).split('/')[-1])

        #print("Processing List of files  : {} ".format(final_proc_list))
        #print(final_proc_list)
        return processing_list_max_size



    except Exception as e:
        xdpLogger('xDP-ERR-117',comment=e)

        spark.stop()
        sys.exit(1)
#CDER-5722 Adding hold on 
def get_hold_file_status(file_prefix_nm):
    """
    retrive file timestamp and hold if required
    """ 
    t = time.localtime()
    current_time = time.strftime("%H:%M:%S", t)

    if file_prefix_nm=='GRP_TSYS_NCARDS_BALS':
        start_time=job_option_config.start_time_tsys
        end_time=job_option_config.end_time_tsys

    elif (file_prefix_nm=='JUBUK_DEBITCARD_NPCB006_PARTEXTR' or file_prefix_nm=='KUBIE_DEBITCARD_NPCB006_PARTEXTR' or
          file_prefix_nm=='NWB_DEBITCARD_NPCB006_PARTEXTR' or file_prefix_nm=='RBS_DEBITCARD_NPCB006_PARTEXTR'):
        start_time=job_option_config.start_time_debit
        end_time=job_option_config.end_time_debit
    return start_time <= current_time <= end_time


if __name__ == "__main__":

    try:
        create_logger("CDE_INGESTION_TRANSFER_FILE_LTP")
        spark = get_spark()
        xdpLogger('xDP-INF-001')
        conflist = spark.sparkContext.getConf().getAll()
        for i in conflist:
            if 'spark.app.id' in i[0]:
                application_id = i[1]

        read_file_action_sql="""select file_action.*,sourcing_master_info.job_name from (
            (select * from {} ) file_action
            left join
            (select * from {} where action_type = 'FileTransfer'
             and action_typ_details in ('ValidFileTransfer') and status ='Pass') ingestion_details
            on file_action.file_prefix_nm = ingestion_details.file_prefix_nm and file_action.file_nm = ingestion_details.file_nm and file_action.snap_dt = ingestion_details.snap_dt
            left join
            (select * from {}) sourcing_master_info
            on file_action.file_prefix_nm = sourcing_master_info.job_name
            )where ingestion_details.file_nm is null and sourcing_master_info.dd_flag = 'Y'""".format(job_option_config.file_action,job_option_config.file_ingestion_detail,job_option_config.cder_mainframe_sourcing_master)
        xdpLogger('xDP-INF-009',comment='File transfer query: {}'.format(read_file_action_sql))
        read_file_action = spark.sql(read_file_action_sql)
        #read_file_action.show()
        if read_file_action.first() :
            xdpLogger('xDP-INF-111',comment="dataframe is not empty")
        else :
            xdpLogger('xDP-INF-111',comment="Dataframe is empty ,no records to be processed")
            spark.stop()
            sys.exit(0)
        to_be_processed = read_file_action.filter(read_file_action.status.isin("SCHEDULED_FILE","EARLY_FILE","SLA BREACHED"))
        #to_be_processed.show()
        if len(to_be_processed.head(1)) == 0 :
                process_file_details = []
                valid_files_list = []
        else:
                valid_files = to_be_processed.select("file_nm").collect()
                valid_files_list = [valid_files[i][0] for i in range(len(valid_files))]
                print("valid file list ", valid_files_list)
                process_file_details = extractFileProcessingList(valid_files_list,to_be_processed)

        file_details = to_be_processed.filter(col("file_nm").isin(process_file_details))
        #file_details.show()

        if len(file_details.head(1)) == 0 :
                xdpLogger('xDP-INF-111',comment="No Valid file to move")
                pass
        else:
                #file_movement(file_details)
                success_list = []
                failure_list = []
                for obj in file_details.collect():
                    snap_dt = obj["snap_dt"]
                    batch_dt = obj["batch_dt"]
                    file_nm = obj["file_nm"]
                    job_name = obj["job_name"]
                    file_prefix_nm = obj["file_prefix_nm"]
                    source = job_option_config.landing_zone + file_nm
                    target = job_option_config.processing_zone + job_name + '/'
                    if (file_prefix_nm=='GRP_TSYS_NCARDS_BALS' or file_prefix_nm=='JUBUK_DEBITCARD_NPCB006_PARTEXTR' or
                        file_prefix_nm=='KUBIE_DEBITCARD_NPCB006_PARTEXTR' or file_prefix_nm=='NWB_DEBITCARD_NPCB006_PARTEXTR' or 
                        file_prefix_nm=='RBS_DEBITCARD_NPCB006_PARTEXTR'):
                        file_hold_status=get_hold_file_status(file_prefix_nm)
                        if file_hold_status:
                            print("Hold the movement of the file : ",file_nm)
                        else:
                            print(file_nm,file_prefix_nm,source,target)
                            a = subprocess.call(['aws', 's3', 'mv', source, target])
                            if a ==0 :
                                xdpLogger('xDP-INF-010',comment='Files {} moved successfully'.format(file_nm))
                                list_1 = (snap_dt,batch_dt,file_nm,file_prefix_nm,'FileTransfer','ValidFileTransfer','Pass',str(datetime.now())[:-7],application_id,date.today())
                                success_list.append(list_1)
                            else:
                                xdpLogger('xDP-WAR-040',comment='File {} - movement failed'.format(file_nm))
                                list_2 = (snap_dt,batch_dt,file_nm,file_prefix_nm,'FileTransfer','ValidFileTransfer','Fail',str(datetime.now())[:-7],application_id,date.today())
                                failure_list.append(list_2)                        
                    else:
                        print(file_nm,file_prefix_nm,source,target)
                        a = subprocess.call(['aws', 's3', 'mv', source, target])
                        if a ==0 :
                            xdpLogger('xDP-INF-010',comment='Files {} moved successfully'.format(file_nm))
                            list_1 = (snap_dt,batch_dt,file_nm,file_prefix_nm,'FileTransfer','ValidFileTransfer','Pass',str(datetime.now())[:-7],application_id,date.today())
                            success_list.append(list_1)
                        else:
                            xdpLogger('xDP-WAR-040',comment='File {} - movement failed'.format(file_nm))
                            list_2 = (snap_dt,batch_dt,file_nm,file_prefix_nm,'FileTransfer','ValidFileTransfer','Fail',str(datetime.now())[:-7],application_id,date.today())
                            failure_list.append(list_2)
                
                print("success_list", success_list)
                print("failure_list", failure_list)
                if len(success_list):
                    writeStatus2FileIngestion(success_list)
                if len(failure_list):
                    writeStatus2FileIngestion(failure_list)



        xdpLogger('xDP-INF-999')
        spark.stop()


    except Exception as e:
        xdpLogger('xDP-ERR-117',comment=e)
        spark.stop()
        sys.exit(1)







