from botocore.session import Session
from pyspark.sql import SparkSession
from collections import OrderedDict
import yaml
import subprocess
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
import sys
import traceback
import os
import sys
import logging
#from util import frmspark
from logger import get_logger,create_logger,xdpLogger
from datetime import datetime
from botocore.exceptions import ParamValidationError
#from util import utilities as utility
import json
import pyspark.sql.functions as f
import re


def get_spark():
    """
    Get a spark session for processiong
    """
    #new_spark = SparkSession.builder.master("yarn").config('hive.exec.dynamic.partition.mode', 'nonstrict').enableHiveSupport().getOrCreate()
    new_spark = SparkSession \
    .builder.master("yarn") \
    .appName("XDP_FileIngestion") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config("spark.sql.broadcastTimeout", "3600") \
    .config("spark.dynamicAllocation.executorIdleTimeout ", "300").config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate()
    new_spark.sparkContext.setLogLevel("ERROR")
    return new_spark



def get_BucketNkey(input_loc,spark):
    try:
        get_logger()
        if (input_loc.lower().startswith('s3')):
            xdpLogger('xDP-INF-111',comment='Func get_BucketNkey started and valid input location passed')
            print('valid value')
            full_path = input_loc[5:]
            print(full_path)
            print(len(full_path.split("/")))
            x=int(len(full_path.split("/")))
            """To check if the loc contains atleast a bucket and a key    """
            if x > 2 :
                bucket_name=full_path.split("/")[0]
                full_path_list = full_path.split("/")
                key = ''
                len1 = len(full_path_list)
                print("*************")
                print(len1)
                k=1
                while k < len1 :
                    key= key + "/" + full_path_list[k]
                    k=k+1
                    length = len(key)
                    Key = key[1:length]
                    myDict = {}
                    myDict['bucket_name'] = Key
                return bucket_name,Key
            else:
                xdpLogger('xDP-ERR-117',comment='location should have atleast 1 bucket and 1 key')
                spark.stop # graceful exit
                sys.exit(1)
        else :
            xdpLogger("xDP-WAR-007",comment="Location {} is invalid ".format(input_loc))
    except Exception as e:
        xdpLogger('xDP-ERR-117',comment=e)


def checkFile(bucket_name,key,spark):
    try:
        get_logger()
        session = Session()
        client = session.create_client('s3')
        obj_dict = client.list_objects(Bucket=bucket_name,Prefix=key)
        listOfobjects = obj_dict['Contents']

    except ParamValidationError :
        xdpLogger('xDP-WAR-016',comment="Input value for BucketName is not Appropriate,Bucket name must match the regex ^[a-zA-Z0-9.\-_]{1,255}$ ")

    except KeyError :
        xdpLogger('xDP-ERR-117',comment='Processing zone folder missing')
        return False, [], {}
        #spark.stop # graceful exit with spark stops -WMIT-5794
        #sys.exit(0)

    except Exception as e :
        xdpLogger('xDP-ERR-117',comment=e)
        sys.exit(0)
    count=0
    keys=[]
    file_size_dict={}
    for object in listOfobjects :
        size = (object['Size'])
        name = (object['Key'])
        name_list=name.split("/")
        index = len(name_list)-2        
        prefix=name_list[index]
        if size > 0 :
            count=count+1
            print("file {} is of size {} ".format(name,size)) 
            keys.append(prefix)			
            if prefix not in file_size_dict:
                file_size_dict[prefix] = size
            else:
                if size > file_size_dict[prefix]:
                    file_size_dict[prefix] = size
    if count >= 0:
        return True ,keys,file_size_dict
    else :
        return False,None

def setup_yaml():
    represent_dict_order = lambda self, data:  self.represent_mapping('tag:yaml.org,2002:map', data.items())
    yaml.add_representer(OrderedDict, represent_dict_order)

def main():
    #some mandatory assignments from the config File.
    timestamp = datetime.now().strftime("%d-%m-%Y_%H:%M:%S")
    config_file = job_option_config.config_file_loc + "rsr_airflow_config.yaml"
    keep_alive_file = job_option_config.config_file_loc +  "keep_alive_file.yaml"

    archivefileloc = job_option_config.config_file_archive_loc + "rsr_airflow_config.yaml"+"_"+timestamp
    keepaliveloc = job_option_config.config_file_archive_loc + "keep_alive_file.yaml"+"_"+timestamp

    setup_yaml()
    spark = get_spark()
    create_logger("CDE_INGESTION_GENERATE_YAML")
    xdpLogger('xDP-INF-001')
    bucket_name,key = get_BucketNkey(job_option_config.processing_zone,spark)
    xdpLogger('xDP-INF-111',comment='Bucket : {}'.format(bucket_name))
    xdpLogger('xDP-INF-111',comment='Key : {}'.format(key))
    Flag,keys,file_size_dict = checkFile(bucket_name,key,spark)
    #print("Keys are ", keys)
    xdpLogger('xDP-INF-111',comment='File size dict is : {}'.format(str(file_size_dict)))
    # removing Unicode characters from the list
    Keys_unic = [str(item) for item in keys]
    print("len keys_unic is ", str(len(Keys_unic)))
    if len(Keys_unic) == 0 :
        subprocess.call(['touch','rsr_airflow_config.yaml'])
        subprocess.call(['aws', 's3', 'mv', 'rsr_airflow_config.yaml', job_option_config.config_file_loc])
        xdpLogger('xDP-INF-111',comment='No files to process')
        spark.stop # graceful exit
        sys.exit(0)
    if Keys_unic :
        xdpLogger('xDP-INF-111',comment='Mentioned are the files from file_expected_list:'.format(str(Keys_unic)))
    else:
        spark.stop # graceful exit
        sys.exit(0)


    # Find out common set between file_expected_list and files actually on the Processing zone
    process_list = list(set(Keys_unic))
    xdpLogger('xDP-INF-111',comment='Process list is {}'.format(str(process_list)))
    file = {}
    reject_list = []

    for f in process_list:
        file1 = OrderedDict()   #ordered dict assignment as per function definition above, this would store the values from
        table_name = f
        #file1["name"] = table_name    # Pick filePrefix or tablename for assignement        
        size=file_size_dict[table_name]
        print(type(size))
        print(size)
        master_data_query = "select file_name, job_name, brand_id, brand, script_to_load_staging_layer, script_to_load_process_layer from {}  where job_name = '{}'".format(job_option_config.cder_mainframe_sourcing_master,table_name)
        xdpLogger('xDP-INF-009',comment='Mainframe feed master query - {}'.format(master_data_query))
        master_data_df = spark.sql(master_data_query)
        master_data_df.show()
        file_name = str(master_data_df.select("file_name").first()[0])
        job_name = str(master_data_df.select("job_name").first()[0])
        brand_id = str(master_data_df.select("brand_id").first()[0])
        brand = str(master_data_df.select("brand").first()[0])
        script_to_load_staging_layer = str(master_data_df.select("script_to_load_staging_layer").first()[0])
        script_to_load_process_layer = str(master_data_df.select("script_to_load_process_layer").first()[0])

        xdpLogger('xDP-INF-111',comment='File name: {} Job name: {} brand id: {} brand: {} script_to_load_staging_layer: {} script_to_load_process_layer: {}'.format(file_name,job_name,brand_id,brand,script_to_load_staging_layer,script_to_load_process_layer))

        file1["file_name"] = file_name
        file1["job_name"] = job_name
        file1["brand_id"] = brand_id
        file1["brand"] = brand
        file1["script_to_load_staging_layer"] = script_to_load_staging_layer
        file1["script_to_load_process_layer"] = script_to_load_process_layer

        try:
            size_ingb = round(float(size) / 1073741824 , 2)
            print(str(size_ingb))
        except TypeError:
            reject_list.append(table_name)
            xdpLogger('xDP-WAR-031',comment="File entry invalid in ctl table  for  :{}".format(table_name))
            continue

        config_df = spark.table(job_option_config.spark_config_tbl)
        config_df_filter = config_df.filter((config_df.lowerbound<=size_ingb) & (config_df.upperbound>=size_ingb))
        if len(config_df_filter.head(1)) == 0 :
           spark.stop 
           xdpLogger('xDP-INF-111',comment="Stopping the script as spark dataframe is empty")
           sys.exit(1)
        elif re.search(r'DEBITCARD_NPCB006_PARTEXTR', file_name) :    
            SPARK_ARGS = """spark-submit -v --executor-memory=18g --executor-cores=4  --driver-memory=10g --conf spark.executor.memoryOverhead=2g  --conf spark.executor.cores=4 --conf spark.driver.memoryOverhead=1g --conf spark.dynamicAllocation.initialExecutors=6  --conf spark.dynamicAllocation.minExecutors=6   --conf  spark.executor.instances=6    --conf spark.dynamicAllocation.maxExecutors=25  --conf spark.default.parallelism=120  --conf spark.sql.shuffle.partitions=120  --conf spark.serializer=org.apache.spark.serializer.KryoSerializer --conf spark.network.timeout=300 --conf spark.sql.sources.commitProtocolClass=org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol"""
            SPARK_ARGS = SPARK_ARGS.replace('\n','')
            SPARK_ARGS = str(SPARK_ARGS)
            print(SPARK_ARGS)		
        else :
            executorcores = str(config_df_filter.select("coresperexecutor").first()[0])
            label = str(config_df_filter.select("label").first()[0])
            lowerbound = str(config_df_filter.select("lowerbound").first()[0])
            upperbound = str(config_df_filter.select("upperbound").first()[0])
            description = str(config_df_filter.select("description").first()[0])
            coresperexecutor = str(config_df_filter.select("coresperexecutor").first()[0])
            numofexec = str(config_df_filter.select("numofexec").first()[0])
            drivermem = int(config_df_filter.select("drivermem").first()[0])
            driveroverheadratio = float(config_df_filter.select("driveroverheadratio").first()[0])
            executormem = int(config_df_filter.select("executormem").first()[0])
            executoroverheadratio = float(config_df_filter.select("executoroverheadratio").first()[0])
            minexecutor = str(config_df_filter.select("minexecutor").first()[0])
            shufflepartitions = str(config_df_filter.select("shufflepartitions").first()[0])
            defaultparallelism = str(config_df_filter.select("defaultparallelism").first()[0])
            drivermemoverhead = int(round(drivermem * 1000 * driveroverheadratio,0))
            executormemoverhead = int(round(executormem * 1000 *  executoroverheadratio ,0))
            SPARK_ARGS = """spark-submit -v --executor-memory={}g --executor-cores={}  --driver-memory={}g --conf spark.executor.memoryOverhead={}m  --conf spark.executor.cores={} --conf spark.driver.memoryOverhead={}m --conf spark.dynamicAllocation.initialExecutors={}  --conf spark.dynamicAllocation.minExecutors={}   --conf  spark.executor.instances={}    --conf spark.dynamicAllocation.maxExecutors={}  --conf spark.default.parallelism={}  --conf spark.sql.shuffle.partitions={}  --conf spark.serializer=org.apache.spark.serializer.KryoSerializer --conf spark.network.timeout=300 --conf spark.sql.sources.commitProtocolClass=org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol""".format(executormem,executorcores,drivermem,executormemoverhead,executorcores,drivermemoverhead,minexecutor,minexecutor,minexecutor,numofexec,defaultparallelism,shufflepartitions)
            SPARK_ARGS = SPARK_ARGS.replace('\n','')
            SPARK_ARGS = str(SPARK_ARGS)
            print(SPARK_ARGS)


        file1['argument'] = SPARK_ARGS
        file[table_name] = file1



    if len(reject_list) > 0 :
        xdpLogger('xDP-INF-111',comment="Files in reject list")
        spark.stop # graceful exit with spark stops -WMIT-5794
        sys.exit(1)
    else :    

    #Dump the file being created at the corresponding location
        all_files = {}
        all_files["files"] = file
        print("printing before the dictionary dump")
        print(all_files)
        try :
            with open("rsr_airflow_config.yaml", "w") as yaml_file:
                yaml.dump(all_files, yaml_file, default_flow_style=False)
        except IOError :
            filename='rsr_airflow_config.yaml'

        except exception as e :
            xdpLogger('xDP-ERR-117',comment=e)


    #Script to initiate backup and  movement of YAML from EMR to S3 bucket
        subprocess.call(['cp', 'rsr_airflow_config.yaml', 'keep_alive_file.yaml'])
        subprocess.call(['aws', 's3', 'cp', 'keep_alive_file.yaml', keepaliveloc])
        subprocess.call(['aws', 's3', 'mv', 'keep_alive_file.yaml', job_option_config.config_file_loc])
        subprocess.call(['aws', 's3', 'cp', config_file , archivefileloc])
        subprocess.call(['aws', 's3', 'mv', 'rsr_airflow_config.yaml', job_option_config.config_file_loc])
        xdpLogger('xDP-INF-111',comment='Backup and Movement of YAML completed')
        xdpLogger('xDP-INF-999')



if __name__ == '__main__':
    main()
