import json
import os
import subprocess
import time
from datetime import datetime

###   /****************************************************************************
###   * Job:             SCHEDULING OF SOURCING DATA-LOADING-FROM-MAINFRAME       * 
###                      -TO-HIVE-STAGING  LAYER                                  *
###   * Description:     SOURCING DATA LOADING FROM MAINFARME WITH FILE FORMAT    *
###                      .CSV DELIMITED WITH '|' AND ',' AND FIXED WIDTH ALONG    * 
###                      WITH CONTROL TABLE ENTRY TO HIVE STAGING LAYER WITH      *
###                      VALIDATION OF ROW COUNT                                  *
###   *                                                                           *
###   * Created on:      Friday, November 22, 2020 2:19:20 PM IST                 *
###   * Created by:      Binaya Lenka (kumabbn)/Accenture                         *
###   *                  Rahul ranjan(ranjarz)/Accenture                          *
###   *                                                                           *
###   ****************************************************************************/

def files_to_track(json_driver_file):
    print(json_driver_file)
    with open(json_driver_file) as json_file:
        data = json.load(json_file)

    return data


def store_what_has_been_processed(local_emr_json, file_data):
    # write to json
    try:
        with open(local_emr_json) as json_file:
            data = json.load(json_file)
    except:
        data = []

    data.append(file_data)

    with open(local_emr_json, 'w') as outfile:
        json.dump(data, outfile)


def fetch_what_has_been_processed(local_emr_json):
    # read from json
    try:
        with open(local_emr_json) as json_file:
            data = json.load(json_file)
    except:
        return []

    return [x["key"] for x in data]


def check_if_file_exists(file):
    cmd = """aws s3 ls '{file}'""".format(file=file["file"])
    file_check_process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    file_check_process.wait()
    if file_check_process.returncode == 0:
        return True
    else:
        return False


def trigger_file_read(file):
    cmd = """spark-submit {code_location} --brand {brand} --app-name {job_name} --file-name {key} """.format(code_location=file["code_location"],
                                                                                                                           brand=file["brand"],
                                                                                                                           job_name=file["job_name"],key=file["key"])
    file_check_process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    file_check_process.wait()

    # print("[cde] Job [{}] has completed succesufully")

    if file_check_process.returncode == 0:
        return True
    else:
        return False


## iterate over map to know what to load and not load

def move_file_load_information_to_hive(file, batch_date_str):
    hive_command = """hive -e "INSERT INTO cde_control.batch_control_table PARTITION(load_date='{batch_date_str}') select '{key}', '{job_name}', '{brand}', current_timestamp();" """.format(
        batch_date_str=batch_date_str,
        brand=file["brand"],
        job_name=file["job_name"],
        key=file["key"])

    hive_insert_process = subprocess.Popen(hive_command, shell=True, stdout=subprocess.PIPE)
    hive_insert_process.wait()

    if hive_insert_process.returncode == 0:
        print("Status Information was inserted successfully for file - {}".format(file["key"]))
    else:
        print("****** WARNING!!! There was some problem inserting records into Control Table for file - {}".format(
            file["key"]))


def file_reading_completed(driver_json, local_emr_json):
    # read from json

    with open(driver_json) as json_file:
        driver_info = json.load(json_file)

    try:
        with open(local_emr_json) as json_file:
            files_processed = json.load(json_file)
    except:
        files_processed = []

    # if len(files_processed) == len(driver_info):
    #     return False
    # else:
    #     return True

    for d in driver_info:
        if d["key"] not in [x["key"] for x in files_processed]:
            return True
    return False


def pause_file_check():
    time_to_pause_in_min = 15

    print("""Would be rechecking files after {wait_min} min - [{current_date}]""".format(wait_min=time_to_pause_in_min,
                                                                                         current_date=datetime.now()))
    time.sleep(15 * 60)


def main(batch_date_str, driver_json=None, emr_json_cache=None):
    while file_reading_completed(driver_json, emr_json_cache):

        pause_file_check()

        for file in files_to_track(driver_json):
            if file["key"] not in fetch_what_has_been_processed(emr_json_cache):

                print("Checking for file - {file}".format(file=file["key"]))

                file_status = check_if_file_exists(file)

                if file_status:
                    file_read_status = trigger_file_read(file)

                    if file_read_status:
                        store_what_has_been_processed(emr_json_cache, file)
                        move_file_load_information_to_hive(file, batch_date_str)

    print("File Reading is finished!!")


if __name__ == '__main__':
    # config_folder = os.path.join(os.path.dirname(__file__), '..', 'config')
    # driver_json_file = os.path.join(config_folder, "s3_files_to_poll_and_read.json")
    # print(driver_json_file)
    driver_json_file = "config/s3_files_to_poll_and_read.json"
    local_emr_json = "processed_staging_data.json"

    main(batch_date_str=datetime.now().strftime("%Y-%m-%d"),
         driver_json=driver_json_file,
         emr_json_cache=local_emr_json)
