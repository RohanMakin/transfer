from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import *
import sys
import os
import re
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import create_logger, xdpLogger
import subprocess
from datetime import datetime, timedelta


def main():
    spark = SparkSession \
    .builder \
    .appName("TERADATA TACTICAL FEED STAGING LOADING") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate() 

    spark.sparkContext.setLogLevel("ERROR")


    ###   /*********************************************************************************** 
    ###   * Job:             CDE_TERADATA_TACTICAL_FEED_STAGING_LOAD_ETL                     * 
    ###   * Description:     READING TERADATA PIPE DELIMITED ,COMMA DELIMITED                *
    ###   *                  FILES AND INSERTING RECORDS IN PROCESS LAYER TABLE              * 
    ###   * Created by:      Binaya Lenka(kumabbn)/Accenture                                 *
    ###                      Rahul Ranjan(ranjarz)/Accenture                                 *	
    ###   *                                                                                  *
    ###   ************************************************************************************/ 

    '''
    Reading required parameters passed as arguments
    '''

    PATH=setup_module_config_path.path
    FILE_NAME = sys.argv[1]
    SYSPARM = None
    CDE_CONTROL=job_option_config.cde_databases["CONTROL"]
    ENV = job_option_config.CDE_ENV.upper()
    DATA_IN_BUCKET=job_option_config.CDE_DATAIN_BUCKET
    BUCKET=job_option_config.CDE_BUCKET

    create_logger('TERADATA TACTICAL FEED STAGING LOADING : {FEED_NAME}'.format(FEED_NAME=FILE_NAME))
    xdpLogger('xDP-INF-013',comment="CDER sourcing data loading process till staging layer for feed {FEED_NAME} has started".format(FEED_NAME=FILE_NAME))

    '''
    updating flow status with start time in control table
    '''

    try:
        ts_start= datetime.today()
        #Update start time
        query_start="INSERT INTO TABLE {cde_control}.sourcing_flow_running_status VALUES ('{FLOW_NAME}','{TS_START}','','S')".format(FLOW_NAME=FILE_NAME,TS_START=ts_start,cde_control=CDE_CONTROL)
        spark.sql(query_start)
        xdpLogger('xDP-INF-111',comment="Logs updated with start time")
        print('Flows Start Time updated')
    except Exception as e:
        try:
            spark.sql(query_start)
            xdpLogger('xDP-INF-111',comment="Logs updated with start time")
            print('Flows Start Time updated')
        except Exception as e:
            xdpLogger('xDP-ERR-117',comment=e)
            print(str(e))        
            sys.exit(1)

    '''
    Extracting required information from master table for file information 
    '''
    try:
        info=spark.sql("""
                    SELECT
                        FILE_NAME,
                        FILE_TYPE,
                        FILE_LOCATION,
                        DELIMETER,
                        DB_NAME,
                        TABLE_NAME
                    FROM 
                        {cde_control}.TERADATA_TACTICAL_FEEDS_MASTER_INFO
                    WHERE
                        FILE_NAME='{FILENAME}'
                    """.format(FILENAME=FILE_NAME,cde_control=CDE_CONTROL)).collect()
                    
        FILE_TYPE, FILE_LOCATION, DELIMETER, DB_NAME, TABLE_NAME  = info[0][1].lower(),info[0][2].lower(),info[0][3],info[0][4].lower(),info[0][5].lower()
        VAR_STR="FILE_TYPE : "+FILE_TYPE + ", FILE_LOCATION : "+FILE_LOCATION+ ", DELIMETER : "+DELIMETER+" , DB_NAME : "+DB_NAME+" , TABLE_NAME : "+TABLE_NAME
        xdpLogger('xDP-INF-025',comment=VAR_STR)
    except Exception as e:
        print("Exception while extracting information from master control table cde_control.TERADATA_TACTICAL_FEEDS_MASTER_INFO")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-117',comment=e)            
        sys.exit(1) 


    '''
    Extracting batch information from cde source batch id control table.
    '''

    try:
        batch_info=spark.sql("""
                                SELECT
                                    BATCH_DATE,
                                    CASE 
                                        WHEN 'RBS'=='{sysparm}' THEN RBS_BATCH_ID
                                        WHEN 'NWB'=='{sysparm}' THEN NWB_BATCH_ID
                                        WHEN 'UBN'=='{sysparm}' THEN UBN_BATCH_ID
                                        WHEN 'UBS'=='{sysparm}' THEN UBR_BATCH_ID
                                    ELSE GRP_BATCH_ID
                                    END AS BATCH_ID
                                FROM
                                    {cde_control}.SOURCING_BATCH_ID_CONTROL_TABLE
                            """.format(cde_control=CDE_CONTROL,sysparm=SYSPARM)).collect()
        
        BATCH_DATE , BATCH_ID = batch_info[0][0], batch_info[0][1]         
    except Exception as e:
        print("Exception while extracting batch information from control table cde_control.SOURCING_BATCH_ID_CONTROL_TABLE")
        print("EXCEPTION :",str(e))
        xdpLogger('xDP-ERR-117',comment=e)
        sys.exit(1)
        
    '''
    Defined s3 buckets path based on environment variable
    '''
    

    S3_FILE_LANDING_ZONE='s3://'+DATA_IN_BUCKET+'/data-in/cde/migration/teradata/pre-prod/SUCCESS/'
    S3_STAGING_ZONE='s3://'+BUCKET+'/transformation/cde/'
    S3_HEADER_TRAILER_INFO='s3://'+DATA_IN_BUCKET+'/data-in/cde/teradata_trailer_info/'
    S3_FILE_ARCHIVAL_ZONE='s3://'+DATA_IN_BUCKET+'/data-in/cde/archival/teradata-downloads/'    

    '''
    Removing tailer from teradata tactical feed file and populating tactical staging table
    ''' 


    #back_date = datetime.today()
    RUN_DATE= str(BATCH_DATE).replace('-','')
    OUTPUT_PATH=S3_STAGING_ZONE + DB_NAME + '/' +TABLE_NAME + '_stg/' 
    FILE_PATH= S3_FILE_LANDING_ZONE + FILE_LOCATION +'/'   

    FULL_FILE_PATH=    FILE_PATH + FILE_NAME +"." + RUN_DATE + ".csv.gz"
    a = subprocess.call(['aws','s3','ls','{file_path}'.format(file_path=FULL_FILE_PATH),'--recursive'])   
    if a == 0:
        ch_dir="cd /mnt1"
        os.system(ch_dir)
        RM_CMD="sudo aws s3 rm " + OUTPUT_PATH + " --recursive"
        if FILE_NAME.lower()=='whd01_edw_db01_ref.edi_street_address':
            MV_CMD = "aws s3 cp " +  FILE_PATH + FILE_NAME +"." + RUN_DATE + ".csv.gz - | gunzip | tr -cd '\11\12\15\40-\176' | sed '1d;$d;s/.*sqxz//;s/~/TILCHAR/g;s/Mq`Pz/~/g;s/.$//g;s/\r//g;/^$/d' | aws s3 cp - " + OUTPUT_PATH +  FILE_NAME +"." + RUN_DATE + ".csv"
        else:
            MV_CMD = "aws s3 cp " +  FILE_PATH + FILE_NAME +"." + RUN_DATE + ".csv.gz - | gunzip | tr -cd '\11\12\15\40-\176' | sed '1d;$d;s/.*sqxz//;s/.$//g;s/\r//g;/^$/d' | aws s3 cp - " + OUTPUT_PATH +  FILE_NAME +"." + RUN_DATE + ".csv"
        print(RM_CMD)
        print(MV_CMD)
        try:
            os.system(RM_CMD)
            os.system(MV_CMD)
                    
        except Exception as e:
            print("Exception while inserting data of file {FILES} in table {table}".format(FILES=FILE_NAME,table=TABLE_NAME))
            print(str(e))
            xdpLogger('xDP-ERR-117',comment=e)
        
        xdpLogger('xDP-INF-010',comment="source file transferred to staging table location")
    else:
        print("Current day file not available for processing at {file_path}".format(file_path=FULL_FILE_PATH))
        xdpLogger('xDP-ERR-117',comment="Sourcing File unavailable within waiting period") 
        sys.exit(1)

    '''
    Creating tailer file from tearadata tactical feed file for validation purpose
    '''    
    FULL_FILE_NAME="H_T_"+ FILE_NAME+"." + RUN_DATE + ".csv"
    TERADATA_TRAILER_INFO="aws s3 cp " + FILE_PATH + FILE_NAME + "." + RUN_DATE + ".csv.gz - | gunzip | sed -e 1b -e '$!d' | aws s3 cp - " + S3_HEADER_TRAILER_INFO + FILE_LOCATION +'/'+ FULL_FILE_NAME
    os.system(TERADATA_TRAILER_INFO)
    
    '''
    Download header file to emr and extract tailer info
    '''
    
    F_DOWNLOAD="sudo aws s3 cp " + S3_HEADER_TRAILER_INFO + FILE_LOCATION +'/'+ FULL_FILE_NAME+" ." 
    os.system(F_DOWNLOAD)

    RMV_UNICODE="sudo LANG=C sed -i $'s/[^[:print:]\t]/,/g;s/.*sqxz//' " + FULL_FILE_NAME 
    os.system(RMV_UNICODE)
    
    '''
    Extracting header info  
    '''
    out=subprocess.Popen(['head', '-n', '1', '{file_name}'.format(file_name=FULL_FILE_NAME)],
           stdout=subprocess.PIPE,
           stderr=subprocess.STDOUT)  
    stdout,stderr = out.communicate()

    if re.search(r'\d{4}-\d{2}-\d{2},\d{2}:\d{2}:\d{2}', str(stdout)):
        FILE_DATE=re.search(r'\d{4}-\d{2}-\d{2},\d{2}:\d{2}:\d{2}', str(stdout)).group().replace(',',' ')
    elif re.search(r'\d{4}-\d{2}-\d{2}', str(stdout)):
        FILE_DATE=re.search(r'\d{4}-\d{2}-\d{2}', str(stdout)).group()
    elif re.search(r'\d{8}', str(stdout)):
        FILE_DATE=re.search(r'\d{8}', str(stdout)).group()
    else:
        FILE_DATE= str(stdout)  
 
    #xdpLogger('xDP-INF-025',comment="FILE DATE: {file_date}".format(file_date=FILE_DATE))   
    
    '''
    Exracting Trailer Info 
    '''    
    
    out=subprocess.Popen(['tail', '-n', '1', '{file_name}'.format(file_name=FULL_FILE_NAME)],
           stdout=subprocess.PIPE,
           stderr=subprocess.STDOUT)  
    stdout,stderr = out.communicate()
    
    count=re.split(r'[|\s]\s*', str(stdout))
    cnt=[s for s in count if s.isdigit()]

    if not cnt:
        FILE_COUNT=str(stdout)
    else:
        FILE_COUNT=cnt[0]

    xdpLogger('xDP-INF-025',comment="FILE COUNT: {file_count}".format(file_count=FILE_COUNT))    

    '''
    Selecting the count(*) inserted at staging layer and assigning to variable
    '''

    RECORD_COUNT= spark.sql("""
                               SELECT COUNT(*) FROM {TDDB_INST}.{TABLE}_stg
                """.format(TDDB_INST=DB_NAME,TABLE=TABLE_NAME)).collect()[0][0]
    #xdpLogger('xDP-INF-025',comment="RECORD COUNT: {record_count}".format(record_count=RECORD_COUNT))    

    RM_CMD= "sudo rm {file_name}".format(file_name=FULL_FILE_NAME)
    os.system(RM_CMD)  

    
    '''
    extracting column details for data loading
    '''
    
    query1="""desc {database}.{table}_TEMP""".format(table=TABLE_NAME,database=DB_NAME)
    
    try:
        COL_DETAILS = spark.sql(query1)
        COL_DETAILS.createOrReplaceTempView("COL_DETAILS")
    except Exception as e:
        print("Temp table {table}_temp not found".format(table=TABLE_NAME,database=DB_NAME))
        print(str(e))
        xdpLogger('xDP-ERR-117',comment=e)

    '''
    creating select string
    '''
    
    if FILE_NAME.lower()=='whd01_edw_db01_ref.edi_street_address':
        query2="""select CASE WHEN data_type = "double" THEN  "replace("||col_name||",' ','')" WHEN col_name like '%address_line_%' THEN  "replace("||col_name||",'TILCHAR','~')"  else "rtrim("||col_name||")"  end tcol_name from COL_DETAILS """
    else:
        query2="""select CASE WHEN data_type = "double" THEN  "replace("||col_name||",' ','')"  else "rtrim("||col_name||")"  end tcol_name from COL_DETAILS """

    try:
        SELECT_STATEMENT = spark.sql(query2)
        DATA = SELECT_STATEMENT.rdd.map(lambda x : x.tcol_name)
        STR1 = DATA.collect()
        STR2 = ','.join(map(str,STR1))
    except Exception as e:
        print("Exception while creating select string")
        print(str(e))
        xdpLogger('xDP-ERR-117',comment=e)

    '''
    Inserting file load status in control table and aborting the process in case of mismatch/failure during loading
    '''

    query3="""
                INSERT INTO TABLE {cde_control}.MAINFRAME_FEEDS_ROW_COUNT
                PARTITION (LOAD_DATE)
                SELECT
                    '{feed_name}',
                    '{brand}',
                    coalesce(from_unixtime(UNIX_TIMESTAMP(cast('{header_datetime}' as string),'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:mm:ss'),from_unixtime(UNIX_TIMESTAMP(cast('{header_datetime}' as string),'yyyyMMdd'),'yyyy-MM-dd HH:mm:ss'),from_unixtime(UNIX_TIMESTAMP(cast('{header_datetime}' as string),'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss')),
                    {tailer_row_count},
                    {staging_table_row_count},
                    CASE WHEN {tailer_row_count}={staging_table_row_count} THEN 'S' ELSE 'F' END ,
                    CURRENT_TIMESTAMP(),
                    null,
                    CASE WHEN {tailer_row_count}={staging_table_row_count} THEN null ELSE 'Mismatch between feed record count and staging table record count' END ,
                    CURRENT_DATE() AS LOAD_DATE
                """.format(cde_control=CDE_CONTROL,feed_name=FILE_NAME + "." + RUN_DATE + ".csv.gz",file_type=FILE_TYPE,brand=SYSPARM,header_datetime=FILE_DATE,tailer_row_count=FILE_COUNT,staging_table_row_count=RECORD_COUNT)

    '''
    process for loading cde_process final table
    '''     

    query4=""" INSERT OVERWRITE TABLE {database}.{table}
                  SELECT {STR} FROM {database}.{table}_STG
           """.format(table=TABLE_NAME,database=DB_NAME,STR=STR2)
    
    
    if int(FILE_COUNT) == int(RECORD_COUNT):
        try:
            xdpLogger('xDP-INF-017',comment="Data load process for control table mainframe_feeds_row_count has started")
            spark.sql(query4)
            xdpLogger('xDP-INF-018',comment="Data loading process for control table mainframe_feeds_row_count has completed")
            spark.sql(query3)
        except Exception as e:
            print("Exception while inserting into staging table staging.{TABLE}".format(TABLE=TABLE_NAME))
            print("EXCEPTION :",str(e)) 
            xdpLogger('xDP-ERR-117',comment=e) 
            sys.exit(1)    
    else:
        try:
            xdpLogger('xDP-INF-017',comment="Data load process for control table mainframe_feeds_row_count has started")
            spark.sql(query3)
            xdpLogger('xDP-INF-018',comment="Data loading process for control table mainframe_feeds_row_count has completed")
            xdpLogger('xDP-ERR-117',comment="File and Record cound mismatch at staging table Layer")                
            sys.exit(1)
        except Exception as e: 
            print("Exception while inserting into control table CDE_CONROL.MAINFRAME_FEEDS_ROW_COUNT".format(TABLE=TABLE_NAME))
            print("EXCEPTION :",str(e))   
            xdpLogger('xDP-ERR-117',comment=e)                
            sys.exit(1)        

    '''
    Archiving current day file
    '''
    
    #NOW = datetime.now().strftime("%Y-%m-%d")
    ARCHIVE_FILE="aws s3 mv "+ FILE_PATH + FILE_NAME + "." + RUN_DATE + ".csv.gz" + " " + S3_FILE_ARCHIVAL_ZONE + str(RUN_DATE) +"/" + FILE_NAME + "." + RUN_DATE + ".csv.gz"
    print(ARCHIVE_FILE)
    os.system(ARCHIVE_FILE)
    xdpLogger('xDP-INF-010',comment="source file has been archived")

    '''
    updating flow status with end time in control table
    '''

    try:
        ts_end= datetime.today()
        #Update end time
        query_end="INSERT INTO TABLE {cde_control}.sourcing_flow_running_status VALUES ('{FLOW_NAME}','','{TS_END}','C')".format(FLOW_NAME=FILE_NAME,TS_END=ts_end,cde_control=CDE_CONTROL)
        spark.sql(query_end)
        xdpLogger('xDP-INF-111',comment="Logs updated with end time")
        print('Flows End Time updated')
    except Exception as e:
        try:
            spark.sql(query_end)
            xdpLogger('xDP-INF-111',comment="Logs updated with end time")
            print('Flows End Time updated')
        except Exception as e:
            xdpLogger('xDP-ERR-117',comment=e)
            print(str(e))        
            sys.exit(1)

    print("Process to load process layer with feed data Completed")
    xdpLogger('xDP-INF-014',comment="CDER sourcing data loading process for feed {FEED_NAME} till process layer has completed".format(FEED_NAME=FILE_NAME + "." + RUN_DATE + ".csv.gz"))

    spark.stop()

if __name__ == "__main__":
    """ 
    Description: This is the entry point for execution of this script.
    The steps in sequence define the logical flow of the code
    """
    main()
