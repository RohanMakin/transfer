from botocore.session import Session
from pyspark.sql import SparkSession
from collections import OrderedDict
import yaml
import subprocess
import sys
import traceback
import sys
from config import setup_module_config_path
import logging
from datetime import datetime, date
import traceback
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import get_logger,create_logger,xdpLogger
import pyspark.sql.functions as f


def get_spark():
    """
    Get a spark session for processiong
    """
    #new_spark = SparkSession.builder.master("yarn").config('hive.exec.dynamic.partition.mode', 'nonstrict').enableHiveSupport().getOrCreate()
    new_spark = SparkSession \
    .builder.master("yarn") \
    .appName("XDP_FileIngestion") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config("spark.sql.broadcastTimeout", "3600") \
    .config("spark.dynamicAllocation.executorIdleTimeout ", "300").config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate()
    new_spark.sparkContext.setLogLevel("ERROR")
    return new_spark


spark = get_spark()
conflist = spark.sparkContext.getConf().getAll()
for i in conflist:
    if 'spark.app.id' in i[0]:
        application_id = i[1]
timestamp = datetime.now()
today_1 = date.today().strftime("%d-%m-%Y")

def writeStatus2FileIngestion(input_list):
        try:
                get_logger()
                sc = spark.sparkContext
                result_df = sc.parallelize(input_list).toDF(["snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt"]).select("snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt")
                if result_df.count()>0:
                    result_df.write.mode('append').insertInto(job_option_config.file_ingestion_detail,overwrite=False)
                    xdpLogger('xDP-INF-111',comment='Status updated in File Ingestion detail table')
                    return True
        except:
                xdpLogger('xDP-ERR-117',comment='Status update in File Ingestion detail table failed')
                pass




def moveFile(file_name, source_file_dir, dest_file_path):
    """Description: This function moves files from source path to destination path
    :param file name of the files to be moved
    :param source path of the files to be moved from
    :param destination path of the files to be moved into
    :return
    """
    source_file_path = "%s%s" %(source_file_dir, file_name)
    try:
        a = subprocess.call(['aws', 's3', 'mv', source_file_path, dest_file_path])
        print(" File Move Attempted!")
        if a == 0:
            print('**********File  {}  moved to {} '.format(file_name,dest_file_path))
            return True
        else:
            print("There is no {file_name} file to be moved at the {source_file_dir} path").format(file_name=file_name,source_file_dir=source_file_dir)
            print(' FileMove Failed!')
            return False

    except Exception as e:
        tb = traceback.format_exc()
        print(tb)
        return False



if __name__ == "__main__":

    a = "ArchiveFilePostprocessing"
    print(a)
    create_logger("CDE_INGESTION_FILE_ARCHIVAL")
    read_file_ingestion_detail_sql="""select file_ingestion_gd.* from
                                      (select * from {} where action_type='ProcessLayerLoad' and status='Pass') file_ingestion_gd
                                      left join
                                      (select * from {} where action_type = 'FileTransfer' and action_typ_details='archivepostproc' and status='Pass' ) file_ingestion_arch
                                       on file_ingestion_gd.file_prefix_nm = file_ingestion_arch.file_prefix_nm and file_ingestion_gd.snap_dt = file_ingestion_arch.snap_dt and file_ingestion_gd.file_nm = file_ingestion_arch.file_nm
                                       where file_ingestion_gd.file_prefix_nm  not in (select  A.file_prefix from {} A where dml_flag='S' ) and file_ingestion_arch.file_prefix_nm is null """.format(job_option_config.file_ingestion_detail,job_option_config.file_ingestion_detail,job_option_config.mainframe_feeds_master_info)
    xdpLogger('xDP-INF-009',comment='File archival query  : {}'.format(read_file_ingestion_detail_sql))
    read_file_ingestion_detail = spark.sql(read_file_ingestion_detail_sql)
    #read_file_ingestion_detail.show()
    success_list = []
    failure_list = []
    if read_file_ingestion_detail.count() == 0:
        xdpLogger('xDP-INF-111',comment='No new files to archive')
        spark.stop()
        sys.exit(0)

    try:

        for file_obj in read_file_ingestion_detail.collect():
            snap_dt = file_obj["snap_dt"]
            batch_dt = file_obj["batch_dt"]
            file_nm = file_obj["file_nm"]
            file_prefix_nm = file_obj["file_prefix_nm"]
            print(file_nm, file_prefix_nm)
            source = job_option_config.processing_zone + file_prefix_nm + '/' + file_nm
            target = job_option_config.file_archive_loc + str(date.today()) + '/' + file_prefix_nm + '/'
            print(source)
            print(target)
            xdpLogger('xDP-INF-111',comment='Moving file to archive zone')
            a = subprocess.call(['aws','s3','mv', source, target])
            if a==0:
                xdpLogger('xDP-INF-010',comment='File {} archived successfully'.format(file_nm))
                list_1= (snap_dt,batch_dt,file_nm,file_prefix_nm,'FileTransfer', 'archivepostproc', 'Pass',str(datetime.now())[:-7],application_id,date.today())
                success_list.append(list_1)
            else:
                xdpLogger('xDP-WAR-040',comment='File {} archival failed'.format(file_nm))
                list_2= (snap_dt,batch_dt,file_nm,file_prefix_nm,'FileTransfer', 'archivepostproc', 'Fail',str(datetime.now())[:-7],application_id,date.today())
                failure_list.append(list_2)
        xdpLogger('xDP-DBG-001',comment='Success list: {}'.format(str(success_list)))
        xdpLogger('xDP-DBG-001',comment='Failure list: {}'.format(str(failure_list)))

        if len(success_list)>0:
            writeStatus2FileIngestion(success_list)
        if len(failure_list)>0:
            writeStatus2FileIngestion(failure_list)




    except Exception as e:
        xdpLogger("xDP-ERR-117",comment=e)
        spark.stop()
        sys.exit(1)




