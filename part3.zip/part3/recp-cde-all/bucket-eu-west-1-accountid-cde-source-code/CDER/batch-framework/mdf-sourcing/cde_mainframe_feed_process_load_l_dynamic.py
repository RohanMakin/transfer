from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as f
import sys
import os
import subprocess
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import create_logger, xdpLogger, get_logger
from datetime import datetime, date


def writeStatus2FileIngestion(input_list,spark):
    try:
        get_logger()
        sc = spark.sparkContext
        result_df = sc.parallelize(input_list).toDF(["snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt"]).select("snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt")
        if result_df.count()>0:
            result_df.write.mode('append').insertInto(job_option_config.file_ingestion_detail,overwrite=False)
            xdpLogger('xDP-INF-111',comment='Status updated in File Ingestion detail table')
            return True
    except Exception as e:
        xdpLogger('xDP-ERR-117',comment='Error while updating File Ingestion detail table')
        xdpLogger('xDP-ERR-117',comment=e)
        pass


def main():
    spark = SparkSession \
    .builder \
    .appName("MAINFRAME PROCESS LAYER I LOADING") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate() 

    spark.sparkContext.setLogLevel("ERROR")
    conflist = spark.sparkContext.getConf().getAll()
    for i in conflist:
        if 'spark.app.id' in i[0]:
            application_id = i[1]


    ###   /*********************************************************************************** 
    ###   * Job:             CDE_MAINFRAME_FEED_PROCESS_LOAD_I                          * 
    ###   * Description:     TYPE I HANDLING WITH BATCH_DAY/MTH BASED CONCEPT                *
    ###   *                  READING MAINFRAME FIXED WIDTH, PIPE DELIMITED ,COMMA DELIMITED  *
    ###   *                  FILES DATA FROM CDE STAGING LAYER AND INSERTING DELTA RECORDS   *
    ###                         IN CDE PROCESS LAYER TARGET TABLE                               * 
    ###   * Created by:      Binaya Lenka(kumabbn)/Accenture                                 *
    ###   *                  Rahul Ranjan(ranjarz)/Accenture                                 *
    ###   ************************************************************************************/ 

    '''
    Reading required parameters passed as arguments
    '''

    PATH=setup_module_config_path.path
    JOB_NAME = sys.argv[1].upper() 
    FILE_NAME = sys.argv[2].upper()
    SYSPARM = sys.argv[3].upper()
    CDE_CONTROL=job_option_config.cde_databases["CONTROL"]
    ENV = job_option_config.CDE_ENV.upper()
    DATA_IN_BUCKET=job_option_config.CDE_DATAIN_BUCKET
    BUCKET=job_option_config.CDE_BUCKET
    stage_only_jobs = job_option_config.staging_only_files.split(',')
    print(stage_only_jobs)
    create_logger('MAINFRAME PROCESS LAYER I LOADING')
    process_layer_query = """select file_ingestion_sll.* from
                                      (select * from {} where file_prefix_nm = '{}' and action_type='StageLayerLoad' and status='Pass' and file_nm like '{}%' order by file_nm) file_ingestion_sll
                                      left join
                                      (select * from {} where file_prefix_nm = '{}' and action_type = 'ProcessLayerLoad' and status='Pass' and file_nm like '{}%' ) file_ingestion_pll
                                       on file_ingestion_sll.file_prefix_nm = file_ingestion_pll.file_prefix_nm and file_ingestion_sll.snap_dt = file_ingestion_pll.snap_dt and file_ingestion_sll.file_nm = file_ingestion_pll.file_nm
                                       where file_ingestion_pll.file_prefix_nm is null order by batch_dt asc """.format(job_option_config.file_ingestion_detail,JOB_NAME,FILE_NAME,job_option_config.file_ingestion_detail,JOB_NAME,FILE_NAME)
    process_file_df = spark.sql(process_layer_query)
    process_file_df.show()
    if process_file_df.count() == 0:
        xdpLogger('xDP-INF-111',comment="No files to process for staging layer load for:  {}".format(JOB_NAME))
        sys.exit(0)
    for file_item in process_file_df.collect():
        success_list = []
        fail_list = []
        dummy_list = []
        snap_dt = file_item['snap_dt']
        batch_dt = file_item['batch_dt']
        BATCH_DATE = str(batch_dt)[0:4]+'-'+str(batch_dt)[4:6]+'-'+str(batch_dt)[6:8]
        file_nm = file_item['file_nm']
        print("snap_dt", snap_dt, "file_nm", file_nm, "batch_dt", batch_dt, "BATCH_DATE", BATCH_DATE)
        create_logger('MAINFRAME PROCESS LAYER I LOADING : {FEED_NAME}'.format(FEED_NAME=file_nm))
        xdpLogger('xDP-INF-013',comment="CDER sourcing data loading process till staging layer for feed {FEED_NAME} has started".format(FEED_NAME=file_nm))
        if(JOB_NAME in stage_only_jobs):
            list_dummy= (snap_dt,str(batch_dt).replace('-',''),file_nm,JOB_NAME,'ProcessLayerLoad', 'NA', 'Pass',str(datetime.now())[:-7],application_id,date.today())
            dummy_list.append(list_dummy)
            writeStatus2FileIngestion(dummy_list,spark)
            continue

        '''
        Extracting required information from master table for file information 
        '''
    
        try:
            info=spark.sql("""
                    SELECT
                        FILE_NAME,
                        FILE_TYPE,
                        STAGING_TABLE_NAME,
                        PROCESS_TABLE_NAME,
                        CDE_SOURCE_FIELDS,
                        DERIVED_FIELDS,
                        HIVE_SCHEMA_NAME,
                        KEY_FIELDS,
                        SECT_CODE_SELECT_STR,
                        DML_FLAG,
                        DATE_STR,
                        STG_DB,
                        PROCESS_DB
                    FROM 
                        {cde_control}.MAINFRAME_FEEDS_MASTER_INFO
                    WHERE
                        FILE_NAME='{FILENAME}'
                    """.format(FILENAME=FILE_NAME,cde_control=CDE_CONTROL)).collect()
                    
            FILE_TYPE , STAGING_TABLE_NAME , PROCESS_TABLE_NAME, CDE_SOURCE_FIELDS, DERIVED_FIELDS , HIVE_SCHEMA_NAME , KEY_FIELDS, SECT_CODE_SELECT_STR , DML_FLAG ,DATE_STR,CDE_STAGING , CDE_PROCESS = info[0][1],info[0][2].lower(),info[0][3].lower(),info[0][4],info[0][5],info[0][6],info[0][7],info[0][8],info[0][9],info[0][10],info[0][11].lower(),info[0][12].lower()
            VAR_STR="FILE_TYPE : "+FILE_TYPE + " , STAGING_TABLE_NAME : "+STAGING_TABLE_NAME+ " , PROCESS_TABLE_NAME : "+PROCESS_TABLE_NAME+ ", CDE_SOURCE_FIELDS : "+CDE_SOURCE_FIELDS+" , DERIVED_FIELDS : "+DERIVED_FIELDS+" , HIVE_SCHEMA_NAME : "+HIVE_SCHEMA_NAME+" , KEY_FIELDS : "+KEY_FIELDS+" , SECT_CODE_SELECT_STR : " + SECT_CODE_SELECT_STR+" , DML_FLAG : " + DML_FLAG
            xdpLogger('xDP-INF-025',comment=VAR_STR)
        except Exception as e:
            print("Exception while extracting information from master control table cde_control.MAINFRAME_FEEDS_MASTER_INFO")
            print("EXCEPTION :",str(e))
            xdpLogger('xDP-ERR-117',comment=e)            
            sys.exit(1)

        '''
        Extracting batch information from cde source batch id control table.
        '''

        try:
            batch_info=spark.sql("""
                                SELECT
                                    BATCH_DATE,
                                    CASE 
                                        WHEN 'RBS'=='{sysparm}' THEN RBS_BATCH_ID
                                        WHEN 'NWB'=='{sysparm}' THEN NWB_BATCH_ID
                                        WHEN 'UBN'=='{sysparm}' THEN UBN_BATCH_ID
                                        WHEN 'UBS'=='{sysparm}' THEN UBR_BATCH_ID
                                    ELSE GRP_BATCH_ID
                                    END AS BATCH_ID
                                FROM
                                    {cde_control}.SOURCING_BATCH_ID_CONTROL_TABLE
                            """.format(cde_control=CDE_CONTROL,sysparm=SYSPARM)).collect()
        
            BATCH_ID = batch_info[0][1]
     
        except Exception as e:
            print("Exception while extracting batch information from control table cde_control.SOURCING_BATCH_ID_CONTROL_TABLE")
            print("EXCEPTION :",str(e))
            xdpLogger('xDP-ERR-117',comment=e)            
            sys.exit(1)

        '''
        Extratcting derived columns info from master table
        '''

        DERIVED_COLUMNS=DERIVED_FIELDS.split('|')
        SQL_STR=DATE_STR
        if (FILE_TYPE == 'MONTHLY') or (FILE_TYPE == 'MID-MONTH'):
            for col in DERIVED_COLUMNS:
                if col.upper()=="EFFECTIVE_START_DT":
                    SQL_STR+="from_unixtime(UNIX_TIMESTAMP('{batch_date}','yyyy-MM-dd'),'yyyy-MM-01') AS {COL},".format(batch_date=BATCH_DATE,COL=col)        
                elif col.upper()=="EFFECTIVE_END_DT":
                    SQL_STR+="LAST_DAY('{batch_date}') AS {COL},".format(batch_date=BATCH_DATE,COL=col)    
                elif col.upper()=="LAST_UPDATED_DT":
                    SQL_STR+="CURRENT_DATE() AS {COL},".format(COL=col)        
                elif col.upper()=="LAST_UPDATED_TM":
                    SQL_STR+="SUBSTR(NOW(),12,8) AS {COL},".format(COL=col)    
                elif col.upper()=="LOADED_BATCH_ID":
                    SQL_STR+="{batch_id}".format(batch_id=BATCH_ID,COL=col) 
                elif col.upper()=="UPDATED_BATCH_ID":
                    SQL_STR+=",NULL".format(COL=col) 
            xdpLogger('xDP-INF-025',comment="Derived column string : {sql_str}".format(sql_str=SQL_STR))    

            if DML_FLAG.upper() == 'S':
                SELECT_STRING=SECT_CODE_SELECT_STR.format(cde_staging=CDE_STAGING,sql_str=SQL_STR,batch_date=BATCH_DATE,batch_dt=batch_dt,file_fields=CDE_SOURCE_FIELDS)
                query1="""
                    INSERT OVERWRITE TABLE {cde_process}.{PROCESS_TABLE}
                    PARTITION (BATCH_MTH)
                    {SPLIT_SELECT_STR}
                    """.format(cde_staging=CDE_STAGING,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME,SPLIT_SELECT_STR=SELECT_STRING,batch_date=BATCH_DATE) 
            else:
                query1="""
                    INSERT OVERWRITE TABLE {cde_process}.{PROCESS_TABLE}
                    PARTITION (BATCH_MTH)
                    SELECT
                        {file_fields},
                        {sql_str},
                        from_unixtime(UNIX_TIMESTAMP('{batch_date}','yyyy-MM-dd'),'yyyyMM') AS BATCH_MTH
                    FROM 
                        {cde_staging}.{STAGING_TABLE}
                        WHERE BATCH_DT = '{batch_dt}'
                    """.format(cde_staging=CDE_STAGING,cde_process=CDE_PROCESS,file_fields=CDE_SOURCE_FIELDS,sql_str=SQL_STR,batch_date=BATCH_DATE,STAGING_TABLE=STAGING_TABLE_NAME,PROCESS_TABLE=PROCESS_TABLE_NAME, batch_dt=batch_dt)
        else:
            for col in DERIVED_COLUMNS:
                if col.upper()=="EFFECTIVE_START_DT":
                    SQL_STR+="'{batch_date}' AS {COL},".format(batch_date=BATCH_DATE,COL=col)        
                elif col.upper()=="EFFECTIVE_END_DT":
                    SQL_STR+="'9999-12-31' AS {COL},".format(COL=col)    
                elif col.upper()=="LAST_UPDATED_DT":
                    SQL_STR+="CURRENT_DATE() AS {COL},".format(COL=col)        
                elif col.upper()=="LAST_UPDATED_TM":
                    SQL_STR+="SUBSTR(NOW(),12,8) AS {COL},".format(COL=col)    
                elif col.upper()=="LOADED_BATCH_ID":
                    SQL_STR+="{batch_id},".format(batch_id=BATCH_ID,COL=col)
                elif col.upper()=="UPDATED_BATCH_ID":
                    SQL_STR+="NULL".format(COL=col)   
                
            xdpLogger('xDP-INF-025',comment="Derived column string : {sql_str}".format(sql_str=SQL_STR))   

            if DML_FLAG.upper() == 'S':
                SELECT_STRING=SECT_CODE_SELECT_STR.format(cde_staging=CDE_STAGING,sql_str=SQL_STR,batch_date=BATCH_DATE,batch_dt=batch_dt,file_fields=CDE_SOURCE_FIELDS)
                query1="""
                    INSERT OVERWRITE TABLE {cde_process}.{PROCESS_TABLE}
                    PARTITION (BATCH_DY)
                        {SPLIT_SELECT_STR}
                    """.format(cde_staging=CDE_STAGING,cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME,SPLIT_SELECT_STR=SELECT_STRING,batch_date=BATCH_DATE) 
            else:
                query1="""
                    INSERT OVERWRITE TABLE {cde_process}.{PROCESS_TABLE}
                    PARTITION (BATCH_DY)
                    SELECT
                        {file_fields},
                        {sql_str},
                        from_unixtime(UNIX_TIMESTAMP('{batch_date}','yyyy-MM-dd'),'yyyyMMdd') AS BATCH_DY
                    FROM 
                        {cde_staging}.{STAGING_TABLE}
                        WHERE batch_dt = '{batch_dt}'
                    """.format(cde_staging=CDE_STAGING,cde_process=CDE_PROCESS,file_fields=CDE_SOURCE_FIELDS,sql_str=SQL_STR,batch_date=BATCH_DATE,STAGING_TABLE=STAGING_TABLE_NAME,PROCESS_TABLE=PROCESS_TABLE_NAME, batch_dt=batch_dt)

        '''
        Insert overwriting current day/month data basd on file type into final table
        '''

        try:
            xdpLogger('xDP-INF-017',comment="Data load process for {cde_process}.{PROCESS_TABLE} has started".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            spark.sql(query1)
            xdpLogger('xDP-INF-018',comment="Data load process for {cde_process}.{PROCESS_TABLE} has completed".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            list_1= (snap_dt,str(BATCH_DATE).replace('-',''),file_nm,JOB_NAME,'ProcessLayerLoad', CDE_PROCESS+'.'+PROCESS_TABLE_NAME, 'Pass',str(datetime.now())[:-7],application_id,date.today())
            success_list.append(list_1)
            writeStatus2FileIngestion(success_list,spark)
            #write ok file
            try:
                print("writing ok file")
                ok_file_nm = JOB_NAME+'_'+snap_dt+'_'+str(BATCH_DATE).replace('-','')+'_COMPLETED.ok'
                print(ok_file_nm)
                completed_file = subprocess.call(['touch', ok_file_nm])
                print(completed_file)
                if completed_file == 0:
                    xdpLogger('xDP-INF-010',comment='Done File created successfully: {}'.format(ok_file_nm))
                    try:
                        copy_to_s3 = subprocess.call(['aws','s3','mv', ok_file_nm, job_option_config.done_file_location])
                        xdpLogger('xDP-INF-010',comment='Done File moved successfully: {}'.format(ok_file_nm))
                    except Exception as e:
                        xdpLogger('xDP-WAR-040',comment='Done File moved failed: {}'.format(ok_file_nm))
                        xdpLogger('xDP-ERR-117',comment=e)
                else:
                    xdpLogger('xDP-ERR-117',comment='Error while creating .completed file: {}'.format(ok_file_nm))
                    sys.exit(0)

            except Exception as exp:
                xdpLogger('xDP-ERR-117',comment=exp)
                spark.stop()
                sys.exit(1)

        except Exception as e: 
            print("Exception while inserting into {cde_process}.{PROCESS_TABLE}".format(cde_process=CDE_PROCESS,PROCESS_TABLE=PROCESS_TABLE_NAME))
            list_2 = (snap_dt,str(BATCH_DATE).replace('-',''),file_nm,JOB_NAME,'ProcessLayerLoad', CDE_PROCESS+'.'+PROCESS_TABLE_NAME, 'Fail',str(datetime.now())[:-7],application_id,date.today())
            fail_list.append(list_2)
            writeStatus2FileIngestion(fail_list,spark)
            print("EXCEPTION :",str(e)) 
            xdpLogger('xDP-ERR-117',comment=e)            
            sys.exit(1)

        '''
        updating source batch control  table for cde batch
        '''
        spark.sql("""INSERT INTO TABLE {cde_control}.SOURCE_BATCH_CONTROL_TABLE 
                    PARTITION (LOAD_DATE)
                    SELECT
                        '{file_name}', 
                        '{brand}', 
                        '{db_name}', 
                        '{table_name}',
                        '{batch_dt}',
                        {batch_id},
                        'S' as status, 
                        current_timestamp()  as load_datetime,
                        current_date()
                    """.format(cde_control=CDE_CONTROL,file_name=file_nm,brand=SYSPARM,db_name=CDE_PROCESS,table_name=PROCESS_TABLE_NAME,batch_dt=BATCH_DATE,batch_id=BATCH_ID))

        xdpLogger('xDP-INF-014',comment="CDER sourcing data loading process for feed {FEED_NAME} till cde_process layer has completed".format(FEED_NAME=file_nm))

    spark.stop()

if __name__ == "__main__":
    """ 
    Description: This is the entry point for execution of this script.
    The steps in sequence define the logical flow of the code
    """
    main()
