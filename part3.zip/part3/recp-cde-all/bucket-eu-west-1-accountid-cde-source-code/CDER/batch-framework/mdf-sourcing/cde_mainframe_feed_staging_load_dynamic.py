from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark.sql.functions import *
import sys
import os
import re
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import create_logger, xdpLogger, get_logger
import subprocess
from datetime import datetime, date



def writeStatus2FileIngestion(input_list,spark):
    try:
        get_logger()
        sc = spark.sparkContext
        result_df = sc.parallelize(input_list).toDF(["snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt"]).select("snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt")
        if result_df.count()>0:
            result_df.write.mode('append').insertInto(job_option_config.file_ingestion_detail,overwrite=False)
            xdpLogger('xDP-INF-111',comment='Status updated in File Ingestion detail table')
            return True
    except Exception as e:
        xdpLogger('xDP-ERR-117',comment='Error while updating File Ingestion detail table')
        xdpLogger('xDP-ERR-117',comment=e)
        pass

def main():
    spark = SparkSession \
    .builder \
    .appName("MAINFRAME FEED STAGING LOADING") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .getOrCreate() 

    spark.sparkContext.setLogLevel("ERROR")
    conflist = spark.sparkContext.getConf().getAll()
    for i in conflist:
        if 'spark.app.id' in i[0]:
            application_id = i[1]


    ###   /*********************************************************************************** 
    ###   * Job:             CDE_MAINFRAME_FEED_STAGING_LOAD_ETL                             * 
    ###   * Description:     READING MAINFRAME FIXED WIDTH, PIPE DELIMITED ,COMMA DELIMITED  *
    ###   *                  FILES AND INSERTING RECORDS IN STAGING TABLE                    * 
    ###   * Created by:      Binaya Lenka(kumabbn)/Accenture                                 *
    ###   *                  Rahul Ranjan(ranjarz)/Accenture                                 *
    ###   *                  Pankaj Gupta(guptpdh)/Accenture                                 * 
    ###   ************************************************************************************/ 

    '''
    Reading required parameters passed as arguments
    '''

    PATH=setup_module_config_path.path
    JOB_NAME = sys.argv[1].upper() 
    FILE_NAME = sys.argv[2].upper()
    SYSPARM = sys.argv[3].upper()
    CDE_CONTROL=job_option_config.cde_databases["CONTROL"]
    ENV = job_option_config.CDE_ENV.upper()
    DATA_IN_BUCKET=job_option_config.CDE_DATAIN_BUCKET
    BUCKET=job_option_config.CDE_BUCKET
    create_logger('MAINFRAME FEED STAGING LOADING : {FEED_NAME}'.format(FEED_NAME=FILE_NAME))
    staging_layer_query = """select file_ingestion_ft.* from
                                      (select * from {} where file_prefix_nm = '{}' and action_type='FileTransfer' and action_typ_details = 'ValidFileTransfer' and status='Pass' and file_nm like '{}%' order by file_nm) file_ingestion_ft
                                      left join
                                      (select * from {} where file_prefix_nm = '{}' and action_type = 'StageLayerLoad' and status='Pass' and file_nm like '{}%'  ) file_ingestion_sll
                                       on file_ingestion_ft.file_prefix_nm = file_ingestion_sll.file_prefix_nm and file_ingestion_ft.snap_dt = file_ingestion_sll.snap_dt and file_ingestion_ft.file_nm = file_ingestion_sll.file_nm
                                       where file_ingestion_sll.file_prefix_nm is null """.format(job_option_config.file_ingestion_detail,JOB_NAME,FILE_NAME,job_option_config.file_ingestion_detail,JOB_NAME,FILE_NAME)
    stage_file_df = spark.sql(staging_layer_query)
    stage_file_df.show()
    #file_names = [row[0] for row in stage_file_df.select('file_nm').collect()]
    #print(file_names)
    if stage_file_df.count() == 0:
        xdpLogger('xDP-INF-111',comment="No files to process for staging layer load for:  {}".format(JOB_NAME))
        sys.exit(0)

    for item in stage_file_df.collect():
        file_item = item['file_nm']
        batch_dt = item['batch_dt']
        create_logger('MAINFRAME FEED STAGING LOADING : {FEED_NAME}'.format(FEED_NAME=file_item))
        xdpLogger('xDP-INF-013',comment="CDER sourcing data loading process till staging layer for feed {FEED_NAME} has started".format(FEED_NAME=file_item))


        '''
        Extracting required information from master table for file information 
        '''
        try:
            info=spark.sql("""
                        SELECT
                            FILE_NAME,
                            FILE_TYPE,
                            STAGING_TABLE_NAME,
                            SOURCE_FIELDS,
                            DERIVED_FIELDS,
                            HIVE_SCHEMA_NAME,
                            KEY_FIELDS,
                            DML_FLAG,
                            STG_DB,
                            PROCESS_DB
                        FROM 
                            {cde_control}.MAINFRAME_FEEDS_MASTER_INFO
                        WHERE
                            FILE_NAME='{FILENAME}'
                        """.format(FILENAME=FILE_NAME,cde_control=CDE_CONTROL)).collect()
                    
            FILE_TYPE , STAGING_TABLE_NAME, SOURCE_FIELDS, DERIVED_FIELDS , HIVE_SCHEMA_NAME , KEY_FIELDS , DML_FLAG ,CDE_STAGING , CDE_PROCESS= info[0][1],info[0][2].lower(),info[0][3],info[0][4],info[0][5],info[0][6],info[0][7],info[0][8].lower(),info[0][9].lower()
            VAR_STR="FILE_TYPE : "+FILE_TYPE + ", STAGING_TABLE_NAME : "+STAGING_TABLE_NAME+ ", SOURCE_FIELDS : "+SOURCE_FIELDS+" , DERIVED_FIELDS : "+DERIVED_FIELDS+" , HIVE_SCHEMA_NAME : "+HIVE_SCHEMA_NAME+" , KEY_FIELDS : "+KEY_FIELDS+" , DML_FLAG : "+DML_FLAG
            xdpLogger('xDP-INF-025',comment=VAR_STR)
        except Exception as e:
            print("Exception while extracting information from master control table cde_control.MAINFRAME_FEEDS_MASTER_INFO")
            print("EXCEPTION :",str(e))
            xdpLogger('xDP-ERR-117',comment=e)     
            sys.exit(1) 


        '''
        Extracting batch information from cde source batch id control table.
        '''

        try:
            batch_info=spark.sql("""
                                SELECT
                                    BATCH_DATE,
                                    CASE 
                                        WHEN 'RBS'=='{sysparm}' THEN RBS_BATCH_ID
                                        WHEN 'NWB'=='{sysparm}' THEN NWB_BATCH_ID
                                        WHEN 'UBN'=='{sysparm}' THEN UBN_BATCH_ID
                                        WHEN 'UBS'=='{sysparm}' THEN UBR_BATCH_ID
                                    ELSE GRP_BATCH_ID
                                    END AS BATCH_ID
                                FROM
                                    {cde_control}.SOURCING_BATCH_ID_CONTROL_TABLE
                            """.format(cde_control=CDE_CONTROL,sysparm=SYSPARM)).collect()
        
            BATCH_ID = batch_info[0][1]         
        except Exception as e:
            print("Exception while extracting batch information from control table cde_control.SOURCING_BATCH_ID_CONTROL_TABLE")
            print("EXCEPTION :",str(e))
            xdpLogger('xDP-ERR-117',comment=e)
            sys.exit(1)
        
        '''
        Defined s3 buckets path based on environment variable
        '''
    

        #S3_FILE_LANDING_ZONE='s3://'+DATA_IN_BUCKET+'/data-in/cde/feeds/mdf/'
        S3_FILE_LANDING_ZONE = job_option_config.processing_zone + JOB_NAME + "/"
        S3_STAGING_ZONE='s3://'+BUCKET+'/transformation/cde'
        S3_HEADER_TRAILER_INFO='s3://'+DATA_IN_BUCKET+'/data-in/cde/header_trailer_info/'
        S3_FILE_ARCHIVAL_ZONE='s3://'+DATA_IN_BUCKET+'/data-in/cde/archival/mainframe-feeds/'        
        success_list = []
        fail_list = []

        '''
        Creating table schema based on mainframe copybook
        '''
    
        HIVE_CMD="hive -f  "+PATH+"hive_ddl/transformation/cde_staging/" + HIVE_SCHEMA_NAME + " --hivevar db_name='" + CDE_STAGING.lower() + "'  --hivevar table_name='" + STAGING_TABLE_NAME + "' --hivevar s3_output_url='" + S3_STAGING_ZONE + "'"
        os.system(HIVE_CMD)

        xdpLogger('xDP-INF-021',comment="Staging layer tables created sucessfully")

        '''
        Removing header and tailer from feed file and populating mainframe staging table
        '''    

        MV_CMD ="sudo aws s3 cp " + S3_FILE_LANDING_ZONE + file_item +" - | sed '1d;$d;s/\r//g' | aws s3 cp - " + S3_STAGING_ZONE + '/' + CDE_STAGING.lower() + '/' + STAGING_TABLE_NAME +'_managed/' + file_item 
        os.system(MV_CMD)

        xdpLogger('xDP-INF-010',comment="source file transferred to managed table loacation")

        '''
        Creating header and tailer file from feed file for validation purpose
        '''    
    
        HEADER_TRAILER_INFO="sudo aws s3 cp " + S3_FILE_LANDING_ZONE + file_item +" - | sed -e 1b -e '$!d' | aws s3 cp - " + S3_HEADER_TRAILER_INFO + CDE_STAGING.lower() + '/' + STAGING_TABLE_NAME  +'/H_T_'+ file_item 
        os.system(HEADER_TRAILER_INFO)
    
        '''
        Download header file to emr and extract header and tailer info
        '''
    
        F_DOWNLOAD="sudo aws s3 cp " + S3_HEADER_TRAILER_INFO + CDE_STAGING.lower() + '/' + STAGING_TABLE_NAME  +'/H_T_'+ file_item   + " ." 
        os.system(F_DOWNLOAD)

        RMV_UNICODE="sudo LANG=C sed -i $'s/[^[:print:]\t]/,/g' H_T_" + file_item 
        os.system(RMV_UNICODE)
    
        '''
        Extracting header info  
        '''
        out=subprocess.Popen(['head', '-n', '1', 'H_T_{file_name}'.format(file_name=file_item)],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT)
        stdout,stderr = out.communicate()
        print(stdout)
        print(stderr)
        if re.search(r'\d{4}-\d{2}-\d{2},\d{2}:\d{2}:\d{2}', str(stdout)):
            FILE_DATE=re.search(r'\d{4}-\d{2}-\d{2},\d{2}:\d{2}:\d{2}', str(stdout)).group().replace(',',' ')
        elif re.search(r'\d{4}-\d{2}-\d{2}', str(stdout)):
            FILE_DATE=re.search(r'\d{4}-\d{2}-\d{2}', str(stdout)).group()
        elif re.search(r'\d{8}', str(stdout)):
            FILE_DATE=re.search(r'\d{8}', str(stdout)).group()
        else:
            FILE_DATE= str(stdout)

        SNAP_DT = FILE_DATE.split(' ')[0].replace('-','')

        #xdpLogger('xDP-INF-025',comment="FILE DATE: {file_date}".format(file_date=FILE_DATE))
   
        '''
        Exracting Trailer Info 
        '''    
    
        out=subprocess.Popen(['tail', '-n', '1', 'H_T_{file_name}'.format(file_name=file_item)],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT)  
        stdout,stderr = out.communicate()
    
        count=re.split(r'[,\s]\s*', str(stdout))
        cnt=[s for s in count if s.isdigit()]

        if not cnt:
            FILE_COUNT=str(stdout)
        else:
            FILE_COUNT=cnt[0]

        #xdpLogger('xDP-INF-025',comment="FILE COUNT: {file_count}".format(file_count=FILE_COUNT))    

        '''
        Selecting the count(*) inserted at staging layer and assigning to variable
        '''

        RECORD_COUNT= spark.sql("""
                               SELECT COUNT(*) FROM {TDDB_INST}.{TABLE}_MANAGED
                """.format(TDDB_INST=CDE_STAGING,TABLE=STAGING_TABLE_NAME)).collect()[0][0]

        #xdpLogger('xDP-INF-025',comment="RECORD COUNT: {record_count}".format(record_count=RECORD_COUNT))    

        RM_CMD= "sudo rm H_T_{file_name}".format(file_name=file_item)
        os.system(RM_CMD)  

        '''
        Inserting file load status in control table and aborting the process in case of mismatch/failure during loading
        '''

        query1="""
                INSERT INTO TABLE {cde_control}.MAINFRAME_FEEDS_ROW_COUNT
                PARTITION (LOAD_DATE)
                SELECT
                    '{feed_name}',
                    '{brand}',
                    coalesce(from_unixtime(UNIX_TIMESTAMP(cast('{header_datetime}' as string),'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:mm:ss'),from_unixtime(UNIX_TIMESTAMP(cast('{header_datetime}' as string),'yyyyMMdd'),'yyyy-MM-dd HH:mm:ss'),from_unixtime(UNIX_TIMESTAMP(cast('{header_datetime}' as string),'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss')),
                    '{tailer_row_count}',
                    {staging_table_row_count},
                    CASE WHEN CAST('{tailer_row_count}' AS INT)={staging_table_row_count} THEN 'S' ELSE 'F' END ,
                    CURRENT_TIMESTAMP(),
                    null,
                    CASE WHEN CAST('{tailer_row_count}' AS INT)={staging_table_row_count} THEN null ELSE 'Mismatch between feed record count and staging table record count' END ,
                    CURRENT_DATE() AS LOAD_DATE
                """.format(cde_control=CDE_CONTROL,feed_name=file_item,file_type=FILE_TYPE,brand=SYSPARM,header_datetime=FILE_DATE,tailer_row_count=FILE_COUNT,staging_table_row_count=RECORD_COUNT)

        '''
        Creating formatted table with actual data types
        '''
        if DML_FLAG.upper() == 'Y' :
            #DEL_DATA="sudo aws s3 rm " + S3_STAGING_ZONE + "/" +CDE_STAGING +"/" + STAGING_TABLE_NAME +" --recursive"
            #os.system(DEL_DATA)
            query2="""
                INSERT OVERWRITE TABLE {TDDB_INST}.{TABLE}
                PARTITION (batch_dt ='{batch_dt}') 
                SELECT
                    {FILE_FIELDS},
                    ROW_PROCESS_TYPE
                FROM 
                    {TDDB_INST}.{TABLE}_MANAGED
                """.format(TDDB_INST=CDE_STAGING,TABLE=STAGING_TABLE_NAME,FILE_FIELDS=SOURCE_FIELDS,batch_dt=batch_dt)  
        else:
            query2="""
                INSERT OVERWRITE TABLE {TDDB_INST}.{TABLE}
                PARTITION (batch_dt ='{batch_dt}')
                SELECT
                    {FILE_FIELDS}
                FROM 
                    {TDDB_INST}.{TABLE}_MANAGED
                """.format(TDDB_INST=CDE_STAGING,TABLE=STAGING_TABLE_NAME,FILE_FIELDS=SOURCE_FIELDS,batch_dt=batch_dt)  

        if int(FILE_COUNT) == int(RECORD_COUNT):
            try:
                xdpLogger('xDP-INF-017',comment="Data load process from {table_name}_managed table to staging final table {table_name} has started".format(table_name=STAGING_TABLE_NAME))
                spark.sql(query2)
                xdpLogger('xDP-INF-018',comment="Data loading process from {table_name}_managed table to staging final table {table_name} has completed".format(table_name=STAGING_TABLE_NAME))
                xdpLogger('xDP-INF-017',comment="Data load process for control table mainframe_feeds_row_count has started")
                spark.sql(query1)
                xdpLogger('xDP-INF-018',comment="Data loading process for control table mainframe_feeds_row_count has completed")
                list_1= (SNAP_DT,str(batch_dt).replace('-',''),file_item,JOB_NAME,'StageLayerLoad', CDE_STAGING+'.'+STAGING_TABLE_NAME, 'Pass',str(datetime.now())[:-7],application_id,date.today())
                success_list.append(list_1)
                writeStatus2FileIngestion(success_list,spark)

            except Exception as e:
                print("Exception while inserting into staging table staging.{TABLE}".format(TABLE=STAGING_TABLE_NAME))
                list_2 = (SNAP_DT,str(batch_dt).replace('-',''),file_item,JOB_NAME,'StageLayerLoad', CDE_STAGING+'.'+STAGING_TABLE_NAME, 'Fail',str(datetime.now())[:-7],application_id,date.today())
                fail_list.append(list_2)
                writeStatus2FileIngestion(fail_list,spark)
                print("EXCEPTION :",str(e)) 
                xdpLogger('xDP-ERR-117',comment=e)
                sys.exit(1)    
        else:
            try:
                xdpLogger('xDP-INF-017',comment="Data load process for control table mainframe_feeds_row_count has started")
                spark.sql(query1)
                xdpLogger('xDP-INF-018',comment="Data loading process for control table mainframe_feeds_row_count has completed")
                xdpLogger('xDP-ERR-117',comment="File and Record cound mismatch at managed table Layer")                
                sys.exit(1)
            except Exception as e: 
                print("Exception while inserting into control table CDE_CONROL.MAINFRAME_FEEDS_ROW_COUNT".format(TABLE=STAGING_TABLE_NAME))
                print("EXCEPTION :",str(e))   
                xdpLogger('xDP-ERR-117',comment=e)                
                sys.exit(1)        

        '''
        Dropping managed table
        '''

        spark.sql("DROP TABLE IF EXISTS {TDDB_INST}.{TABLE}_MANAGED".format(TDDB_INST=CDE_STAGING,TABLE=STAGING_TABLE_NAME))

        '''
        Archiving current day file
        '''
    
        #NOW = datetime.now().strftime("%Y-%m-%d")
        #ARCHIVE_FILE="aws s3 mv "+ S3_FILE_LANDING_ZONE + file_item + " " + S3_FILE_ARCHIVAL_ZONE + str(BATCH_DATE) +"/" +  file_item
        #os.system(ARCHIVE_FILE)
        #xdpLogger('xDP-INF-010',comment="source file has been archived")
        print("Process to load staging layer with feed data Completed")
        xdpLogger('xDP-INF-014',comment="CDER sourcing data loading process for feed {FEED_NAME} till staging layer has completed".format(FEED_NAME=file_item))

    spark.stop()

    
if __name__ == "__main__":
    """ 
    Description: This is the entry point for execution of this script.
    The steps in sequence define the logical flow of the code
    """
    main()