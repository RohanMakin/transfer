import os
import sys
path="/home/hadoop/cde/CDER/"
sys.path.append(os.path.abspath("/home/hadoop/cde/CDER/xdp/"))
sys.path.append(os.path.abspath("/home/hadoop/cde/CDER/module-udf/"))