import sys
import os
from datetime import datetime, date
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import sys
from config import setup_module_config_path
import subprocess
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import get_logger,create_logger,xdpLogger

import csv


def get_spark():
    """
    Get a spark session for processiong
    """
    new_spark = SparkSession \
    .builder \
    .appName("XDP_FileIngestion") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .config("spark.sql.broadcastTimeout", "3600") \
    .config("spark.dynamicAllocation.executorIdleTimeout ", "300").enableHiveSupport() \
    .getOrCreate()
    new_spark.sparkContext.setLogLevel("ERROR")
    return new_spark




def prepare_file_action_data(application_id):
    get_logger()
    query = """select file_arrival.snap_dt, file_arrival.batch_dt, file_arrival.arrival_date, file_arrival.arrival_time, file_arrival.file_nm, file_arrival.file_prefix_nm, file_master.schedule_interval,file_master.max_wait_time, file_master.scheduled_time from {file_arrival_status} file_arrival
left join
{cder_mainframe_sourcing_master} file_master
on 
lower(concat(substring(file_nm, 1,instr(file_nm,'.')-1),".csv")) = lower(file_master.file_name)""".format(file_arrival_status=job_option_config.file_arrival_status,cder_mainframe_sourcing_master=job_option_config.cder_mainframe_sourcing_master)
    xdpLogger('xDP-INF-009',comment='File action query executed: {}'.format(query))
    file_schedule = spark.sql(query)
    file_schedule.createOrReplaceTempView("file_schedule")
    df = spark.sql("select * from file_schedule")
    #df.show()

    schedule_flag_query = """select *, ((bigint(to_timestamp(arrival_time)))- (bigint(to_timestamp(scheduled_time))))/60 as diff from file_schedule"""
    schedule_flag_df = spark.sql(schedule_flag_query)
    #schedule_flag_df.show()
    schedule_flag_df = schedule_flag_df.withColumn('status',when(col('diff')-col('max_wait_time')>0,"SLA BREACHED").when(col('diff')<0,"EARLY_FILE").when(col('diff').isNull(), None).otherwise("SCHEDULED_FILE"))
    #schedule_flag_df.show()
    schedule_flag_df.createOrReplaceTempView("schedule_flag_df")

    arrival_action_join_query = """select schedule_flag_df.snap_dt, schedule_flag_df.batch_dt, schedule_flag_df.file_nm, schedule_flag_df.file_prefix_nm, schedule_flag_df.status  from schedule_flag_df left join {file_action} file_action on schedule_flag_df.file_nm = file_action.file_nm and schedule_flag_df.snap_dt = file_action.snap_dt and schedule_flag_df.file_prefix_nm = file_action.file_prefix_nm where file_action.file_nm is null and file_action.file_prefix_nm is null""".format(file_action=job_option_config.file_action)
    xdpLogger('xDP-INF-009',comment='Query for new files executed: {}'.format(arrival_action_join_query))
    action_df = spark.sql(arrival_action_join_query)
    if action_df.count() > 0:
        #print("No new files to log")
        #spark.stop()
        #sys.exit(0)
        for action_item in action_df.collect():
            file_status = action_item['status']
            if file_status == 'SLA BREACHED':
                file_prefix = action_item['file_prefix_nm']
                snap_dt = action_item['snap_dt']
                batch_dt = action_item['batch_dt']
                ok_file_name = file_prefix+'_'+snap_dt+'_'+ batch_dt+'_SLABREACHED.ok'
                try:
                    a = subprocess.call(['touch',ok_file_name])
                    if a == 0:
                        xdpLogger('xDP-INF-010',comment='ok file {} generated'.format(ok_file_name))
                        try:
                            b = subprocess.call(['aws', 's3', 'mv', ok_file_name, job_option_config.done_file_location])
                            xdpLogger('xDP-INF-010',comment='SLA BREACHED File is {} moved'.format(ok_file_name))

                        except Exception as e:
                            xdpLogger('xDP-WAR-040',comment='Done file {} movement failed'.format(ok_file_name))
                            xdpLogger('xDP-ERR-117',comment=e)
                            sys.exit(0)
                except Exception as e:
                    xdpLogger('xDP-ERR-117',comment='Done file {} not created'.format(ok_file_name))
                    xdpLogger('xDP-ERR-117',comment=e)
                    sys.exit(0)


        action_df = action_df.withColumn('application_id',lit(application_id)).withColumn('run_dt',lit(date.today()))
        #write to file ingestion table
        ingestion_df = action_df.withColumn('action_type',lit('File Action')).withColumn('action_typ_details',col('status')).withColumnRenamed('status','status_flag').withColumn('status',when(col('status_flag')=='SLA BREACHED',"Fail").otherwise("Pass")).withColumn('time',lit(str(datetime.now())[:-7])).withColumn('application_id', lit(application_id)).select("snap_dt","batch_dt","file_nm","file_prefix_nm","action_type","action_typ_details","status","time","application_id","run_dt")
        #ingestion_df.show()
        ingestion_df.write.mode('append').insertInto(job_option_config.file_ingestion_detail,overwrite=False)
        xdpLogger('xDP-INF-111',comment='Status updated in File Ingestion detail table')
        #action_df.show()
    #write to file action table
        action_df.write.mode('append').insertInto(job_option_config.file_action,overwrite=False)
        xdpLogger('xDP-INF-111',comment='Status updated in File Action table')

    batch_date_sql = "select batch_date from {}".format(job_option_config.sourcing_batch_id_control)
    batch_date = spark.sql(batch_date_sql).collect()[0][0]
    batch_dt = str(batch_date).replace('-','')
    print(batch_dt)
    #print("No new files arrived")
    
    missing_sql = "select a.file_nm as file_prefix_nm,a.expected_time, a.run_dt, b.arrival_time, c.status from(select * from {todays_flow_schedule} where run_dt = '{BATCH_DATE}' and case when (substring(current_timestamp ,12,2) >= 20 and substring(current_timestamp ,12,2) <= 23) then case when (substring(to_timestamp(expected_time) ,12,2) >= 20 and substring(to_timestamp(expected_time) ,12,2) <= 23) then to_timestamp(expected_time) < current_timestamp else from_unixtime(unix_timestamp(to_timestamp(expected_time))+1*86400,'yyyy-MM-dd HH:mm:ss') < current_timestamp end else case when (substring(to_timestamp(expected_time) ,12,2) >= 20 and substring(to_timestamp(expected_time) ,12,2) <= 23) then from_unixtime(unix_timestamp(to_timestamp(expected_time))-1*86400,'yyyy-MM-dd HH:mm:ss')< current_timestamp else to_timestamp(expected_time) < current_timestamp end end) a left join {file_arrival_status} b on a.file_nm = b.file_prefix_nm and b.batch_dt = '{BATCH_DT}' left join {file_action} c on a.file_nm = c.file_prefix_nm and c.batch_dt = '{BATCH_DT}' where b.file_nm is null and c.file_prefix_nm is null".format(todays_flow_schedule=job_option_config.todays_flow_schedule,file_arrival_status=job_option_config.file_arrival_status,file_action=job_option_config.file_action,BATCH_DATE=batch_date,BATCH_DT=batch_dt)
    xdpLogger('xDP-INF-009',comment='Query for missing files: {}'.format(missing_sql))
    missing_df = spark.sql(missing_sql)
    #missing_df.show()
    #HOLIDAY_FILENM="HolidayFiles.csv"
    # account_id="978523670193"
    HOLIDAY_FILENM=job_option_config.HOLIDAY_FILENM
    HOLIDAY_LIST_PATH=job_option_config.HOLIDAY_FILEPATH
    #HOLIDAY_LIST_PATH="s3://bucket-eu-west-1-{}-risk-cicd/cde/dags/config/HolidayFiles.csv".format(account_id)
    #subprocess.call(['aws','s3','cp',job_option_config.HOLIDAY_FILEPATH, HOLIDAY_FILENM])
    subprocess.call(['aws','s3','cp',HOLIDAY_LIST_PATH, HOLIDAY_FILENM])
    holiday_list=[]

    with open(HOLIDAY_FILENM) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        holiday_list=[row[0] for row in csv_reader][1:]
    #print(holiday_list)
    if missing_df.count() == 0:
        #print("No miss")
        xdpLogger('xDP-INF-111',comment='No new missing files')
        sys.exit(0)
    #missing_df.show()
    for missing_item in missing_df.collect():
        prefix_nm = missing_item['file_prefix_nm']
        missing_ok_file = prefix_nm+'_'+batch_dt+'_MISSING.ok'
        if prefix_nm in holiday_list:
            missing_ok_file = prefix_nm+'_'+batch_dt+'_HOLIDAY_MISS.ok'
        print(missing_ok_file)
        #wite missing.ok file
        try:
            print("writing ok file")
            missing_file = subprocess.call(['touch', missing_ok_file])
            print(missing_file)
            if missing_file == 0:
                xdpLogger('xDP-WAR-030',comment='File {} is missing'.format(missing_ok_file))
                try:
                    copy_to_s3 = subprocess.call(['aws','s3','mv', missing_ok_file, job_option_config.done_file_location])
                    xdpLogger('xDP-INF-010',comment='Done file {} moved'.format(missing_ok_file))
                except Exception as e:
                    xdpLogger('xDP-ERR-117',comment=e)
            else:
                xdpLogger('xDP-ERR-117',comment='Error while creating missing file')
                xdpLogger('xDP-ERR-117',comment=e)
                sys.exit(0)

        except Exception as exp:
            print(exp)
            xdpLogger('xDP-ERR-117',comment=exp)
            spark.stop()
            sys.exit(1)
        
    missing_df = missing_df.withColumn('snap_dt',lit(None)).withColumn('batch_dt',lit(batch_dt)).withColumn('file_nm',lit(None)).withColumn('status',lit('FILE_MISSING')).withColumn('application_id',lit(application_id)).select("snap_dt","batch_dt","file_nm","file_prefix_nm","status","application_id","run_dt")
    #missing_df.show()


    missing_ingestion_df = missing_df.withColumnRenamed('status','action_status').withColumn('action_typ', lit('File Action')).withColumn('action_typ_details',lit('FILE_MISSING')).withColumn('status',lit('Fail')).withColumn('time',lit(str(datetime.now())[:-7])).select("snap_dt","batch_dt","file_nm","file_prefix_nm","action_typ","action_typ_details","status","time","application_id","run_dt")
    #missing_ingestion_df.show()


    #entry to ingestion_deatil table
    missing_ingestion_df.write.mode('append').insertInto(job_option_config.file_ingestion_detail,overwrite=False)
    xdpLogger('xDP-INF-111',comment='Status updated in File Ingestion detail table')

    #entry to file_action table
    missing_df.write.mode('append').insertInto(job_option_config.file_action,overwrite=False)
    xdpLogger('xDP-INF-111',comment='Status updated in File Action table')


if __name__ == "__main__":
    
    try:
        spark = get_spark()
        conflist = spark.sparkContext.getConf().getAll()
        create_logger("CDE_INGESTION_PREPARE_FILE_ACTION")
        xdpLogger('xDP-INF-001')
        for i in conflist:
            if 'spark.app.id' in i[0]:
                application_id = i[1]
        file_action_data = prepare_file_action_data(application_id)
        xdpLogger('xDP-INF-999')

    except Exception as e:
        xdpLogger('xDP-ERR-117',comment=e)
        spark.stop()
        sys.exit(1)

