#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from importlib import reload
reload(sys)
import os
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import subprocess
import botocore.session
from datetime import datetime,timedelta
from datetime import date
from config import setup_module_config_path
from pyspark.sql.functions import col, asc,desc
import job_option_config
from job_option_config import cde_databases, cde_sysparm
from logger import get_logger,create_logger,xdpLogger
from pyspark.sql.utils import CapturedException

cde_control = job_option_config.cde_databases["CONTROL"]
file_ingestion_detail = job_option_config.file_ingestion_detail
file_arrival_status = job_option_config.file_arrival_status
file_action = job_option_config.file_action

def get_spark():
    """
    Get a spark session for processiong
    """
    new_spark = SparkSession \
    .builder \
    .appName("XDP_FileIngestion") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .config("spark.sql.broadcastTimeout", "3600") \
    .config("spark.dynamicAllocation.executorIdleTimeout ", "300").enableHiveSupport() \
    .getOrCreate()
    new_spark.sparkContext.setLogLevel("ERROR")
    return new_spark

def is_table_exists(table_name):
        """
        Check if table_name exists or not
        """
        get_logger()
        xdpLogger('xDP-INF-001')
        try:
                spark.read.table(table_name)
                return True
        except CapturedException:
                return False

def execute_specific_query(query, **kwargs):
    """
    Execute a SQL Statement.
    """
    #query = query.format(**kwargs)
    get_logger()
    xdpLogger('xDP-INF-001')
    xdpLogger('xDP-INF-009',comment="Executing SQL.:{}".format(query))
    try:
        return spark.sql(query)
    except CapturedException as exp:
        xdpLogger('xDP-WAR-053',comment="Query execution failed. Exception logged")
        return False
        xdpLogger('FMREXP',exp)
        xdpLogger('xDP-ERR-117',comment=exp)
        raise frmexceptions.QueryException(exp.desc, exp.stackTrace)



def purge_partition(input_table_nm,max_partitions):
    get_logger()
    xdpLogger('xDP-INF-001')
    
    input_table_name = input_table_nm   
    if not is_table_exists(input_table_name):
        xdpLogger('xDP-WAR-045',comment="Table missing :{}".format(input_table_name))
        return

    is_tb_partitioned = True    
    partition_cols = execute_specific_query("show partitions {}".format(input_table_name))
    if (partition_cols == False):
        is_tb_partitioned = False
        return
    partition_cols.show()
    part_count = partition_cols.count()
    drop_part_count = part_count - int(max_partitions)
    print(drop_part_count)
    if drop_part_count == 0 or drop_part_count < 0:
        print("No partitions to drop")
        return
    partition_cols_list = partition_cols.sort(col("partition").asc()).head(drop_part_count)
    print(partition_cols_list)
    if len(partition_cols_list)==0:
        print("No partitions to purge")
        return
    for part in partition_cols_list:
        part_val_str = part["partition"]
        print(part_val_str)
        part_col = part_val_str.split('=')[0]
        part_val = part_val_str.split('=')[1]
        print(part_col,part_val)
        query = "ALTER TABLE {} DROP PARTITION ({}='{}') PURGE".format(input_table_name,part_col,part_val)
        print(query)
        spark.sql(query)

if __name__ == "__main__":

    spark = get_spark()
    create_logger("PARTITION PURGE")
    xdpLogger('xDP-INF-001')
    #table_name = 'cde_control.file_arrival_status_part'
    default_max_partitions = job_option_config.max_partitions
    path = setup_module_config_path.path   #Used this variable to call partition config csv file
    CDE_PROCESS=job_option_config.cde_databases["PROCESS"]
    CDE_STAGING=job_option_config.cde_databases["STAGING"]
    table_list_query = "select process_table_name from (select distinct mainframe_feed.process_table_name from {} master left join {} mainframe_feed on master.file_name = mainframe_feed.file_name where master.script_to_load_process_layer = 'cde_mainframe_direct_feed_process_load_dynamic.py' ) A where A.process_table_name is not null or A.process_table_name !='' ".format(job_option_config.cder_mainframe_sourcing_master,job_option_config.mainframe_feeds_master_info)
    staging_table_list_query = "select distinct staging_table_name from {} ".format(job_option_config.mainframe_feeds_master_info)
    table_list = spark.sql(table_list_query)
    staging_table_list = spark.sql(staging_table_list_query)
    table_list.show()
    staging_table_list.show()
    try:
        mkdir_partion_config = "hdfs dfs -mkdir /user/hadoop/spc/"
        os.system(mkdir_partion_config)
        copy_spc = "hdfs dfs -put -f {PATH}/module-udf/sourcing_partition_config.csv /user/hadoop/spc/".format(PATH=path)
        os.system(copy_spc)
        print("Sourcing Partition Config file copied to HDFS location:/user/hadoop/spc/")
    except Exception as e:         
        print("Failed to copy Sourcing Partition Config file to HDFS location:/user/hadoop/spc/")
        print("EXCEPTION :",str(e))
        sys.exit(1)
    try:  
        SOURCING_PARTITION=spark.read.csv('/user/hadoop/spc/sourcing_partition_config.csv',header=True)
        SOURCING_PARTITION.createOrReplaceTempView('SOURCING_PARTITION')
    except Exception as e:         
        print("SOURCING_PARTITION temp table creation failed")
        print("EXCEPTION :",str(e))
        sys.exit(1) 
    for table_names in table_list.collect():
        print(table_names)
        if table_names["process_table_name"] == None:
            continue
        table_name = CDE_PROCESS.upper() + '.' + table_names["process_table_name"]
        print(table_name)
        try:
            max_partitions=spark.sql("Select max_partitions from SOURCING_PARTITION where upper(table_name)=upper('{TABLE_NAME}')".format(TABLE_NAME=table_name)).collect()[0][0]
        except Exception as e:
            max_partitions=default_max_partitions
        print(max_partitions)
        purge_partition(table_name,max_partitions)
        xdpLogger('xDP-INF-111',comment="Partition purging for table: {} finished".format(table_name))
    for table_names in staging_table_list.collect():
        print(table_names)
        if table_names["staging_table_name"] == None:
            continue
        table_name = CDE_STAGING.upper() + '.' + table_names["staging_table_name"]
        print(table_name)
        try:
            max_partitions=spark.sql("Select max_partitions from SOURCING_PARTITION where upper(table_name)=upper('{TABLE_NAME}')".format(TABLE_NAME=table_name)).collect()[0][0]
        except Exception as e:
            max_partitions=default_max_partitions
        print(max_partitions)
        purge_partition(table_name,job_option_config.max_partitions)
        xdpLogger('xDP-INF-111',comment="Partition purging for table: {} finished".format(table_name))
    xdpLogger('xDP-INF-999')
    spark.stop()
