#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from importlib import reload
reload(sys)
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import subprocess
import botocore.session
from datetime import datetime,timedelta
from datetime import date
#from util import frmspark
from config import setup_module_config_path
import job_option_config
from job_option_config import cde_databases, cde_sysparm
#from util import frmexceptions
#from util import utilities as utility
from logger import get_logger,create_logger,xdpLogger
from pyspark.sql.utils import CapturedException
from pyspark.sql.utils import AnalysisException

cde_control = job_option_config.cde_databases["CONTROL"]
cde_bop_batch_grp = job_option_config.cde_databases["BOP_CDE_BATCH_GRP"]
file_ingestion_detail = job_option_config.file_ingestion_detail
file_arrival_status = job_option_config.file_arrival_status
sourcing_file_versioning = job_option_config.sourcing_file_versioning
file_action = job_option_config.file_action
job_running_status=cde_control+'.job_running_status'
flow_running_status=cde_control+'.flow_running_status'
sourcing_flow_running_status=cde_control+'.sourcing_flow_running_status'
cde_trigger_queue=cde_bop_batch_grp+'.cde_trigger_queue'

def get_spark():
    """
    Get a spark session for processiong
    """
    new_spark = SparkSession \
    .builder \
    .appName("XDP_FileIngestion") \
    .config('spark.sql.warehouse.dir', u'hdfs:///user/spark/warehouse') \
    .config('hive.exec.dynamic.partition', 'true') \
    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
    .config('hive.exec.max.dynamic.partitions','20000') \
    .config('hive.exec.max.dynamic.partitions.pernode', '20000') \
    .config('fs.s3.maxRetries', '20') \
    .enableHiveSupport() \
    .config("spark.sql.broadcastTimeout", "3600") \
    .config("spark.dynamicAllocation.executorIdleTimeout ", "300").enableHiveSupport() \
    .getOrCreate()
    new_spark.sparkContext.setLogLevel("ERROR")
    return new_spark

def is_table_exists(table_name):
        """
        Check if table_name exists or not
        """
        get_logger()
        xdpLogger('xDP-INF-001')
        try:
                spark.read.table(table_name)
                return True
        except CapturedException:
                return False

def execute_specific_query(query, **kwargs):
    """
    Execute a SQL Statement.
    """
    #query = query.format(**kwargs)
    get_logger()
    xdpLogger('xDP-INF-001')
    xdpLogger('xDP-INF-009',comment="Executing SQL.:{}".format(query))
    try:
        return spark.sql(query)
    except AnalysisException as exp:
        xdpLogger('xDP-INF-111',comment="Table is not Partitioned")
        return False
    except CapturedException as exp:
        xdpLogger('xDP-WAR-053',comment="Query execution failed. Exception logged")
        xdpLogger('FMREXP',exp)
        xdpLogger('xDP-ERR-117',comment=exp)
        raise frmexceptions.QueryException(exp.desc, exp.stackTrace)



def shrink_utility(input_table_nm):
    get_logger()
    xdpLogger('xDP-INF-001')
    
    input_table_name = input_table_nm   
    if not is_table_exists(input_table_name):
        xdpLogger('xDP-WAR-045',comment="Table missing :{}".format(input_table_name))

    is_tb_partitioned = True    
    partition_cols = execute_specific_query("show partitions {}".format(input_table_name))
    if (partition_cols == False):
        is_tb_partitioned = False
    
    
    date_count_before_shrink = spark.sql("select count(*) from {}".format(input_table_name)).collect()[0][0]
    
    table_name_only = input_table_name.split(".")[1]
    
    temp_tb = "{}".format(cde_control) + "." + "{}_tmp".format(table_name_only)
    if is_table_exists(temp_tb):
        spark.sql("drop table {}".format(temp_tb))
    
    table_data_df = spark.sql("select * from {}".format(input_table_name))
    table_data_df.repartition(1).write.saveAsTable(temp_tb)           
    spark.sql("insert overwrite table {} select * from {}".format(input_table_name,temp_tb))

    date_count_after_shrink = spark.sql("select count(*) from {}".format(input_table_name)).collect()[0][0]
    if (date_count_before_shrink == date_count_after_shrink):
        xdpLogger('xDP-INF-003',comment="Record count matching after shrinking files")
    else:
        xdpLogger('xDP-ERR-117',comment="Record count mismatch post shrinking for table: {}".format(inp_table))
        spark.stop()
        sys.exit(1)

if __name__ == "__main__":

    spark = get_spark()
    create_logger("SHRINK_UTILITY")
    xdpLogger('xDP-INF-001')      
    
    shrink_utility(file_arrival_status.lower())
    xdpLogger('xDP-INF-111',comment="File shrinking finished for logging table: {}".format(file_arrival_status))
    shrink_utility(file_action.lower())
    xdpLogger('xDP-INF-111',comment="File shrinking finished for logging table: {}".format(file_action))
    shrink_utility(file_ingestion_detail.lower())
    xdpLogger('xDP-INF-111',comment="File shrinking finished for logging table: {}".format(file_ingestion_detail))
    shrink_utility(sourcing_file_versioning.lower())
    xdpLogger('xDP-INF-111',comment="File shrinking finished for logging table: {}".format(sourcing_file_versioning))
###    shrink_utility(job_running_status.lower())
###    xdpLogger('xDP-INF-111',comment="File shrinking finished for logging table: {}".format(job_running_status))
###    shrink_utility(flow_running_status.lower())
###    xdpLogger('xDP-INF-111',comment="File shrinking finished for logging table: {}".format(flow_running_status))
###    shrink_utility(sourcing_flow_running_status.lower())
###    xdpLogger('xDP-INF-111',comment="File shrinking finished for logging table: {}".format(sourcing_flow_running_status))
###    shrink_utility(cde_trigger_queue.lower())
###    xdpLogger('xDP-INF-111',comment="File shrinking finished for logging table: {}".format(cde_trigger_queue))
     
    xdpLogger('xDP-INF-999')
    spark.stop()
