from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from datetime import date, datetime, time, timedelta
import os
import sys

from airflow.operators.subdag_operator import SubDagOperator
'''from cde_cde01_m_g_bureau_data_prep import child_dag_cde01_m_g_bureau_data_prep
from cde_cde01_m_g_multi_bureau import child_dag_cde01_m_g_multi_bureau
from cde_cde01_m_r_pal_probesm_flow import child_dag_cde01_m_r_pal_probesm_flow
from cde_cde01_m_n_pal_probesm_flow import child_dag_cde01_m_n_pal_probesm_flow
from cde_cde01_m_j_pal_probesm_flow import child_dag_cde01_m_j_pal_probesm_flow
from cde_cde01_m_k_pal_probesm_flow import child_dag_cde01_m_k_pal_probesm_flow
from cde_cde05_m_r_midmonth_val_flow import child_dag_cde05_m_r_midmonth_val_flow
from cde_cde05_m_n_midmonth_val_flow import child_dag_cde05_m_n_midmonth_val_flow
from cde_cde05_m_j_midmonth_val_flow import child_dag_cde05_m_j_midmonth_val_flow'''

import boto3
import botocore.session 
import json
import yaml

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]

SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]
CDL_EXP_SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["CDL_EXP_SOURCING_CHECK"]

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	

file = open(MASTER_IP,"r")
IP = file.read()
file.close

flow_name="CDE99_M_X_MIDMONTH_LOGIC_FLOW"
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val
	
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

dag = DAG('CDE99_M_X_MIDMONTH_LOGIC_FLOW' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1)

'''RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
	
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)'''

#Child DAG Definitions

'''subDag_cde01_m_g_bureau_data_prep = SubDagOperator(
    subdag=child_dag_cde01_m_g_bureau_data_prep('CDE99_M_X_MIDMONTH_LOGIC_FLOW', 'CDE01_M_G_BUREAU_DATA_PREP', default_args, dag.schedule_interval),
    task_id='CDE01_M_G_BUREAU_DATA_PREP',
    default_args=default_args,
    dag=dag)
    
subDag_cde01_m_g_multi_bureau = SubDagOperator(
    subdag=child_dag_cde01_m_g_multi_bureau('CDE99_M_X_MIDMONTH_LOGIC_FLOW', 'CDE01_M_G_MULTI_BUREAU', default_args, dag.schedule_interval),
    task_id='CDE01_M_G_MULTI_BUREAU',
    default_args=default_args,
    dag=dag)
    
subDag_cde01_m_r_pal_probesm_flow = SubDagOperator(
    subdag=child_dag_cde01_m_r_pal_probesm_flow('CDE99_M_X_MIDMONTH_LOGIC_FLOW', 'CDE01_M_R_PAL_PROBESM_FLOW', default_args, dag.schedule_interval),
    task_id='CDE01_M_R_PAL_PROBESM_FLOW',
    default_args=default_args,
    dag=dag)
    
subDag_cde01_m_n_pal_probesm_flow = SubDagOperator(
    subdag=child_dag_cde01_m_n_pal_probesm_flow('CDE99_M_X_MIDMONTH_LOGIC_FLOW', 'CDE01_M_N_PAL_PROBESM_FLOW', default_args, dag.schedule_interval),
    task_id='CDE01_M_N_PAL_PROBESM_FLOW',
    default_args=default_args,
    dag=dag)
    
subDag_cde01_m_j_pal_probesm_flow = SubDagOperator(
    subdag=child_dag_cde01_m_j_pal_probesm_flow('CDE99_M_X_MIDMONTH_LOGIC_FLOW', 'CDE01_M_J_PAL_PROBESM_FLOW', default_args, dag.schedule_interval),
    task_id='CDE01_M_J_PAL_PROBESM_FLOW',
    default_args=default_args,
    dag=dag)
    
subDag_cde01_m_k_pal_probesm_flow = SubDagOperator(
    subdag=child_dag_cde01_m_k_pal_probesm_flow('CDE99_M_X_MIDMONTH_LOGIC_FLOW', 'CDE01_M_K_PAL_PROBESM_FLOW', default_args, dag.schedule_interval),
    task_id='CDE01_M_K_PAL_PROBESM_FLOW',
    default_args=default_args,
    dag=dag)
        
subDag_cde05_m_r_midmonth_val_flow = SubDagOperator(
    subdag=child_dag_cde05_m_r_midmonth_val_flow('CDE99_M_X_MIDMONTH_LOGIC_FLOW', 'CDE05_M_R_MIDMONTH_VAL_FLOW', default_args, dag.schedule_interval),
    task_id='CDE05_M_R_MIDMONTH_VAL_FLOW',
    default_args=default_args,
    dag=dag)

subDag_cde05_m_n_midmonth_val_flow = SubDagOperator(
    subdag=child_dag_cde05_m_n_midmonth_val_flow('CDE99_M_X_MIDMONTH_LOGIC_FLOW', 'CDE05_M_N_MIDMONTH_VAL_FLOW', default_args, dag.schedule_interval),
    task_id='CDE05_M_N_MIDMONTH_VAL_FLOW',
    default_args=default_args,
    dag=dag)

subDag_cde05_m_j_midmonth_val_flow = SubDagOperator(
    subdag=child_dag_cde05_m_j_midmonth_val_flow('CDE99_M_X_MIDMONTH_LOGIC_FLOW', 'CDE05_M_J_MIDMONTH_VAL_FLOW', default_args, dag.schedule_interval),
    task_id='CDE05_M_J_MIDMONTH_VAL_FLOW',
    default_args=default_args,
    dag=dag)'''

#CDE01_M_G_BUREAU_DATA_PREP
CDE01_M_G_CALLCR_DATA_PREP = BashOperator(task_id='CDE01_M_G_CALLCR_DATA_PREP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_CALLCR_DATA_PREP')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_CALLCR_DATA_PREP.py GRP CDE01_M_G_CALLCR_DATA_PREP CDE01_M_G_BUREAU_DATA_PREP -y,", dag=dag)
CDE01_M_G_EQUIFAX_DATA_PREP = BashOperator(task_id='CDE01_M_G_EQUIFAX_DATA_PREP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_EQUIFAX_DATA_PREP')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_EQUIFAX_DATA_PREP.py GRP CDE01_M_G_EQUIFAX_DATA_PREP CDE01_M_G_BUREAU_DATA_PREP -y,", dag=dag)
CDE01_M_G_EXPERIAN_DATA_PREP = BashOperator(task_id='CDE01_M_G_EXPERIAN_DATA_PREP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_EXPERIAN_DATA_PREP')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_EXPERIAN_DATA_PREP.py GRP CDE01_M_G_EXPERIAN_DATA_PREP CDE01_M_G_BUREAU_DATA_PREP -y,", dag=dag)
CDE01_M_G_EXP_PROCESS_LOAD = BashOperator(task_id='CDE01_M_G_EXP_PROCESS_LOAD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_EXP_PROCESS_LOAD')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_EXP_PROCESS_LOAD.py GRP CDE01_M_G_EXP_PROCESS_LOAD CDE01_M_G_BUREAU_DATA_PREP -y,", dag=dag)
CDL_EXP_SOURCING_CHECK = BashOperator(task_id='CDL_EXP_SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDL_EXP_SOURCING_CHECK')+" "+cmd_part+"\" "+CDL_EXP_SOURCING_CHECK_PATH+" GRP CDL_EXP_SOURCING_CHECK CDE01_M_G_BUREAU_DATA_PREP FILE_INGESTION_DETAIL DCM_BATCH_M EXPERIAN_GRPDCMV11 -y,", dag=dag)

CDE01_M_G_CALLCR_DATA_PREP.set_downstream(CDE01_M_G_EXPERIAN_DATA_PREP)
CDL_EXP_SOURCING_CHECK.set_downstream(CDE01_M_G_EXP_PROCESS_LOAD)
CDE01_M_G_EXP_PROCESS_LOAD.set_downstream(CDE01_M_G_EXPERIAN_DATA_PREP)
CDE01_M_G_EXPERIAN_DATA_PREP.set_downstream(CDE01_M_G_EQUIFAX_DATA_PREP)

#CDE01_M_G_MULTI_BUREAU
CDE01_M_X_MULTI_BUREAU_PROBE1 = BashOperator(task_id='CDE01_M_X_MULTI_BUREAU_PROBE1' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_MULTI_BUREAU_PROBE1')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_MULTI_BUREAU_PROBE1.py GRP CDE01_M_X_MULTI_BUREAU_PROBE1 CDE01_M_G_MULTI_BUREAU -y,", dag=dag)
CDE01_M_X_MULTI_BUREAU_PROBE2 = BashOperator(task_id='CDE01_M_X_MULTI_BUREAU_PROBE2' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_MULTI_BUREAU_PROBE2')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_MULTI_BUREAU_PROBE2.py GRP CDE01_M_X_MULTI_BUREAU_PROBE2 CDE01_M_G_MULTI_BUREAU -y,", dag=dag)
CDE06_M_G_GURN_DELINKS = BashOperator(task_id='CDE06_M_G_GURN_DELINKS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_G_GURN_DELINKS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_G_GURN_DELINKS.py GRP CDE06_M_G_GURN_DELINKS CDE01_M_G_MULTI_BUREAU -y,",dag=dag)
CDE01_M_X_MULTI_BUREAU_PROBE1.set_downstream(CDE01_M_X_MULTI_BUREAU_PROBE2)
CDE06_M_G_GURN_DELINKS.set_downstream(CDE01_M_X_MULTI_BUREAU_PROBE1)

#CDE01_M_R_PAL_PROBESM_FLOW
CDE06_M_X_CCARD_BIS_R = BashOperator(task_id='CDE06_M_X_CCARD_BIS_R' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_CCARD_BIS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_CCARD_BIS.py RBS CDE06_M_X_CCARD_BIS CDE01_M_R_PAL_PROBESM_FLOW -y,", dag=dag)
CDE06_M_X_PAL_CCARD_DERVS_R = BashOperator(task_id='CDE06_M_X_PAL_CCARD_DERVS_R' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_PAL_CCARD_DERVS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_PAL_CCARD_DERVS.py RBS CDE06_M_X_PAL_CCARD_DERVS CDE01_M_R_PAL_PROBESM_FLOW -y,", dag=dag)
CDE06_M_X_CCARD_BIS_R.set_downstream(CDE06_M_X_PAL_CCARD_DERVS_R)

#CDE01_M_N_PAL_PROBESM_FLOW
CDE06_M_X_CCARD_BIS_N = BashOperator(task_id='CDE06_M_X_CCARD_BIS_N' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_CCARD_BIS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_CCARD_BIS.py NWB CDE06_M_X_CCARD_BIS CDE01_M_N_PAL_PROBESM_FLOW -y,", dag=dag)
CDE06_M_X_PAL_CCARD_DERVS_N = BashOperator(task_id='CDE06_M_X_PAL_CCARD_DERVS_N' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_PAL_CCARD_DERVS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_PAL_CCARD_DERVS.py NWB CDE06_M_X_PAL_CCARD_DERVS CDE01_M_N_PAL_PROBESM_FLOW -y,", dag=dag)
CDE06_M_X_CCARD_BIS_N.set_downstream(CDE06_M_X_PAL_CCARD_DERVS_N)

#CDE01_M_J_PAL_PROBESM_FLOW
CDE06_M_X_CCARD_BIS_J = BashOperator(task_id='CDE06_M_X_CCARD_BIS_J' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_CCARD_BIS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_CCARD_BIS.py UBN CDE06_M_X_CCARD_BIS CDE01_M_J_PAL_PROBESM_FLOW -y,", dag=dag)
CDE06_M_X_PAL_CCARD_DERVS_J = BashOperator(task_id='CDE06_M_X_PAL_CCARD_DERVS_J' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_PAL_CCARD_DERVS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_PAL_CCARD_DERVS.py UBN CDE06_M_X_PAL_CCARD_DERVS CDE01_M_J_PAL_PROBESM_FLOW -y,", dag=dag)
CDE06_M_X_CCARD_BIS_J.set_downstream(CDE06_M_X_PAL_CCARD_DERVS_J)

#CDE01_M_K_PAL_PROBESM_FLOW
CDE06_M_X_CCARD_BIS_K = BashOperator(task_id='CDE06_M_X_CCARD_BIS_K' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_CCARD_BIS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_CCARD_BIS.py UBS CDE06_M_X_CCARD_BIS CDE01_M_K_PAL_PROBESM_FLOW -y,", dag=dag)
CDE06_M_X_PAL_CCARD_DERVS_K = BashOperator(task_id='CDE06_M_X_PAL_CCARD_DERVS_K' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_PAL_CCARD_DERVS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_PAL_CCARD_DERVS.py UBS CDE06_M_X_PAL_CCARD_DERVS CDE01_M_K_PAL_PROBESM_FLOW -y,", dag=dag)
CDE06_M_X_CCARD_BIS_K.set_downstream(CDE06_M_X_PAL_CCARD_DERVS_K)

#CDE05_M_R_MIDMONTH_VAL_FLOW
CDE05_M_X_LIM_PAL_MB_DIST_R = BashOperator(task_id='CDE05_M_X_LIM_PAL_MB_DIST_R' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_LIM_PAL_MB_DIST')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_LIM_PAL_MB_DIST.py RBS CDE05_M_X_LIM_PAL_MB_DIST CDE05_M_R_MIDMONTH_VAL_FLOW -y,", dag=dag)
CDE05_M_X_LIM_PAL_EQ_DIST_R = BashOperator(task_id='CDE05_M_X_LIM_PAL_EQ_DIST_R' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_LIM_PAL_EQ_DIST')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_LIM_PAL_EQ_DIST.py RBS CDE05_M_X_LIM_PAL_EQ_DIST CDE05_M_R_MIDMONTH_VAL_FLOW -y,", dag=dag)
CDE05_M_X_LIM_PAL_MB_DIST_R.set_downstream(CDE05_M_X_LIM_PAL_EQ_DIST_R)

#CDE05_M_N_MIDMONTH_VAL_FLOW
CDE05_M_X_LIM_PAL_MB_DIST_N = BashOperator(task_id='CDE05_M_X_LIM_PAL_MB_DIST_N' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_LIM_PAL_MB_DIST')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_LIM_PAL_MB_DIST.py NWB CDE05_M_X_LIM_PAL_MB_DIST CDE05_M_N_MIDMONTH_VAL_FLOW -y,", dag=dag)
CDE05_M_X_LIM_PAL_EQ_DIST_N = BashOperator(task_id='CDE05_M_X_LIM_PAL_EQ_DIST_N' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_LIM_PAL_EQ_DIST')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_LIM_PAL_EQ_DIST.py NWB CDE05_M_X_LIM_PAL_EQ_DIST CDE05_M_N_MIDMONTH_VAL_FLOW -y,", dag=dag)
CDE05_M_X_LIM_PAL_MB_DIST_N.set_downstream(CDE05_M_X_LIM_PAL_EQ_DIST_N)

#CDE05_M_J_MIDMONTH_VAL_FLOW
CDE05_M_X_LIM_PAL_MB_DIST_J = BashOperator(task_id='CDE05_M_X_LIM_PAL_MB_DIST_J' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_LIM_PAL_MB_DIST')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_LIM_PAL_MB_DIST.py UBN CDE05_M_X_LIM_PAL_MB_DIST CDE05_M_J_MIDMONTH_VAL_FLOW -y,", dag=dag)
CDE05_M_X_LIM_PAL_EQ_DIST_J = BashOperator(task_id='CDE05_M_X_LIM_PAL_EQ_DIST_J' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_LIM_PAL_EQ_DIST')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_LIM_PAL_EQ_DIST.py UBN CDE05_M_X_LIM_PAL_EQ_DIST CDE05_M_J_MIDMONTH_VAL_FLOW -y,", dag=dag)
CDE05_M_X_LIM_PAL_MB_DIST_J.set_downstream(CDE05_M_X_LIM_PAL_EQ_DIST_J)	
	
START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE99_M_X_MIDMONTH_LOGIC_FLOW -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE99_M_X_MIDMONTH_LOGIC_FLOW -y,", dag=dag)    
CDE04_M_G_QCB_COPY = BashOperator(task_id='CDE04_M_G_QCB_COPY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_G_QCB_COPY')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_G_QCB_COPY.py GRP CDE04_M_G_QCB_COPY CDE99_M_X_MIDMONTH_LOGIC_FLOW -y,", dag=dag)
CDE07_M_G_BUR_OUTMAPPER = BashOperator(task_id='CDE07_M_G_BUR_OUTMAPPER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_G_BUR_OUTMAPPER')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_G_BUR_OUTMAPPER.py GRP CDE07_M_G_BUR_OUTMAPPER CDE99_M_X_MIDMONTH_LOGIC_FLOW -y,", dag=dag)
CDE07_M_G_BUR_OUTMAPPER_V11 = BashOperator(task_id='CDE07_M_G_BUR_OUTMAPPER_V11' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_G_BUR_OUTMAPPER_V11')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_G_BUR_OUTMAPPER_V11.py GRP CDE07_M_G_BUR_OUTMAPPER_V11 CDE99_M_X_MIDMONTH_LOGIC_FLOW -y,", dag=dag)
CDE06_M_G_BASEL_CC_MODEL_INPUTS = BashOperator(task_id='CDE06_M_G_BASEL_CC_MODEL_INPUTS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_G_BASEL_CC_MODEL_INPUTS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_G_BASEL_CC_MODEL_INPUTS.py GRP CDE06_M_G_BASEL_CC_MODEL_INPUTS CDE99_M_X_MIDMONTH_LOGIC_FLOW -y,", dag=dag)
CDE10_M_G_BBLS_BANKRUPTCY_FLAG = BashOperator(task_id='CDE10_M_G_BBLS_BANKRUPTCY_FLAG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_G_BBLS_BANKRUPTCY_FLAG')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_G_BBLS_BANKRUPTCY_FLAG.py GRP CDE10_M_G_BBLS_BANKRUPTCY_FLAG CDE99_M_X_MIDMONTH_LOGIC_FLOW -y,", dag=dag)

# added for [master flow sourcing check]
SOURCING_CHECK= BashOperator(task_id='SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE99_M_X_MIDMONTH_LOGIC_FLOW -y,", dag=dag)

START.set_downstream(SOURCING_CHECK)
SOURCING_CHECK.set_downstream(CDE01_M_G_CALLCR_DATA_PREP)
SOURCING_CHECK.set_downstream(CDE06_M_G_BASEL_CC_MODEL_INPUTS)
SOURCING_CHECK.set_downstream(CDE10_M_G_BBLS_BANKRUPTCY_FLAG)
SOURCING_CHECK.set_downstream(CDL_EXP_SOURCING_CHECK)

# START.set_downstream(subDag_cde01_m_g_bureau_data_prep)
# START.set_downstream(CDE06_M_G_BASEL_CC_MODEL_INPUTS)

CDE01_M_G_EQUIFAX_DATA_PREP.set_downstream(CDE06_M_G_GURN_DELINKS)
CDE01_M_X_MULTI_BUREAU_PROBE2.set_downstream(CDE06_M_X_CCARD_BIS_R)
CDE01_M_X_MULTI_BUREAU_PROBE2.set_downstream(CDE06_M_X_CCARD_BIS_N)
CDE01_M_X_MULTI_BUREAU_PROBE2.set_downstream(CDE06_M_X_CCARD_BIS_J)
CDE01_M_X_MULTI_BUREAU_PROBE2.set_downstream(CDE06_M_X_CCARD_BIS_K)
CDE01_M_X_MULTI_BUREAU_PROBE2.set_downstream(CDE04_M_G_QCB_COPY)
CDE04_M_G_QCB_COPY.set_downstream(CDE07_M_G_BUR_OUTMAPPER)
CDE01_M_G_EXP_PROCESS_LOAD.set_downstream(CDE07_M_G_BUR_OUTMAPPER_V11)
CDE06_M_X_PAL_CCARD_DERVS_J.set_downstream(CDE05_M_X_LIM_PAL_MB_DIST_J)
CDE06_M_X_PAL_CCARD_DERVS_R.set_downstream(CDE05_M_X_LIM_PAL_MB_DIST_R)
CDE06_M_X_PAL_CCARD_DERVS_N.set_downstream(CDE05_M_X_LIM_PAL_MB_DIST_N)
CDE05_M_X_LIM_PAL_EQ_DIST_R.set_downstream(END)
CDE05_M_X_LIM_PAL_EQ_DIST_J.set_downstream(END)
CDE05_M_X_LIM_PAL_EQ_DIST_N.set_downstream(END)
CDE06_M_X_PAL_CCARD_DERVS_K.set_downstream(END)
CDE06_M_G_BASEL_CC_MODEL_INPUTS.set_downstream(END)
CDE10_M_G_BBLS_BANKRUPTCY_FLAG.set_downstream(END)
#CDE04_M_G_QCB_COPY.set_downstream(END)
CDE07_M_G_BUR_OUTMAPPER.set_downstream(END)
CDE07_M_G_BUR_OUTMAPPER_V11.set_downstream(END)

#RUN_CHECK.set_downstream(START)
#RUN_CHECK.set_downstream(STOP)