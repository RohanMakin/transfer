from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from datetime import date, datetime, time, timedelta
from airflow.utils.decorators import apply_defaults
from os.path import join, abspath
import os
from airflow import DAG
# from airflow.operators import SimpleHttpOperator, HttpSensor,   BashOperator, EmailOperator, S3KeySensor
from datetime import datetime, timedelta
#import settings as st
import glob
from datetime import date, datetime, time, timedelta
import random
import yaml
import airflow
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import BranchPythonOperator
import json
import botocore
from botocore.session import Session
from botocore.exceptions import ClientError, ParamValidationError
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow import configuration as conf
from airflow.models import DagBag, TaskInstance
from airflow.utils.state import State
from airflow.utils.trigger_rule import TriggerRule

with open('/usr/local/airflow/ssh/variables.json') as json_file:
    data = json.load(json_file) 
account_id = data['AccountId']
json_file.close()

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

START_DATE = datetime(2019, 10, 12, hour=10,minute=30)

args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'queue': 'sqs-airflow-cde',
    'retry_delay': timedelta(minutes=1),
    'start_date': START_DATE,
    'end_date': datetime(2099,12,31),
    'max_active_runs' : 1 ,
    'concurrency' : 1,
}


## The Schedule internal should NOT be less than the XDP_FileIngestion_Controller DAG execution time.
## Dont change schedule_interval less than 15 minutes for this DAG 

DAG_NAME = "XDP_FI_ControlFlow_cde"

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)

dag = DAG(
    dag_id=DAG_NAME,
    default_args=args,
    catchup=False,
    schedule_interval= DAG_CONFIG_DICT["CONTROL_FLOW_DAG_SCHEDULE"]
)


def final_status(**kwargs):
    for task_instance in kwargs['dag_run'].get_task_instances():
        if task_instance.current_state() not in [State.SUCCESS,State.SKIPPED] and task_instance.task_id != kwargs['task_instance'].task_id:
            raise Exception("Task {} failed. Failing this DAG run".format(task_instance.task_id))





def checkActiveruns():
     dg1=DAG(dag_id='XDP_FI_PrepareFlow_cde')
     dg2=DAG(dag_id='XDP_FI_ProcessData_cde')
     a=dg1.get_num_active_runs()
     b=dg2.get_num_active_runs()
     print("numOfactiveRuns",a)
     if a == 0 and b == 0:
         return ['Trigger_NextDag']
     else :
         return ['skipExecution']



def conditionally_trigger(context, dag_run_obj):
    """This function decides whether or not to Trigger the remote DAG"""
    c_p = context['params']['condition_param']
    print("Controller DAG : conditionally_trigger = {}".format(c_p))
    if context['params']['condition_param']:
        dag_run_obj.payload = {'message': context['params']['message']}
        print(dag_run_obj.payload)
        return dag_run_obj
    return None




skipExecution_opr = DummyOperator(
    task_id='skipExecution',
    dag=dag,
)

# Define the single task in this controller example DAG
trigger_op6 = TriggerDagRunOperator(
    task_id='Trigger_NextDag',
    trigger_dag_id="XDP_FI_PrepareFlow_cde",
    python_callable=conditionally_trigger,
    params={'condition_param': True, 'message': 'Trigger'},
    dag=dag,
)


branching_opr = BranchPythonOperator(
    task_id='BeginWithDecison',
    python_callable=checkActiveruns,
    dag=dag,
)


branching_opr >> [skipExecution_opr,trigger_op6]