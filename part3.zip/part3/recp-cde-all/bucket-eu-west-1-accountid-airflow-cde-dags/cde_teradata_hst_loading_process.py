try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO
import botocore.session # pylint: disable=import-error
from os.path import join, abspath
import traceback
from collections import namedtuple
import yaml
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 

import os
import sys 
import json


SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)
flow_name="LOAD_HISTORICAL_MIGRATED_DATA"


dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"

DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
ENV = DAG_CONFIG_DICT["CDE_ENV"]

script_loc="batch-framework/teradata-migration/"
teradata_to_aws_stg_job="cde_historical_data_loading_from_teradata_to_hive_staging_layer.py"
stg_to_aws_final_job="cde_hst_historical_data_loading_from_hive_staging_to_final_layer.py"
partition_folder_creation_job="create_partition_folder.py"
ctl_segregation_job = 'ctl_file_segregation.py'
final_status_populate_job = 'hst_table_load_status_populate.py'
config_file_check_and_movement_job = "config_file_mv.py"

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]
POLLING_FILE = DAG_CONFIG_DICT["POLLING_FILE"]
POLLING_MULTI_FILE = DAG_CONFIG_DICT["POLLING_MULTI_FILE"]
LOG_STATUS_START = DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_STATUS_END = DAG_CONFIG_DICT["LOG_STATUS_END"]
TRANSFORMATION_LOC=DAG_CONFIG_DICT["TRANSFORMATION_LOC_"+ENV]
PRESENTATION_LOC=DAG_CONFIG_DICT["PRESENTATION_LOC_"+ENV]
CDE_FILE_LOC=DAG_CONFIG_DICT["CDE_FILE_LOC"]
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
JOB_PATH_XDPSCRIPT= BASE_PATH+DAG_CONFIG_DICT["JOB_PATH_XDPSCRIPT"]
spark_config_param18 = DAG_CONFIG_DICT["SPARK_CONFIG_PARAM_18G"]
spark_config_param12 = DAG_CONFIG_DICT["SPARK_CONFIG_PARAM_12G"]
spark_config_param_gen = DAG_CONFIG_DICT["SPARK_CONFIG_PARAM_GEN"]
CONTROL = DAG_CONFIG_DICT["CDE_CONTROL"]
load_hst_data_schedule = DAG_CONFIG_DICT["LOAD_HISTORICAL_MIGRATED_DATA_SCHEDULE"]
save_location = "s3://bucket-eu-west-1-"+account_id+"-user/data_support_cde/test_results/"

file = open(MASTER_IP,"r")
IP = file.read()
file.close

def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/hst_flow_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'SEGREGATE_CTL'    
    return return_val

dag = DAG('LOAD_HISTORICAL_MIGRATED_DATA' , default_args=default_args, schedule_interval=load_hst_data_schedule, catchup=False, max_active_runs=1)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
    
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)

CONFIG_FILE_CHECK = BashOperator(task_id='CONFIG_FILE_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sudo spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ config_file_check_and_movement_job +" CTL -y,", dag=dag)

#CREATE_S3_PARTITION = BashOperator(task_id='CREATE_S3_PARTITION' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ partition_folder_creation_job +" -y,", dag=dag)

SEGREGATE_CTL = BashOperator(task_id='SEGREGATE_CTL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ ctl_segregation_job +" CTL -y,", dag=dag)

LOAD_MIGRATED_DATA_STG16 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG16' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL16 CTL_INTERMEDIATE16 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL16 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL16' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE16 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG17 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG17' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL17 CTL_INTERMEDIATE17 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL17 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL17' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE17 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG18 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG18' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL18 CTL_INTERMEDIATE18 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL18 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL18' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE18 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG19 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG19' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL19 CTL_INTERMEDIATE19 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL19 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL19' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE19 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG20 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG20' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL20 CTL_INTERMEDIATE20 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL20 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL20' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE20 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG21 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG21' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL21 CTL_INTERMEDIATE21 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL21 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL21' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param12+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE21 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG22 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG22' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL22 CTL_INTERMEDIATE22 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL22 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL22' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param12+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE22 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG23 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG23' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL23 CTL_INTERMEDIATE23 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL23 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL23' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param12+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE23 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG24 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG24' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL24 CTL_INTERMEDIATE24 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL24 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL24' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param12+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE24 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG25 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG25' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL25 CTL_INTERMEDIATE25 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL25 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL25' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param12+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE25 Y -y,", dag=dag)
POPULATE_LOAD_STATUS = BashOperator(task_id='POPULATE_LOAD_STATUS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+ CDE_FILE_LOC+ script_loc+ final_status_populate_job +" -y,", dag=dag)

DATA_LOAD_RECON = BashOperator(task_id='DATA_LOAD_RECON' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('DATA_LOAD_RECON')+" "+cmd_part+"\" "+JOB_PATH_XDPSCRIPT+"optimized_validation_script.py "+CONTROL +".hst_table_load_status_td " +CONTROL+ ".hst_table_load_status_aws td_tablename-aws_tablename  "+save_location+ " NA NA NA NA NA -y,", dag=dag)

CONFIG_FILE_CHECK.set_downstream(RUN_CHECK)
#RUN_CHECK.set_downstream(CREATE_S3_PARTITION)
#CREATE_S3_PARTITION.set_downstream(SEGREGATE_CTL)
RUN_CHECK.set_downstream(SEGREGATE_CTL)
SEGREGATE_CTL.set_downstream(LOAD_MIGRATED_DATA_STG16)
SEGREGATE_CTL.set_downstream(LOAD_MIGRATED_DATA_STG17)
SEGREGATE_CTL.set_downstream(LOAD_MIGRATED_DATA_STG18)
SEGREGATE_CTL.set_downstream(LOAD_MIGRATED_DATA_STG19)
SEGREGATE_CTL.set_downstream(LOAD_MIGRATED_DATA_STG20)
SEGREGATE_CTL.set_downstream(LOAD_MIGRATED_DATA_STG21)
SEGREGATE_CTL.set_downstream(LOAD_MIGRATED_DATA_STG22)
SEGREGATE_CTL.set_downstream(LOAD_MIGRATED_DATA_STG23)
SEGREGATE_CTL.set_downstream(LOAD_MIGRATED_DATA_STG24)
SEGREGATE_CTL.set_downstream(LOAD_MIGRATED_DATA_STG25)
LOAD_MIGRATED_DATA_STG16.set_downstream(LOAD_MIGRATED_DATA_FINAL16)
LOAD_MIGRATED_DATA_STG17.set_downstream(LOAD_MIGRATED_DATA_FINAL17)
LOAD_MIGRATED_DATA_STG18.set_downstream(LOAD_MIGRATED_DATA_FINAL18)
LOAD_MIGRATED_DATA_STG19.set_downstream(LOAD_MIGRATED_DATA_FINAL19)
LOAD_MIGRATED_DATA_STG20.set_downstream(LOAD_MIGRATED_DATA_FINAL20)
LOAD_MIGRATED_DATA_STG21.set_downstream(LOAD_MIGRATED_DATA_FINAL21)
LOAD_MIGRATED_DATA_STG22.set_downstream(LOAD_MIGRATED_DATA_FINAL22)
LOAD_MIGRATED_DATA_STG23.set_downstream(LOAD_MIGRATED_DATA_FINAL23)
LOAD_MIGRATED_DATA_STG24.set_downstream(LOAD_MIGRATED_DATA_FINAL24)
LOAD_MIGRATED_DATA_STG25.set_downstream(LOAD_MIGRATED_DATA_FINAL25)
LOAD_MIGRATED_DATA_FINAL16.set_downstream(POPULATE_LOAD_STATUS)
LOAD_MIGRATED_DATA_FINAL17.set_downstream(POPULATE_LOAD_STATUS)
LOAD_MIGRATED_DATA_FINAL18.set_downstream(POPULATE_LOAD_STATUS)
LOAD_MIGRATED_DATA_FINAL19.set_downstream(POPULATE_LOAD_STATUS)
LOAD_MIGRATED_DATA_FINAL20.set_downstream(POPULATE_LOAD_STATUS)
LOAD_MIGRATED_DATA_FINAL21.set_downstream(POPULATE_LOAD_STATUS)
LOAD_MIGRATED_DATA_FINAL22.set_downstream(POPULATE_LOAD_STATUS)
LOAD_MIGRATED_DATA_FINAL23.set_downstream(POPULATE_LOAD_STATUS)
LOAD_MIGRATED_DATA_FINAL24.set_downstream(POPULATE_LOAD_STATUS)
LOAD_MIGRATED_DATA_FINAL25.set_downstream(POPULATE_LOAD_STATUS)
POPULATE_LOAD_STATUS.set_downstream(DATA_LOAD_RECON)
RUN_CHECK.set_downstream(STOP)



