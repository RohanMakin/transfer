try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO
import botocore.session # pylint: disable=import-error
from os.path import join, abspath
import traceback
from collections import namedtuple

import yaml
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 

import os
import sys
import json



SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

sourcing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/oracle_sourcing_config.yaml"
dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]

SOURCING_SCRIPT_PATH = DAG_CONFIG_DICT["SOURCING_SCRIPT_PATH"]
oracle_dag_schedule = DAG_CONFIG_DICT["ORACLE_DAG_SCHEDULE"]
teradata_dag_concurrency = DAG_CONFIG_DICT["TERADATA_DAG_CONCURRENCY"]

file = open(MASTER_IP,"r")
IP = file.read()
file.close

CONFIG_FILE = read_s3_file(sourcing_yaml_path)
CONFIG_DICT = yaml.safe_load(CONFIG_FILE)

TERADATA_SCRIPT_PATH = BASE_PATH+DAG_CONFIG_DICT["TERADATA_SCRIPT_PATH"]
TERADATA_PREPROCESSOR_SCRIPT_PATH = BASE_PATH+DAG_CONFIG_DICT["TERADATA_PREPROCESSOR_SCRIPT_PATH"]
print('\n BASE_PATH'+BASE_PATH+'\n SOURCING_SCRIPT_PATH'+SOURCING_SCRIPT_PATH+'\n oracle_dag_schedule'+oracle_dag_schedule+'\n teradata_dag_concurrency'+str(teradata_dag_concurrency)+'\n TERADATA_SCRIPT_PATH'+TERADATA_SCRIPT_PATH)
dag = DAG('ORACLE_DATA_INGESTION' , default_args=default_args, schedule_interval=oracle_dag_schedule, catchup=False, max_active_runs=1, concurrency = teradata_dag_concurrency)


files_list_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/oracle_files.csv"

FileProcessingStarts = DummyOperator(
    task_id='FileProcessingStarts',
    dag=dag,)
	
FileProcessingEnds = DummyOperator(
    task_id='FileProcessingEnds',
    dag=dag,)	

def create_dag():
    dagList = read_s3_file(files_list_path)     
    lines = dagList.split('\n')
    preprocessing=0
    
    for x in lines: 
        st = x.strip()
        if len(st.split(",")) == 2: #preprocessing required. 
            preprocessing=1
            dagItem=str(st.split(",")[0])
            file_str = "FILE_"+dagItem  
            size_str = "SIZE_"+dagItem 	
            FILE_NAME = CONFIG_DICT[file_str]
            task_id_process = 'PROCESS_'+dagItem
            FILE_SIZE = CONFIG_DICT[size_str]
            spark_config_str = "SPARK_CONFIG_PARAM_"+FILE_SIZE            
            spark_config_param = DAG_CONFIG_DICT[spark_config_str]
            print("spark_config_param: " + spark_config_param)
            print("ORACLE_PREPROCESSOR_SCRIPT_PATH: " + TERADATA_PREPROCESSOR_SCRIPT_PATH)
            PREPROCESSING = BashOperator(task_id=task_id_process , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param+" "+TERADATA_PREPROCESSOR_SCRIPT_PATH+" "+ " -y,", dag=dag)
        if preprocessing==1: 
            break
            
    preprocessing=0
    for x in lines:
        st = x.strip()
        if len(st.split(",")) == 2: #preprocessing required. 
            print("line: " + str(st) + ": preprocessing required!!!")
            preprocessing=1
            dagItem=str(st.split(",")[1])
        else:                       #preprocessing NOT required. 
            print("line: " + str(st) + ": preprocessing NOT required!!!")
            dagItem = str(st)
        print('File Item '+dagItem)
        if dagItem != "" :
            task_id_process = 'PROCESS_'+dagItem

            file_str = "FILE_"+dagItem   
            size_str = "SIZE_"+dagItem 			
            FILE_NAME = CONFIG_DICT[file_str]
            FILE_SIZE = CONFIG_DICT[size_str]
            spark_config_str = "SPARK_CONFIG_PARAM_"+FILE_SIZE            
            spark_config_param = DAG_CONFIG_DICT[spark_config_str]   			            
            print('\n FILE_NAME'+FILE_NAME+'\n FILE_SIZE'+FILE_SIZE+'\n spark_config_param'+spark_config_param)            		
            FILE_PROCESS = BashOperator(task_id=task_id_process , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param+" "+TERADATA_SCRIPT_PATH+" "+ FILE_NAME +" -y,", dag=dag)        
            if preprocessing==1: 
                FileProcessingStarts.set_downstream(PREPROCESSING)
                PREPROCESSING.set_downstream(FILE_PROCESS)
                FILE_PROCESS.set_downstream(FileProcessingEnds)
            else: 
                FileProcessingStarts.set_downstream(FILE_PROCESS)
                FILE_PROCESS.set_downstream(FileProcessingEnds)
            preprocessing=0 # Switch off the preprocessing
create_dag()

