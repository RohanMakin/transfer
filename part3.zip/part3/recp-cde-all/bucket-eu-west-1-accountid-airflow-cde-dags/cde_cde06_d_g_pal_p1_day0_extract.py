from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from datetime import date, datetime, time, timedelta
import os
import sys

import boto3
import botocore.session 
import json
import yaml

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]
CONCURRENCY_D_G_PAL_P1_DAY0_EXTRACT = DAG_CONFIG_DICT["CONCURRENCY_D_G_PAL_P1_DAY0_EXTRACT"]
FLOW_DEPENDENCY = BASE_PATH+DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
# TACTICAL_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["TACTICAL_SOURCING_CHECK"]

ATHENA_ROW_COUNT_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["ATHENA_ROW_COUNT_CHECK"]

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	

file = open(MASTER_IP,"r")
IP = file.read()
file.close

flow_name="CDE06_D_G_PAL_P1_Day0_Extract"
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name	
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key] 
    return str(polling_time)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val
	
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}
dag = DAG('CDE06_D_G_PAL_P1_Day0_Extract' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1, concurrency = CONCURRENCY_D_G_PAL_P1_DAY0_EXTRACT)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
	
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)
	
START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
##CDER-5800 Adding batch ctrl dependency 
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW= BashOperator(task_id='DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_D_G_BATCH_CTRL_UPDATE_FLOW "+get_polling_time('CDE99_D_G_BATCH_CTRL_UPDATE_FLOW')+" -y,", dag=dag)

#CDE06_D_G_RDR_BB_CONN_DATA = BashOperator(task_id='CDE06_D_G_RDR_BB_CONN_DATA' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_G_RDR_BB_CONN_DATA')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_G_RDR_BB_CONN_DATA.py GRP CDE06_D_G_RDR_BB_CONN_DATA CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_APP_PARM_UPLIFT = BashOperator(task_id='CDE06_D_X_APP_PARM_UPLIFT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_APP_PARM_UPLIFT')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_APP_PARM_UPLIFT.py GRP CDE06_D_X_APP_PARM_UPLIFT CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_NONPERS_CUST_DAILY = BashOperator(task_id='CDE06_D_X_NONPERS_CUST_DAILY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_NONPERS_CUST_DAILY')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_NONPERS_CUST_DAILY.py GRP CDE06_D_X_NONPERS_CUST_DAILY CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_PAL_ACCOUNT = BashOperator(task_id='CDE06_D_X_PAL_ACCOUNT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_PAL_ACCOUNT')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_PAL_ACCOUNT.py GRP CDE06_D_X_PAL_ACCOUNT CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_PAL_ACC_CONN_DAILY = BashOperator(task_id='CDE06_D_X_PAL_ACC_CONN_DAILY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_PAL_ACC_CONN_DAILY')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_PAL_ACC_CONN_DAILY.py GRP CDE06_D_X_PAL_ACC_CONN_DAILY CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_PAL_APP_CARDS = BashOperator(task_id='CDE06_D_X_PAL_APP_CARDS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_PAL_APP_CARDS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_PAL_APP_CARDS.py GRP CDE06_D_X_PAL_APP_CARDS CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_PAL_APP_CORE = BashOperator(task_id='CDE06_D_X_PAL_APP_CORE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_PAL_APP_CORE')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_PAL_APP_CORE.py GRP CDE06_D_X_PAL_APP_CORE CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_PAL_APP_CUST_MRG = BashOperator(task_id='CDE06_D_X_PAL_APP_CUST_MRG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_PAL_APP_CUST_MRG')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_PAL_APP_CUST_MRG.py GRP CDE06_D_X_PAL_APP_CUST_MRG CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_PAL_APP_SCORING = BashOperator(task_id='CDE06_D_X_PAL_APP_SCORING' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_PAL_APP_SCORING')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_PAL_APP_SCORING.py GRP CDE06_D_X_PAL_APP_SCORING CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_PAL_CUST_PORT_DAILY = BashOperator(task_id='CDE06_D_X_PAL_CUST_PORT_DAILY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_PAL_CUST_PORT_DAILY')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_PAL_CUST_PORT_DAILY.py GRP CDE06_D_X_PAL_CUST_PORT_DAILY CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_PAL_PERS_CUST_DAILY = BashOperator(task_id='CDE06_D_X_PAL_PERS_CUST_DAILY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_PAL_PERS_CUST_DAILY')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_PAL_PERS_CUST_DAILY.py GRP CDE06_D_X_PAL_PERS_CUST_DAILY CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_SAO_APPLICATIONS = BashOperator(task_id='CDE06_D_X_SAO_APPLICATIONS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_SAO_APPLICATIONS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_SAO_APPLICATIONS.py GRP CDE06_D_X_SAO_APPLICATIONS CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)
#CDE99_D_X_NOTIFY = BashOperator(task_id='CDE99_D_X_NOTIFY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE99_D_X_NOTIFY')+" "+cmd_part+"\" "+JOB_PATH+"CDE99_D_X_NOTIFY.py GRP CDE99_D_X_NOTIFY CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)

# added for [master flow tactical check] CDER-5651
# TACTICAL_SOURCING_CHECK= BashOperator(task_id='TACTICAL_SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('TACTICAL_SOURCING_CHECK')+" "+cmd_part+"\" "+TACTICAL_CHECK_PATH + " CDE06_D_G_PAL_P1_Day0_Extract -y,", dag=dag)

# START.set_downstream(TACTICAL_SOURCING_CHECK)

#CDER-5689

PRE_CDE06_D_X_PAL_APP_CORE_POLL = BashOperator(task_id='PRE_CDE06_D_X_PAL_APP_CORE_POLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('POLLING_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"POLLING_CHECK.py GRP POLLING_CHECK CDE06_D_G_PAL_P1_Day0_Extract CMSA_APPLIC_MERGED -y,", dag=dag)
PRE_CDE06_D_X_PAL_PERS_CUST_DAILY_POLL = BashOperator(task_id='PRE_CDE06_D_X_PAL_PERS_CUST_DAILY_POLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('POLLING_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"POLLING_CHECK.py GRP POLLING_CHECK CDE06_D_G_PAL_P1_Day0_Extract UKB_TMIPCUS_PERS_CUST -y,", dag=dag)
PRE_CDE06_D_X_PAL_APP_SCORING_POLL = BashOperator(task_id='PRE_CDE06_D_X_PAL_APP_SCORING_POLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('POLLING_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"POLLING_CHECK.py GRP POLLING_CHECK CDE06_D_G_PAL_P1_Day0_Extract CMSA_CR_SCOR_RES_P -y,", dag=dag)
PRE_CDE06_D_X_PAL_ACC_CONN_DAILY_POLL = BashOperator(task_id='PRE_CDE06_D_X_PAL_ACC_CONN_DAILY_POLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('POLLING_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"POLLING_CHECK.py GRP POLLING_CHECK CDE06_D_G_PAL_P1_Day0_Extract UKB_TMICACH_CUS_ACCONH -y,", dag=dag)

PRE_CDE06_D_X_PAL_APP_CUST_MRG_POLL = BashOperator(task_id='PRE_CDE06_D_X_PAL_APP_CUST_MRG_POLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('POLLING_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"POLLING_CHECK.py GRP POLLING_CHECK CDE06_D_G_PAL_P1_Day0_Extract CMSA_CUST_PER_MERGED -y,", dag=dag)
PRE_CDE06_D_X_PAL_APP_CARDS_POLL = BashOperator(task_id='PRE_CDE06_D_X_PAL_APP_CARDS_POLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('POLLING_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"POLLING_CHECK.py GRP POLLING_CHECK CDE06_D_G_PAL_P1_Day0_Extract CMSA_OTH_ASS_COM_S -y,", dag=dag)
PRE_CDE06_D_X_PAL_CUST_PORT_DAILY_POLL = BashOperator(task_id='PRE_CDE06_D_X_PAL_CUST_PORT_DAILY_POLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('POLLING_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"POLLING_CHECK.py GRP POLLING_CHECK CDE06_D_G_PAL_P1_Day0_Extract UKB_TMICUPH_CUS_PORT_H -y,", dag=dag)
PRE_CDE06_D_X_APP_PARM_UPLIFT_POLL = BashOperator(task_id='PRE_CDE06_D_X_APP_PARM_UPLIFT_POLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('POLLING_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"POLLING_CHECK.py GRP POLLING_CHECK CDE06_D_G_PAL_P1_Day0_Extract CMSA_TBZCSDP_PARM_P -y,", dag=dag)
PRE_CDE06_D_X_PAL_ACCOUNT_POLL = BashOperator(task_id='PRE_CDE06_D_X_PAL_ACCOUNT_POLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('POLLING_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"POLLING_CHECK.py GRP POLLING_CHECK CDE06_D_G_PAL_P1_Day0_Extract CMS_AC_UNIT_PERM_DLY -y,", dag=dag)
PRE_CDE06_D_X_NONPERS_CUST_DAILY_POLL = BashOperator(task_id='PRE_CDE06_D_X_NONPERS_CUST_DAILY_POLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('POLLING_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"POLLING_CHECK.py GRP POLLING_CHECK CDE06_D_G_PAL_P1_Day0_Extract UKB_TMINPCU_N_PERS_CUS -y,", dag=dag)


CDE06_D_X_PAL_ACCOUNT_ROW_COUNT_CHECK = BashOperator(task_id='CDE06_D_X_PAL_ACCOUNT_ROW_COUNT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ATHENA_ROW_COUNT_CHECK')+" "+cmd_part+"\" "+ATHENA_ROW_COUNT_CHECK_PATH+" GRP ATHENA_ROW_COUNT_CHECK CDE06_D_G_PAL_P1_Day0_Extract T_CMS_AC_UNIT_PERM_DLY -y,", dag=dag)
CDE06_D_X_PAL_APP_CORE_ROW_COUNT_CHECK = BashOperator(task_id='CDE06_D_X_PAL_APP_CORE_ROW_COUNT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ATHENA_ROW_COUNT_CHECK')+" "+cmd_part+"\" "+ATHENA_ROW_COUNT_CHECK_PATH+" GRP ATHENA_ROW_COUNT_CHECK CDE06_D_G_PAL_P1_Day0_Extract T_CMSA_APPLIC_MERGED -y,", dag=dag)
CDE06_D_X_PAL_CUST_PORT_DAILY_ROW_COUNT_CHECK = BashOperator(task_id='CDE06_D_X_PAL_CUST_PORT_DAILY_ROW_COUNT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ATHENA_ROW_COUNT_CHECK')+" "+cmd_part+"\" "+ATHENA_ROW_COUNT_CHECK_PATH+" GRP ATHENA_ROW_COUNT_CHECK CDE06_D_G_PAL_P1_Day0_Extract T_UKB_TMICUPH_CUS_PORT_H -y,", dag=dag)
CDE06_D_X_NONPERS_CUST_DAILY_ROW_COUNT_CHECK = BashOperator(task_id='CDE06_D_X_NONPERS_CUST_DAILY_ROW_COUNT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ATHENA_ROW_COUNT_CHECK')+" "+cmd_part+"\" "+ATHENA_ROW_COUNT_CHECK_PATH+" GRP ATHENA_ROW_COUNT_CHECK CDE06_D_G_PAL_P1_Day0_Extract T_UKB_TMINPCU_N_PERS_CUS_DAILY -y,", dag=dag)
CDE06_D_X_PAL_APP_CARDS_ROW_COUNT_CHECK = BashOperator(task_id='CDE06_D_X_PAL_APP_CARDS_ROW_COUNT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ATHENA_ROW_COUNT_CHECK')+" "+cmd_part+"\" "+ATHENA_ROW_COUNT_CHECK_PATH+" GRP ATHENA_ROW_COUNT_CHECK CDE06_D_G_PAL_P1_Day0_Extract T_CMSA_OTH_ASS_COM_S -y,", dag=dag)
CDE06_D_X_PAL_ACC_CONN_DAILY_ROW_COUNT_CHECK = BashOperator(task_id='CDE06_D_X_PAL_ACC_CONN_DAILY_ROW_COUNT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ATHENA_ROW_COUNT_CHECK')+" "+cmd_part+"\" "+ATHENA_ROW_COUNT_CHECK_PATH+" GRP ATHENA_ROW_COUNT_CHECK CDE06_D_G_PAL_P1_Day0_Extract T_UKB_TMICACH_CUS_ACCONH_DAILY -y,", dag=dag)
CDE06_D_X_PAL_PERS_CUST_DAILY_ROW_COUNT_CHECK = BashOperator(task_id='CDE06_D_X_PAL_PERS_CUST_DAILY_ROW_COUNT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ATHENA_ROW_COUNT_CHECK')+" "+cmd_part+"\" "+ATHENA_ROW_COUNT_CHECK_PATH+" GRP ATHENA_ROW_COUNT_CHECK CDE06_D_G_PAL_P1_Day0_Extract T_UKB_TMIPCUS_PERS_CUST_DAILY -y,", dag=dag)
CDE06_D_X_APP_PARM_UPLIFT_ROW_COUNT_CHECK = BashOperator(task_id='CDE06_D_X_APP_PARM_UPLIFT_ROW_COUNT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ATHENA_ROW_COUNT_CHECK')+" "+cmd_part+"\" "+ATHENA_ROW_COUNT_CHECK_PATH+" GRP ATHENA_ROW_COUNT_CHECK CDE06_D_G_PAL_P1_Day0_Extract T_CMSA_TBZCSDP_PARM_P -y,", dag=dag)
CDE06_D_X_PAL_APP_CUST_MRG_ROW_COUNT_CHECK = BashOperator(task_id='CDE06_D_X_PAL_APP_CUST_MRG_ROW_COUNT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ATHENA_ROW_COUNT_CHECK')+" "+cmd_part+"\" "+ATHENA_ROW_COUNT_CHECK_PATH+" GRP ATHENA_ROW_COUNT_CHECK CDE06_D_G_PAL_P1_Day0_Extract T_CMSA_CUST_PER_MERGED -y,", dag=dag)
CDE06_D_X_PAL_APP_SCORING_ROW_COUNT_CHECK = BashOperator(task_id='CDE06_D_X_PAL_APP_SCORING_ROW_COUNT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ATHENA_ROW_COUNT_CHECK')+" "+cmd_part+"\" "+ATHENA_ROW_COUNT_CHECK_PATH+" GRP ATHENA_ROW_COUNT_CHECK CDE06_D_G_PAL_P1_Day0_Extract T_CMSA_CR_SCOR_RES_P -y,", dag=dag)


# added for code tuning - parallelization
START.set_downstream(DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(PRE_CDE06_D_X_PAL_APP_CORE_POLL)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(PRE_CDE06_D_X_PAL_ACCOUNT_POLL)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(PRE_CDE06_D_X_PAL_APP_CARDS_POLL)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(PRE_CDE06_D_X_PAL_APP_CUST_MRG_POLL)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(PRE_CDE06_D_X_PAL_APP_SCORING_POLL)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(PRE_CDE06_D_X_PAL_ACC_CONN_DAILY_POLL)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(PRE_CDE06_D_X_PAL_PERS_CUST_DAILY_POLL)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(PRE_CDE06_D_X_PAL_CUST_PORT_DAILY_POLL)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(PRE_CDE06_D_X_APP_PARM_UPLIFT_POLL)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(PRE_CDE06_D_X_NONPERS_CUST_DAILY_POLL)
DEPENDENCY_CHECK_D_G_BATCH_CTRL_FLOW.set_downstream(CDE06_D_X_SAO_APPLICATIONS)

PRE_CDE06_D_X_PAL_APP_CORE_POLL.set_downstream(CDE06_D_X_PAL_APP_CORE_ROW_COUNT_CHECK)
PRE_CDE06_D_X_PAL_ACCOUNT_POLL.set_downstream(CDE06_D_X_PAL_ACCOUNT_ROW_COUNT_CHECK)
PRE_CDE06_D_X_PAL_APP_CARDS_POLL.set_downstream(CDE06_D_X_PAL_APP_CARDS_ROW_COUNT_CHECK)
PRE_CDE06_D_X_PAL_APP_CUST_MRG_POLL.set_downstream(CDE06_D_X_PAL_APP_CUST_MRG_ROW_COUNT_CHECK)
PRE_CDE06_D_X_PAL_APP_SCORING_POLL.set_downstream(CDE06_D_X_PAL_APP_SCORING_ROW_COUNT_CHECK)
PRE_CDE06_D_X_PAL_ACC_CONN_DAILY_POLL.set_downstream(CDE06_D_X_PAL_ACC_CONN_DAILY_ROW_COUNT_CHECK)
PRE_CDE06_D_X_PAL_PERS_CUST_DAILY_POLL.set_downstream(CDE06_D_X_PAL_PERS_CUST_DAILY_ROW_COUNT_CHECK)
PRE_CDE06_D_X_PAL_CUST_PORT_DAILY_POLL.set_downstream(CDE06_D_X_PAL_CUST_PORT_DAILY_ROW_COUNT_CHECK)
PRE_CDE06_D_X_APP_PARM_UPLIFT_POLL.set_downstream(CDE06_D_X_APP_PARM_UPLIFT_ROW_COUNT_CHECK)
PRE_CDE06_D_X_NONPERS_CUST_DAILY_POLL.set_downstream(CDE06_D_X_NONPERS_CUST_DAILY_ROW_COUNT_CHECK)

CDE06_D_X_PAL_APP_CORE_ROW_COUNT_CHECK.set_downstream(CDE06_D_X_PAL_APP_CORE)
CDE06_D_X_PAL_ACCOUNT_ROW_COUNT_CHECK.set_downstream(CDE06_D_X_PAL_ACCOUNT)
CDE06_D_X_PAL_APP_CARDS_ROW_COUNT_CHECK.set_downstream(CDE06_D_X_PAL_APP_CARDS)
CDE06_D_X_PAL_APP_CUST_MRG_ROW_COUNT_CHECK.set_downstream(CDE06_D_X_PAL_APP_CUST_MRG)
CDE06_D_X_PAL_APP_SCORING_ROW_COUNT_CHECK.set_downstream(CDE06_D_X_PAL_APP_SCORING)
CDE06_D_X_PAL_ACC_CONN_DAILY_ROW_COUNT_CHECK.set_downstream(CDE06_D_X_PAL_ACC_CONN_DAILY)
CDE06_D_X_PAL_PERS_CUST_DAILY_ROW_COUNT_CHECK.set_downstream(CDE06_D_X_PAL_PERS_CUST_DAILY)
CDE06_D_X_PAL_CUST_PORT_DAILY_ROW_COUNT_CHECK.set_downstream(CDE06_D_X_PAL_CUST_PORT_DAILY)
CDE06_D_X_APP_PARM_UPLIFT_ROW_COUNT_CHECK.set_downstream(CDE06_D_X_APP_PARM_UPLIFT)
CDE06_D_X_NONPERS_CUST_DAILY_ROW_COUNT_CHECK.set_downstream(CDE06_D_X_NONPERS_CUST_DAILY)


# added for code tuning - parallelization
# START.set_downstream(CDE06_D_X_PAL_APP_CORE)
# START.set_downstream(CDE06_D_X_PAL_ACCOUNT)
# START.set_downstream(CDE06_D_X_PAL_APP_CARDS)
# START.set_downstream(CDE06_D_X_PAL_APP_CUST_MRG)
# START.set_downstream(CDE06_D_X_PAL_APP_SCORING)
# START.set_downstream(CDE06_D_X_PAL_ACC_CONN_DAILY)
# START.set_downstream(CDE06_D_X_PAL_PERS_CUST_DAILY)
# START.set_downstream(CDE06_D_X_PAL_CUST_PORT_DAILY)
# START.set_downstream(CDE06_D_X_APP_PARM_UPLIFT)
# START.set_downstream(CDE06_D_X_NONPERS_CUST_DAILY)
#CDE06_D_X_NONPERS_CUST_DAILY.set_downstream(CDE06_D_G_RDR_BB_CONN_DATA)
#CDE06_D_G_RDR_BB_CONN_DATA.set_downstream(CDE06_D_X_SAO_APPLICATIONS)
#CDE06_D_X_SAO_APPLICATIONS.set_downstream(CDE99_D_X_NOTIFY)

CDE06_D_X_PAL_APP_CORE.set_downstream(END)
CDE06_D_X_PAL_ACCOUNT.set_downstream(END)
CDE06_D_X_PAL_APP_CARDS.set_downstream(END)
CDE06_D_X_PAL_APP_CUST_MRG.set_downstream(END)
CDE06_D_X_PAL_APP_SCORING.set_downstream(END)
CDE06_D_X_PAL_ACC_CONN_DAILY.set_downstream(END)
CDE06_D_X_PAL_PERS_CUST_DAILY.set_downstream(END)
CDE06_D_X_PAL_CUST_PORT_DAILY.set_downstream(END)
CDE06_D_X_APP_PARM_UPLIFT.set_downstream(END)
CDE06_D_X_NONPERS_CUST_DAILY.set_downstream(END)
CDE06_D_X_SAO_APPLICATIONS.set_downstream(END)

#CDE99_D_X_NOTIFY.set_downstream(END)

RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)



# commented for code tuning - parallelization of jobs
# START.set_downstream(CDE06_D_X_PAL_APP_CORE)
# CDE06_D_X_PAL_APP_CORE.set_downstream(CDE06_D_X_PAL_ACCOUNT)
# CDE06_D_X_PAL_ACCOUNT.set_downstream(CDE06_D_X_PAL_APP_CARDS)
# CDE06_D_X_PAL_APP_CARDS.set_downstream(CDE06_D_X_PAL_APP_CUST_MRG)
# CDE06_D_X_PAL_APP_CUST_MRG.set_downstream(CDE06_D_X_PAL_APP_SCORING)
# CDE06_D_X_PAL_APP_SCORING.set_downstream(CDE06_D_X_PAL_ACC_CONN_DAILY)
# CDE06_D_X_PAL_ACC_CONN_DAILY.set_downstream(CDE06_D_X_PAL_PERS_CUST_DAILY)
# CDE06_D_X_PAL_PERS_CUST_DAILY.set_downstream(CDE06_D_X_PAL_CUST_PORT_DAILY)
# CDE06_D_X_PAL_CUST_PORT_DAILY.set_downstream(CDE06_D_X_APP_PARM_UPLIFT)
# CDE06_D_X_APP_PARM_UPLIFT.set_downstream(CDE06_D_X_NONPERS_CUST_DAILY)
# #CDE06_D_X_NONPERS_CUST_DAILY.set_downstream(CDE06_D_G_RDR_BB_CONN_DATA)
# #CDE06_D_G_RDR_BB_CONN_DATA.set_downstream(CDE06_D_X_SAO_APPLICATIONS)
# #CDE06_D_X_SAO_APPLICATIONS.set_downstream(CDE99_D_X_NOTIFY)
# CDE06_D_X_NONPERS_CUST_DAILY.set_downstream(CDE99_D_X_NOTIFY)
# CDE99_D_X_NOTIFY.set_downstream(END)

# RUN_CHECK.set_downstream(START)
# RUN_CHECK.set_downstream(STOP)