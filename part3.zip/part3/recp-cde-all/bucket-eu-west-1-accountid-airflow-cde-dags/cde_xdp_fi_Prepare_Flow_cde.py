from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from datetime import date, datetime, time, timedelta
from airflow.utils.decorators import apply_defaults
from os.path import join, abspath
import os
from airflow import DAG
# from airflow.operators import SimpleHttpOperator, HttpSensor,   BashOperator, EmailOperator, S3KeySensor
from datetime import datetime, timedelta
#import settings as st
import glob
from datetime import date, datetime, time, timedelta
import random
import yaml
import botocore
import airflow
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import BranchPythonOperator
import json
from botocore.session import Session
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow import configuration as conf
from airflow.models import DagBag, TaskInstance
from botocore.exceptions import ClientError, ParamValidationError
from airflow.utils.state import State
from airflow.utils.trigger_rule import TriggerRule


#START_DATE = datetime.now() - timedelta(minutes=10)
START_DATE = datetime(2019, 10, 12, hour=10,minute=30)

args = {
    'owner': 'jalotan',
    'depends_on_past': False,
    'email': ['namit.jalota@rbs.co.uk'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'queue': 'sqs-airflow-cde',
    'retry_delay': timedelta(minutes=1),
    'start_date': START_DATE,
    'end_date': datetime(2099,12,31),
    'max_active_runs' : 1 ,
    'concurrency' : 1,
}



with open('/usr/local/airflow/ssh/variables.json') as json_file:
    data = json.load(json_file) 
account_id = data['AccountId']
json_file.close()

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

input_loc='s3://bucket-eu-west-1-{}-risk-cicd/cde/dags/config/rsr_airflow_config.yaml'.format(account_id)
DAG_NAME = "XDP_FI_PrepareFlow_cde"

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
EMR_LOCAL_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
MASTER_IP_FILE = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]


dag = DAG(
    dag_id=DAG_NAME,
    default_args=args,
    catchup=False,
    schedule_interval=None
)


def conditionally_trigger(context, dag_run_obj):
    """This function decides whether or not to Trigger the remote DAG"""
    c_p = context['params']['condition_param']
    print("Controller DAG : conditionally_trigger = {}".format(c_p))
    if context['params']['condition_param']:
        dag_run_obj.payload = {'message': context['params']['message']}
        print(dag_run_obj.payload)
        return dag_run_obj
    return None




# Define the single task in this controller example DAG
trigger_op3 = TriggerDagRunOperator(
    task_id='Trigger_NextDag',
    trigger_dag_id="XDP_FI_ProcessData_cde",
    python_callable=conditionally_trigger,
    params={'condition_param': True, 'message': 'Trigger'},
    dag=dag,
)


MASTER_IP = open(MASTER_IP_FILE,"r").read()
STATIC_CONFIG = ''
AIRFLOW_CONFIG = ''



DAG_LOCAL_PATH = '/usr/local/airflow/dags/'
DYNAMIC_DAG_PATH = abspath(join(DAG_LOCAL_PATH, 'rsr_airflow_config.yaml'))

SSH_COMMAND = "ssh -o StrictHostKeyChecking=no -t -i {key} hadoop@{master_ip} ".format(key=KEY_FILE, master_ip=MASTER_IP)
SPARK_ARGS = {
    'app': 'Framework',
    'argument':'spark-submit -v --executor-memory=6g --executor-cores=2  --driver-memory=3g --conf spark.executor.memoryOverhead=300m  --conf spark.executor.cores=2 --conf spark.driver.memoryOverhead=300m --conf spark.dynamicAllocation.initialExecutors=2  --conf spark.dynamicAllocation.minExecutors=2   --conf  spark.executor.instances=2    --conf spark.dynamicAllocation.maxExecutors=5  --conf spark.default.parallelism=20  --conf spark.sql.shuffle.partitions=20  --conf spark.serializer=org.apache.spark.serializer.KryoSerializer'
    }


arg_spark = '{}'.format(str(SPARK_ARGS['argument']))

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'
SPARK_SUBMIT_COMMAND = SSH_COMMAND + "\"{arg_sparks} {cmd_part} {emr_lcl}\"".format(arg_sparks = arg_spark, cmd_part = cmd_part, emr_lcl=EMR_LOCAL_PATH)
SHELL_COMMAND = SSH_COMMAND + "sudo sh {emr_lcl}".format(emr_lcl=EMR_LOCAL_PATH)
#first_task =  dag start

dag_start_op_0 = DummyOperator(
    task_id='START',
    dag=dag,)

transferFile_op1 = BashOperator(task_id='Prepare_Flow',
    bash_command="""{shell}batch-framework/mdf-sourcing/prepare_flow.sh {emr_lcl}batch-framework/mdf-sourcing""".format(shell=SHELL_COMMAND, emr_lcl=EMR_LOCAL_PATH),
    dag=dag, trigger_rule='all_success')

def checkFile(*args,**kwargs):
    try:
        print(input_loc)
        full_path = input_loc[5:]
        bucket_name=full_path.split("/")[0]
        full_path_list = full_path.split("/")
        key = ''
        len1 = len(full_path_list)
        k=1
        while k < len1 :
            key= key + "/" + full_path_list[k]
            k=k+1
        length = len(key)
        Key = key[1:length]
        myDict = {}
        myDict['bucket_name'] = Key
        session = Session()
        client = session.create_client('s3')
        obj_dict = client.list_objects(Bucket=bucket_name,Prefix=Key)
        print(obj_dict)
        size=obj_dict['Contents'][0]['Size']
        if size >= 5:
            return ['Trigger_NextDag']
        else :
            return ['END']
    except Exception as e :
        print(e)

branching_yaml = BranchPythonOperator(
    task_id='AreInputFilesPresent',
    python_callable=checkFile,
    dag=dag,
)

dag_stop_op_0 = DummyOperator(
    task_id='END',
    dag=dag,
    trigger_rule='none_failed')


dag_start_op_0 >> transferFile_op1 >> branching_yaml
branching_yaml >> [trigger_op3,dag_stop_op_0]
trigger_op3 >> dag_stop_op_0