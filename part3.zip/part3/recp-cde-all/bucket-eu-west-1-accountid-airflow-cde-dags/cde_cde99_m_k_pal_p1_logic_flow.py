from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from datetime import date, datetime, time, timedelta
import os
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
import boto3
import botocore.session 
import json
import yaml
from airflow.operators.subdag_operator import SubDagOperator
'''from cde_cde01_m_k_pal_prep_flow import child_dag_cde01_m_k_pal_prep_flow
from cde_cde03_m_k_passes_flow import child_dag_cde03_m_k_passes_flow
from cde_cde04_m_k_pal_outputs_flow import child_dag_cde04_m_k_pal_outputs_flow'''

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]
FLOW_DEPENDENCY = BASE_PATH+DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]


MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	

file = open(MASTER_IP,"r")
IP = file.read()
file.close

# Dependency Code check 
def call_dagbag(*op_args):
    flow_name = op_args[0]
    print('Check DAG '+str(flow_name))
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    
    dag_bag_list = dagbag.dags[flow_name] #dagid     
    call_status_check(dag_bag_list) # last dag state
   

def call_status_check(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_state = last_instance.get_state() # last dag state
        print('\n Last Execution state'+str(dag_state))

        if(str(dag_state) == 'success') :
            print ('Dependency Met')    
        else :
            print ('Dependency Not Met')
            call_wait(dag_bag_list)  
  
def call_wait(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(300)    # Sleep
    call_status_check(dag_bag_list)

flow_name="CDE99_M_K_PAL_P1_LOGIC_FLOW"
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name	
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key] 
    return str(polling_time)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val



default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}
dag = DAG('CDE99_M_K_PAL_P1_LOGIC_FLOW' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False,  max_active_runs=1)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
	
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)
	
START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE99_M_K_PAL_P1_LOGIC_FLOW -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE99_M_K_PAL_P1_LOGIC_FLOW -y,", dag=dag)

# Child DAG Definitions
'''subDag_cde01_m_k_pal_prep_flow = SubDagOperator(
	subdag=child_dag_cde01_m_k_pal_prep_flow('CDE99_M_K_PAL_P1_LOGIC_FLOW', 'CDE01_M_K_PAL_PREP_FLOW', default_args, dag.schedule_interval),
	task_id='CDE01_M_K_PAL_PREP_FLOW',
	default_args=default_args,
	dag=dag)
	
subDag_cde03_m_k_passes_flow = SubDagOperator(
	subdag=child_dag_cde03_m_k_passes_flow('CDE99_M_K_PAL_P1_LOGIC_FLOW', 'CDE03_M_K_PASSES_FLOW', default_args, dag.schedule_interval),
	task_id='CDE03_M_K_PASSES_FLOW',
	default_args=default_args,
	dag=dag)

subDag_cde04_m_k_pal_outputs_flow= SubDagOperator(
	subdag=child_dag_cde04_m_k_pal_outputs_flow('CDE99_M_K_PAL_P1_LOGIC_FLOW', 'CDE04_M_K_PAL_OUTPUTS_FLOW', default_args, dag.schedule_interval),
	task_id='CDE04_M_K_PAL_OUTPUTS_FLOW',
	default_args=default_args,
	dag=dag)
	
subDag_cde04_m_k_powerc_cust_lvl_flow = SubDagOperator(
subdag=child_dag_cde04_m_k_powerc_cust_lvl_flow('CDE99_M_K_PAL_P1_LOGIC_FLOW','CDE04_M_K_PAL_OUTPUTS_FLOW', 'CDE04_M_K_POWERC_CUST_LVL_FLOW', args, dag.schedule_interval),
task_id='CDE04_M_K_POWERC_CUST_LVL_FLOW',
default_args=args,
dag=dag)

subDag_cde07_m_k_riskmart_load_flow= SubDagOperator(
subdag=child_dag_cde07_m_k_riskmart_load_flow('CDE99_M_K_PAL_P1_LOGIC_FLOW','CDE04_M_K_PAL_OUTPUTS_FLOW', 'CDE07_M_K_RISKMART_LOAD_FLOW', args, dag.schedule_interval),
task_id='CDE07_M_K_RISKMART_LOAD_FLOW',
default_args=args,
dag=dag)'''	

'''dependency_check_m_k_probe_logic  = PythonOperator(task_id='DEPENDENCY_CHECK_M_K_PROBE_LOGIC', python_callable=call_dagbag, op_args =['CDE99_M_K_PROBE_LOGIC_FLOW'], trigger_rule="all_done", dag=dag)
dependency_check_m_g_gurn_master  = PythonOperator(task_id='DEPENDENCY_CHECK_M_G_GURN_MASTER', python_callable=call_dagbag, op_args =['CDE99_M_G_GURN_MASTER_FLOW'], trigger_rule="all_done", dag=dag)
dependency_check_m_k_bus_logic  = PythonOperator(task_id='DEPENDENCY_CHECK_M_K_BUS_LOGIC', python_callable=call_dagbag, op_args =['CDE99_M_K_BUS_LOGIC_FLOW'], trigger_rule="all_done", dag=dag)'''

#CDE01_M_K_PAL_PREP_FLOW
CDE01_M_X_PAL_ACCOUNT_PREP = BashOperator(task_id='CDE01_M_X_PAL_ACCOUNT_PREP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PAL_ACCOUNT_PREP')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PAL_ACCOUNT_PREP.py UBS CDE01_M_X_PAL_ACCOUNT_PREP CDE01_M_K_PAL_PREP_FLOW -y,", dag=dag)
#CDE01_M_X_PAL_EXTRACT_CHECK = BashOperator(task_id='CDE01_M_X_PAL_EXTRACT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PAL_EXTRACT_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PAL_EXTRACT_CHECK.py UBS CDE01_M_X_PAL_EXTRACT_CHECK CDE01_M_K_PAL_PREP_FLOW -y,", dag=dag)
CDE01_M_X_PAL_FINAL_PREP = BashOperator(task_id='CDE01_M_X_PAL_FINAL_PREP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PAL_FINAL_PREP')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PAL_FINAL_PREP.py UBS CDE01_M_X_PAL_FINAL_PREP CDE01_M_K_PAL_PREP_FLOW -y,", dag=dag)
#CDE01_M_X_PAL_EXTRACT_CHECK.set_downstream(CDE01_M_X_PAL_ACCOUNT_PREP)
CDE01_M_X_PAL_ACCOUNT_PREP.set_downstream(CDE01_M_X_PAL_FINAL_PREP)

#CDE03_M_K_PASSES_FLOW
CDE03_M_K_PASSES_RECOMM = BashOperator(task_id='CDE03_M_K_PASSES_RECOMM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_K_PASSES_RECOMM')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_K_PASSES_RECOMM.py UBS CDE03_M_K_PASSES_RECOMM CDE03_M_K_PASSES_FLOW -y,", dag=dag)

#CDE04_M_K_PAL_OUTPUTS_FLOW
CDE01_M_X_PAL_SCREEN_BUILD = BashOperator(task_id='CDE01_M_X_PAL_SCREEN_BUILD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PAL_SCREEN_BUILD')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PAL_SCREEN_BUILD.py UBS CDE01_M_X_PAL_SCREEN_BUILD CDE04_M_K_PAL_OUTPUTS_FLOW -y,", dag=dag)
CDE04_M_K_PASSES_OUTPUT_MAPPER = BashOperator(task_id='CDE04_M_K_PASSES_OUTPUT_MAPPER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_K_PASSES_OUTPUT_MAPPER')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_K_PASSES_OUTPUT_MAPPER.py UBS CDE04_M_K_PASSES_OUTPUT_MAPPER CDE04_M_K_PAL_OUTPUTS_FLOW -y,", dag=dag)
CDE05_M_X_PAL_VAL = BashOperator(task_id='CDE05_M_X_PAL_VAL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_PAL_VAL')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_PAL_VAL.py UBS CDE05_M_X_PAL_VAL CDE04_M_K_PAL_OUTPUTS_FLOW -y,", dag=dag)
#CDE99_M_X_REMOVE_PAL_LOGIC_OK_FILE = BashOperator(task_id='CDE99_M_X_REMOVE_PAL_LOGIC_OK_FILE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE99_M_X_REMOVE_PAL_LOGIC_OK_FILE')+" "+cmd_part+"\" "+JOB_PATH+"CDE99_M_X_REMOVE_PAL_LOGIC_OK_FILE.py UBS CDE99_M_X_REMOVE_PAL_LOGIC_OK_FILE CDE04_M_K_PAL_OUTPUTS_FLOW -y,", dag=dag)

#CDE04_M_K_POWERC_CUST_LVL_FLOW
CDE04_M_X_PAL_CUST_POWERCR = BashOperator(task_id='CDE04_M_X_PAL_CUST_POWERCR' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_X_PAL_CUST_POWERCR')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_X_PAL_CUST_POWERCR.py UBS CDE04_M_X_PAL_CUST_POWERCR CDE04_M_X_PAL_CUST_POWERCR -y,", dag=dag)	

#CDE07_M_K_RISKMART_LOAD_FLOW
CDE07_M_X_PAL_OUT = BashOperator(task_id='CDE07_M_X_PAL_OUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_OUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_OUT.py UBS CDE07_M_X_PAL_OUT CDE07_M_K_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_PAL_INPUT = BashOperator(task_id='CDE07_M_X_PAL_INPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_INPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_INPUT.py UBS CDE07_M_X_PAL_INPUT CDE07_M_K_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_PAL_VLD = BashOperator(task_id='CDE07_M_X_PAL_VLD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_VLD')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_VLD.py UBS CDE07_M_X_PAL_VLD CDE07_M_K_RISKMART_LOAD_FLOW -y,", dag=dag)

dag_start_riskmart_load_flow= DummyOperator(task_id='START_CDE07_M_K_RISKMART_LOAD_FLOW',dag=dag,)
dag_end_riskmart_load_flow= DummyOperator(task_id='END_CDE07_M_K_RISKMART_LOAD_FLOW',dag=dag,)

dag_start_riskmart_load_flow.set_downstream(CDE07_M_X_PAL_OUT)
dag_start_riskmart_load_flow.set_downstream(CDE07_M_X_PAL_INPUT)
dag_start_riskmart_load_flow.set_downstream(CDE07_M_X_PAL_VLD)
CDE07_M_X_PAL_OUT.set_downstream(dag_end_riskmart_load_flow)
CDE07_M_X_PAL_INPUT.set_downstream(dag_end_riskmart_load_flow)
CDE07_M_X_PAL_VLD.set_downstream(dag_end_riskmart_load_flow)

CDE04_M_K_PASSES_OUTPUT_MAPPER.set_downstream(CDE01_M_X_PAL_SCREEN_BUILD)
CDE04_M_K_PASSES_OUTPUT_MAPPER.set_downstream(CDE05_M_X_PAL_VAL)
#subDag_cde04_m_k_powerc_cust_lvl_flow.set_downstream(CDE99_M_X_REMOVE_PAL_LOGIC_OK_FILE)
#CDE01_M_X_PAL_SCREEN_BUILD.set_downstream(CDE99_M_X_REMOVE_PAL_LOGIC_OK_FILE)
#CDE05_M_X_PAL_VAL.set_downstream(CDE99_M_X_REMOVE_PAL_LOGIC_OK_FILE)
CDE04_M_K_PASSES_OUTPUT_MAPPER.set_downstream(CDE04_M_X_PAL_CUST_POWERCR)
CDE01_M_X_PAL_SCREEN_BUILD.set_downstream(dag_start_riskmart_load_flow)
CDE05_M_X_PAL_VAL.set_downstream(dag_start_riskmart_load_flow)

#CDER-5685
DEPENDENCY_CHECK_M_K_PROBE_LOGIC= BashOperator(task_id='DEPENDENCY_CHECK_M_K_PROBE_LOGIC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_K_PROBE_LOGIC_POST_GURN_FLOW "+get_polling_time('CDE99_M_K_PROBE_LOGIC_POST_GURN_FLOW')+" -y,", dag=dag)
DEPENDENCY_CHECK_M_G_GURN_MASTER= BashOperator(task_id='DEPENDENCY_CHECK_M_G_GURN_MASTER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_G_GURN_MASTER_FLOW "+get_polling_time('CDE99_M_G_GURN_MASTER_FLOW')+" -y,", dag=dag)
DEPENDENCY_CHECK_M_K_BUS_LOGIC= BashOperator(task_id='DEPENDENCY_CHECK_M_K_BUS_LOGIC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_K_BUS_LOGIC_FLOW "+get_polling_time('CDE99_M_K_BUS_LOGIC_FLOW')+" -y,", dag=dag)
# added for [master flow sourcing check]
SOURCING_CHECK= BashOperator(task_id='SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE99_M_K_PAL_P1_LOGIC_FLOW -y,", dag=dag)

START.set_downstream(SOURCING_CHECK)
SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_M_K_PROBE_LOGIC)
SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_M_G_GURN_MASTER)
SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_M_K_BUS_LOGIC)

DEPENDENCY_CHECK_M_K_PROBE_LOGIC.set_downstream(CDE01_M_X_PAL_ACCOUNT_PREP)
DEPENDENCY_CHECK_M_K_BUS_LOGIC.set_downstream(CDE01_M_X_PAL_ACCOUNT_PREP)
DEPENDENCY_CHECK_M_G_GURN_MASTER.set_downstream(CDE01_M_X_PAL_ACCOUNT_PREP)

CDE01_M_X_PAL_FINAL_PREP.set_downstream(CDE03_M_K_PASSES_RECOMM)
CDE03_M_K_PASSES_RECOMM.set_downstream(CDE04_M_K_PASSES_OUTPUT_MAPPER)

# START.set_downstream(dependency_check_m_k_probe_logic)
# START.set_downstream(dependency_check_m_g_gurn_master)
# START.set_downstream(dependency_check_m_k_bus_logic)
#subDag_cde04_m_k_pal_outputs_flow.set_downstream(END)
CDE04_M_X_PAL_CUST_POWERCR.set_downstream(END)
dag_end_riskmart_load_flow.set_downstream(END)

RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)
