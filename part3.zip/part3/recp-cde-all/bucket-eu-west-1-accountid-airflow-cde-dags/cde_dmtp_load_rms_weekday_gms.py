import json
import logging
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.utils.helpers import chain
from datetime import datetime, timedelta
import boto3
import yaml

########################################################################
AIRFLOW_FLOW_NAME='cde_dmtp_load_rms_weekday_gms'
########################################################################

default_args = {
    'owner': 'DMTP',
    'depends_on_past': False,
    'email': ['piotr.kasprowicz@natwest.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'queue': 'sqs-airflow-cde',
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2021, 3, 1),
    'end_date': datetime(2099,12,31),
}

dag = DAG(AIRFLOW_FLOW_NAME, default_args=default_args, schedule_interval="40 22 * * 1-5", concurrency = 6, max_active_runs=1, catchup=False)

### ARIFLOW DAG SETUP CODE ** END ###

### PORTION FOR DAG SUBMISSION START ####
s3 = boto3.client('s3')

### Get EMR key

KEY_FILE = "/usr/local/airflow/ssh/cde-emr-ec2-key.pem"

with open("/usr/local/airflow/ssh/cde-emr-ip.txt", "r") as dmo_emr_ip:
    IP = dmo_emr_ip.read()

### Get AWS Account ID

#Extract the AWS account id
with open('/usr/local/airflow/ssh/variables.json') as json_file:
    data = json.load(json_file) 
aws_account_id = data['AccountId']
json_file.close()

# Get current date
run_date = "{{ (dag_run.start_date).strftime('%Y-%m-%d') }}"
logging.info("#" * 30)
logging.info("RUN DATE : {}".format(run_date))
logging.info("#" * 30)

# Set variables
brand = "RMS"
schedule = "WEEKDAY_GMS"

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    s3 = boto3.resource('s3')
    bucketname, itemname = path_to_bucket_key(filepath)
    obj = s3.Object(bucketname, itemname)
    body = obj.get()['Body'].read().decode(encoding)
    return body

spark_config_yaml_path = "s3://bucket-eu-west-1-"+aws_account_id+"-risk-cicd/cde/dags/config/dmtp_spark_config.yaml"
SPARK_CONFIG_FILE = read_s3_file(spark_config_yaml_path)
SPARK_CONFIG_DICT = yaml.safe_load(SPARK_CONFIG_FILE)
staging_jobs_yaml_path = "s3://bucket-eu-west-1-"+aws_account_id+"-risk-cicd/cde/dags/config/dmtp_staging_jobs_config.yaml"
STAGING_JOBS_CONFIG_FILE = read_s3_file(staging_jobs_yaml_path)
STAGING_JOBS_CONFIG_DICT = yaml.safe_load(STAGING_JOBS_CONFIG_FILE)

TABLES_DICT = STAGING_JOBS_CONFIG_DICT[brand+"_"+schedule]

def ok_file_check(file,**kwargs):
    import os
    import sys
    import subprocess
    bash_cmd = "ssh -o StrictHostKeyChecking=no -t -i "+KEY_FILE+" hadoop@" + IP + " test -f /home/hadoop/dmo/{brand}_BANK_HOLIDAY.OK ".format(brand=brand)
    file_check_process = subprocess.Popen(bash_cmd, shell=True, stdout=subprocess.PIPE)
    file_check_process.wait()
    if file_check_process.returncode == 0:
        print("Today is bank holiday, new feeds are not expected and staging will not run")
        return "STOP"
    else:
        print("Today is not a bank holiday, new feeds are expected and staging will run")
        return "SYNC_CODE"

SYNC_CODE = BashOperator(task_id='SYNC_CODE' , bash_command="ssh -o StrictHostKeyChecking=no -t -i "+KEY_FILE+" hadoop@" + IP + " sudo aws s3 sync s3://bucket-eu-west-1-{AWS_ACCOUNT_ID}-risk-cicd/cde/code/DMTP/release_dmtp_data_sourcing_1.0 /home/hadoop/dmo ".format(AWS_ACCOUNT_ID=aws_account_id), dag=dag)

HOLIDAY_CHECK = BashOperator(task_id='HOLIDAY_CHECK' , bash_command="ssh -o StrictHostKeyChecking=no -t -i "+KEY_FILE+" hadoop@" + IP + " spark-submit -v --executor-memory=500m --driver-memory=500m --conf spark.executor.memoryOverhead=100m --conf spark.executor.cores=1 --conf spark.driver.memoryOverhead=100m --conf spark.dynamicAllocation.initialExecutors=1 --conf spark.dynamicAllocation.minExecutors=1 --conf spark.executor.instances=1 --conf spark.dynamicAllocation.maxExecutors=1 --conf spark.default.parallelism=10 --conf spark.sql.shuffle.partitions=10 /home/hadoop/dmo/batch/holiday_checker.py {brand} {run_date} ".format(brand=brand,run_date=run_date), dag=dag)
OK_FILE_CHECK =  BranchPythonOperator(task_id='OK_FILE_CHECK',python_callable=ok_file_check,op_kwargs={'file': "/home/hadoop/dmo/{brand}_BANK_HOLIDAY.OK".format(brand=brand)},dag = dag,provide_context=True)

STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)

START = DummyOperator(
    task_id='START',
    dag=dag,)

### Task definition - one per table
for table in TABLES_DICT:
    brand = TABLES_DICT[table][0]
    subbrand = TABLES_DICT[table][1]
    table_name = TABLES_DICT[table][2]
    file_name = TABLES_DICT[table][3]
    job_name = TABLES_DICT[table][4]
    spark_config_type = TABLES_DICT[table][5]
    spark_config = SPARK_CONFIG_DICT[spark_config_type]
    # Copying the files for RCE use
    input_path = "s3://bucket-eu-west-1-{0}-landing-zone/data-in/cde/feeds/mdf/{1}".format(aws_account_id,file_name)
    output_path = "s3://bucket-eu-west-1-{0}-processed-data/transformation/cde/cde_staging/DMTP_feeds_copy/{1}".format(aws_account_id,file_name)
    copy_cmd = "aws s3 cp {0} {1}".format(input_path,output_path)
    file_check_task = BashOperator(
        task_id = "{}_FILE_CHECK".format(file_name.split(".")[0]),
        bash_command = "ssh -o StrictHostKeyChecking=no -t -i "+KEY_FILE+" hadoop@" + IP + " ' python3 /home/hadoop/dmo/batch/file_checker.py {AWS_ACCOUNT_ID} {file_name} && {copy_cmd} ' ".format(file_name=file_name,AWS_ACCOUNT_ID=aws_account_id,copy_cmd=copy_cmd), 
        retries = 2,
        dag=dag
    )
    staging_task = BashOperator(
        task_id = "{}_STAGING".format(file_name.split(".")[0]),
        bash_command = "ssh -o StrictHostKeyChecking=no -t -i "+KEY_FILE+" hadoop@" + IP + " spark-submit {spark_config} /home/hadoop/dmo/jobs/{job_name} {brand} {subbrand} {AWS_ACCOUNT_ID} {table_name} {run_date}".format(spark_config=spark_config,brand=brand,subbrand=subbrand,job_name=job_name,AWS_ACCOUNT_ID=aws_account_id,table_name=table_name,run_date=run_date), 
        retries = 3,
        dag=dag
    )
    START.set_downstream(file_check_task)
    file_check_task.set_downstream(staging_task)

SYNC_CODE.set_downstream(HOLIDAY_CHECK)
HOLIDAY_CHECK.set_downstream(OK_FILE_CHECK)
OK_FILE_CHECK.set_downstream(STOP)
OK_FILE_CHECK.set_downstream(START)