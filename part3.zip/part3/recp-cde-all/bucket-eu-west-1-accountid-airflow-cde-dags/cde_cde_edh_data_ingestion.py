try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO
import botocore.session # pylint: disable=import-error
from os.path import join, abspath
import traceback
from collections import namedtuple

import yaml
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 

import os
import sys
import json



SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

flow_name="CDE_EDH_DATA_INGESTION"
sourcing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/edh_sourcing_config.yaml"
dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]

dag_config_yaml_path_1 = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
DAG_CONFIG_FILE_1 = read_s3_file(dag_config_yaml_path_1)
DAG_CONFIG_DICT_1 = yaml.safe_load(DAG_CONFIG_FILE_1)
cde_env_1 = DAG_CONFIG_DICT_1["CDE_ENV"]
BASE_PATH_ENV_1 = "BASE_PATH_"+cde_env_1
BASE_PATH_1 = DAG_CONFIG_DICT_1[BASE_PATH_ENV_1]
LOG_START_PATH = BASE_PATH_1+DAG_CONFIG_DICT_1["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH_1+DAG_CONFIG_DICT_1["LOG_STATUS_END"]

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]

#SOURCING_SCRIPT_PATH = DAG_CONFIG_DICT["SOURCING_SCRIPT_PATH"]
edh_dag_schedule = DAG_CONFIG_DICT["EDH_DAG_SCHEDULE"]
edh_dag_concurrency = DAG_CONFIG_DICT["EDH_DAG_CONCURRENCY"]

file = open(MASTER_IP,"r")
IP = file.read()
file.close

CONFIG_FILE = read_s3_file(sourcing_yaml_path)
CONFIG_DICT = yaml.safe_load(CONFIG_FILE)

## adding yaml file as prt of NPBJ-2099
cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)



#TERADATA_SCRIPT_PATH = BASE_PATH+DAG_CONFIG_DICT["TERADATA_SCRIPT_PATH"]
#TERADATA_PREPROCESSOR_SCRIPT_PATH = BASE_PATH+DAG_CONFIG_DICT["TERADATA_PREPROCESSOR_SCRIPT_PATH"]

#EDH_TO_STG_SCRIPT_PATH : batch-framework/mdf-sourcing/edh_to_staging_load.py
#STG_TO_MAIN_SCRIPT_PATH : batch-framework/mdf-sourcing/edh_stg_to_main_load.py
EDH_TO_STG_SCRIPT_PATH = BASE_PATH+DAG_CONFIG_DICT["EDH_TO_STG_SCRIPT_PATH"]
EDH_STG_TO_MAIN_SCRIPT_PATH = BASE_PATH+DAG_CONFIG_DICT["EDH_STG_TO_MAIN_SCRIPT_PATH"]

#print('\n BASE_PATH'+BASE_PATH+'\n SOURCING_SCRIPT_PATH'+SOURCING_SCRIPT_PATH+'\n edh_dag_schedule'+edh_dag_schedule+'\n edh_dag_concurrency'+str(edh_dag_concurrency)+'\n TERADATA_SCRIPT_PATH'+TERADATA_SCRIPT_PATH)
dag = DAG('CDE_EDH_DATA_INGESTION' , default_args=default_args, schedule_interval=edh_dag_schedule, catchup=False, max_active_runs=1, concurrency = edh_dag_concurrency)


START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE_EDH_DATA_INGESTION -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE_EDH_DATA_INGESTION -y,", dag=dag)


files_list_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/edh_tables_list.csv"

##FileProcessingStarts = DummyOperator(
##    task_id='FileProcessingStarts',
##    dag=dag,)
	
##FileProcessingEnds = DummyOperator(
##    task_id='FileProcessingEnds',
##  dag=dag,)	

def create_dag():
    dagList = read_s3_file(files_list_path)     
    lines = dagList.split('\n')
    #preprocessing=0
    for x in lines: 
        st = x.strip()

        if str(st.split(",")[6].strip().split(" ")[2].strip()) == str(datetime.today().day) or str(st.split(",")[6].strip().split(" ")[2].strip()) == "*": 

            edhAccount= str(st.split(",")[0].strip())
            edhDb = str( st.split(",")[1].strip())
            edhTable = str( st.split(",")[2].strip())
            awsStgDbTable=str(st.split(",")[3].strip() + "." + st.split(",")[4].strip()) #contains <db>.<tablename>
            awsDbTable=str(st.split(",")[3].strip() + "." + st.split(",")[5].strip()) #contains <db>.<tablename>
            fullOrPartial=str(st.split(",")[8].strip()) 
            partialCondition=str(st.split(",")[7].strip())             
            dagItem=str(st.split(",")[3].strip() + "." + st.split(",")[5].strip()) #contains <db>.<tablename>
            file_str = "FILE_"+dagItem  
            size_str = "SIZE_"+dagItem 	
            FILE_NAME = CONFIG_DICT[file_str]
            
            FILE_SIZE = CONFIG_DICT[size_str]
            spark_config_str = "SPARK_CONFIG_PARAM_"+FILE_SIZE            
            spark_config_param = DAG_CONFIG_DICT[spark_config_str]
            print("spark_config_param: " + spark_config_param)
            #print("TERADATA_PREPROCESSOR_SCRIPT_PATH: " + TERADATA_PREPROCESSOR_SCRIPT_PATH)
            task_id_process = 'EDHToSTG_'+dagItem
            EDH_TO_STAGING = BashOperator(task_id=task_id_process , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param+" "+EDH_TO_STG_SCRIPT_PATH+" "+ edhAccount + " " + edhDb + " " + edhTable + " " + awsStgDbTable +   " " + awsDbTable +  " " + fullOrPartial + " " + partialCondition +   " -y,", dag=dag)                
            task_id_process = 'STGToMain_'+dagItem
            STAGING_TO_FINAL = BashOperator(task_id=task_id_process , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param+" "+EDH_STG_TO_MAIN_SCRIPT_PATH + " " +  awsStgDbTable + " " + awsDbTable +  " -y,", dag=dag)                
            
            START.set_downstream(EDH_TO_STAGING)
            EDH_TO_STAGING.set_downstream(STAGING_TO_FINAL)
            STAGING_TO_FINAL.set_downstream(END)
create_dag()

