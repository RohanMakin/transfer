try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO
import botocore.session # pylint: disable=import-error
from os.path import join, abspath
import traceback
from collections import namedtuple
import yaml
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 

import os
import sys 
import json


SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date':  datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()
	
dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"
LANDING_ZONE = "s3://bucket-eu-west-1-"+account_id+"-landing-zone/data-in/cde"
TRANSFORMATION_LOC = "s3://bucket-eu-west-1-"+account_id+"-processed-data/transformation/cde"
PRESENTATION_LOC = "s3://bucket-eu-west-1-"+account_id+"-processed-data/presentation/cde"
LANDING_BUCKET="s3://bucket-eu-west-1-"+account_id+"-landing-zone"

DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
ENV = DAG_CONFIG_DICT["CDE_ENV"]

script_loc="scripts/airflow/"
job_loc="batch-framework/teradata-migration/"
job_name="refresh_backup_data_to_prod.sh"
athena_job_name="refresh_athena_backup_data_to_prod.sh"
repair_table_script='repair_table.sh'
Config_file_loc1='batch-framework/teradata-migration/data_transfer_table_info1.ini'
Config_file_loc2='batch-framework/teradata-migration/data_transfer_table_info2.ini'
Config_file_loc3='batch-framework/teradata-migration/data_transfer_table_info3.ini'

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]
CDE_FILE_LOC=DAG_CONFIG_DICT["CDE_FILE_LOC"]
SOURCING_SCRIPT_PATH=DAG_CONFIG_DICT["SOURCING_SCRIPT_PATH"]
spark_config_param = DAG_CONFIG_DICT["SPARK_CONFIG_PARAM_3G"]

file = open(MASTER_IP,"r")
IP = file.read()
file.close

dag = DAG('CDE_REFRESH_PROD_SRC_DATA' , default_args=default_args, schedule_interval=None, catchup=False, max_active_runs=1)

CDE_REFRESH_PROD_SRC_DATA1 = BashOperator(task_id='CDE_REFRESH_PROD_SRC_DATA1' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+job_name +" "+Config_file_loc1+" "+CDE_FILE_LOC+" "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)
CDE_REFRESH_PROD_SRC_DATA2 = BashOperator(task_id='CDE_REFRESH_PROD_SRC_DATA2' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+job_name +" "+Config_file_loc2+" "+CDE_FILE_LOC+" "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)
CDE_REFRESH_PROD_SRC_DATA3 = BashOperator(task_id='CDE_REFRESH_PROD_SRC_DATA3' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+job_name +" "+Config_file_loc3+" "+CDE_FILE_LOC+" "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)
CDE_REFRESH_ATHENA_PROD_SRC_DATA = BashOperator(task_id='CDE_REFRESH_ATHENA_PROD_SRC_DATA' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+athena_job_name +" "+Config_file_loc3+" "+CDE_FILE_LOC+" "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)
CDE_REPAIR_TABLE = BashOperator(task_id='CDE_REPAIR_TABLE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+repair_table_script +" -y,", dag=dag)

CDE_REFRESH_PROD_SRC_DATA1.set_downstream(CDE_REPAIR_TABLE)
CDE_REFRESH_PROD_SRC_DATA2.set_downstream(CDE_REPAIR_TABLE)
CDE_REFRESH_PROD_SRC_DATA3.set_downstream(CDE_REPAIR_TABLE)
