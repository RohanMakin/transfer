from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from datetime import date, datetime, time, timedelta
import os
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
import boto3
import botocore.session 
import json
import yaml
'''from cde_cde01_d_k_accum_flow import child_dag_cde01_d_k_accum_flow
from cde_cde06_d_k_probe_extracts import child_dag_cde06_d_k_probe_extracts'''
from airflow.operators.subdag_operator import SubDagOperator

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
ACCUM_LASTRUN_PATH = BASE_PATH+DAG_CONFIG_DICT["ACCUM_LASTRUN_PATH"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]
CONCURRENCY_ACCUM_FLOW = DAG_CONFIG_DICT["CONCURRENCY_ACCUM_FLOW"]
SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]
FLOW_DEPENDENCY = BASE_PATH+DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	

file = open(MASTER_IP,"r")
IP = file.read()
file.close

# Dependency Code check 
def call_dagbag(*op_args):
    flow_name = op_args[0]
    print('Check DAG '+str(flow_name))
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    
    dag_bag_list = dagbag.dags[flow_name] #dagid     
    call_status_check(dag_bag_list) # last dag state
   

def call_status_check(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_state = last_instance.get_state() # last dag state
        print('\n Last Execution state'+str(dag_state))

        if(str(dag_state) == 'success') :
            print ('Dependency Met')    
        else :
            print ('Dependency Not Met')
            call_wait(dag_bag_list)  
  
def call_wait(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(300)    # Sleep
    call_status_check(dag_bag_list)

flow_name="CDE99_D_K_PROBE_ACCUM_FLOW"
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name	
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key] 
    return str(polling_time)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val



default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}
dag = DAG('CDE99_D_K_PROBE_ACCUM_FLOW' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False,  max_active_runs=1, concurrency = CONCURRENCY_ACCUM_FLOW)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
	
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)
	
START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE99_D_K_PROBE_ACCUM_FLOW -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE99_D_K_PROBE_ACCUM_FLOW -y,", dag=dag)
LAST_RUN_CHECK= BashOperator(task_id='LAST_RUN_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('LAST_RUN_CHECK')+" "+cmd_part+"\" "+ACCUM_LASTRUN_PATH+" CDE99_D_K_PROBE_ACCUM_FLOW -y,", dag=dag)
##CDER-5800 Adding batch ctrl dependency 
DEPENDENCY_CHECK_D_K_BATCH_CTRL_FLOW= BashOperator(task_id='DEPENDENCY_CHECK_D_K_BATCH_CTRL_FLOW' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_D_K_BATCH_CTRL_UPDATE_FLOW "+get_polling_time('CDE99_D_K_BATCH_CTRL_UPDATE_FLOW')+" -y,", dag=dag)
# Child DAG Definitions
'''subDag_cde01_d_k_accum_flow = SubDagOperator(
	subdag=child_dag_cde01_d_k_accum_flow('CDE99_D_K_PROBE_ACCUM_FLOW', 'CDE01_D_K_ACCUM_FLOW', default_args, dag.schedule_interval),
	task_id='CDE01_D_K_ACCUM_FLOW',
	default_args=default_args,
	dag=dag)

subDag_cde06_d_k_probe_extracts = SubDagOperator(
	subdag=child_dag_cde06_d_k_probe_extracts('CDE99_D_K_PROBE_ACCUM_FLOW', 'CDE06_D_K_PROBE_Extracts', default_args, dag.schedule_interval),
	task_id='CDE06_D_K_PROBE_Extracts',
	default_args=default_args,
	dag=dag)
'''

#CDE01_D_K_ACCUM_FLOW
dag_start_accum = DummyOperator(task_id='START_CDE01_D_K_ACCUM_FLOW',dag=dag,)
dag_end_accum = DummyOperator(task_id='END_CDE01_D_K_ACCUM_FLOW',dag=dag,)
CDE00_D_X_ACCOUNT_MASTER_ALL = BashOperator(task_id='CDE00_D_X_ACCOUNT_MASTER_ALL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_D_X_ACCOUNT_MASTER_ALL')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_D_X_ACCOUNT_MASTER_ALL.py UBS CDE00_D_X_ACCOUNT_MASTER_ALL CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE00_D_X_ACCOUNT_MASTER_DAILY = BashOperator(task_id='CDE00_D_X_ACCOUNT_MASTER_DAILY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_D_X_ACCOUNT_MASTER_DAILY')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_D_X_ACCOUNT_MASTER_DAILY.py UBS CDE00_D_X_ACCOUNT_MASTER_DAILY CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE00_D_X_ACCOUNT_TYPE = BashOperator(task_id='CDE00_D_X_ACCOUNT_TYPE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_D_X_ACCOUNT_TYPE')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_D_X_ACCOUNT_TYPE.py UBS CDE00_D_X_ACCOUNT_TYPE CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE00_D_X_BRANCH = BashOperator(task_id='CDE00_D_X_BRANCH' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_D_X_BRANCH')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_D_X_BRANCH.py UBS CDE00_D_X_BRANCH CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE00_D_X_FRL_DAILY_ALL = BashOperator(task_id='CDE00_D_X_FRL_DAILY_ALL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_D_X_FRL_DAILY_ALL')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_D_X_FRL_DAILY_ALL.py UBS CDE00_D_X_FRL_DAILY_ALL CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE00_D_X_LOAN_DETAILS = BashOperator(task_id='CDE00_D_X_LOAN_DETAILS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_D_X_LOAN_DETAILS')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_D_X_LOAN_DETAILS.py UBS CDE00_D_X_LOAN_DETAILS CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE00_D_X_TRANSACTION_HIST_FRL = BashOperator(task_id='CDE00_D_X_TRANSACTION_HIST_FRL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_D_X_TRANSACTION_HIST_FRL')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_D_X_TRANSACTION_HIST_FRL.py UBS CDE00_D_X_TRANSACTION_HIST_FRL CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE00_D_X_TRANSACTION_HIST = BashOperator(task_id='CDE00_D_X_TRANSACTION_HIST' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_D_X_TRANSACTION_HIST')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_D_X_TRANSACTION_HIST.py UBS CDE00_D_X_TRANSACTION_HIST CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_CAUSTIC_ACC_MERGE = BashOperator(task_id='CDE01_D_X_CAUSTIC_ACC_MERGE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_CAUSTIC_ACC_MERGE')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_CAUSTIC_ACC_MERGE.py UBS CDE01_D_X_CAUSTIC_ACC_MERGE CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_Caustic_ACC_V000 = BashOperator(task_id='CDE01_D_X_Caustic_ACC_V000' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_Caustic_ACC_V000')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_CAUSTIC_ACC_V000.py UBS CDE01_D_X_CAUSTIC_ACC_V000 CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_Caustic_ACC_V100 = BashOperator(task_id='CDE01_D_X_Caustic_ACC_V100' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_Caustic_ACC_V100')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_CAUSTIC_ACC_V100.py UBS CDE01_D_X_CAUSTIC_ACC_V100 CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_Caustic_ACC_V200 = BashOperator(task_id='CDE01_D_X_Caustic_ACC_V200' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_Caustic_ACC_V200')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_CAUSTIC_ACC_V200.py UBS CDE01_D_X_CAUSTIC_ACC_V200 CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_Caustic_ACC_V300 = BashOperator(task_id='CDE01_D_X_Caustic_ACC_V300' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_Caustic_ACC_V300')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_CAUSTIC_ACC_V300.py UBS CDE01_D_X_CAUSTIC_ACC_V300 CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_Caustic_ACC_V400 = BashOperator(task_id='CDE01_D_X_Caustic_ACC_V400' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_Caustic_ACC_V400')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_CAUSTIC_ACC_V400.py UBS CDE01_D_X_CAUSTIC_ACC_V400 CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_HIREP_ACC_MERGE = BashOperator(task_id='CDE01_D_X_HIREP_ACC_MERGE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_HIREP_ACC_MERGE')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_HIREP_ACC_MERGE.py UBS CDE01_D_X_HIREP_ACC_MERGE CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_HIREP_ACC_V000F = BashOperator(task_id='CDE01_D_X_HIREP_ACC_V000F' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_HIREP_ACC_V000F')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_HIREP_ACC_V000F.py UBS CDE01_D_X_HIREP_ACC_V000F CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_HIREP_ACC_V100F = BashOperator(task_id='CDE01_D_X_HIREP_ACC_V100F' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_HIREP_ACC_V100F')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_HIREP_ACC_V100F.py UBS CDE01_D_X_HIREP_ACC_V100F CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_HIREP_ACC_V200F = BashOperator(task_id='CDE01_D_X_HIREP_ACC_V200F' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_HIREP_ACC_V200F')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_HIREP_ACC_V200F.py UBS CDE01_D_X_HIREP_ACC_V200F CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_HIREP_ACC_V300F = BashOperator(task_id='CDE01_D_X_HIREP_ACC_V300F' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_HIREP_ACC_V300F')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_HIREP_ACC_V300F.py UBS CDE01_D_X_HIREP_ACC_V300F CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_HIREP_ACC_V400F = BashOperator(task_id='CDE01_D_X_HIREP_ACC_V400F' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_HIREP_ACC_V400F')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_HIREP_ACC_V400F.py UBS CDE01_D_X_HIREP_ACC_V400F CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_Trans_AGG_FRL = BashOperator(task_id='CDE01_D_X_Trans_AGG_FRL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_Trans_AGG_FRL')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_TRANS_AGG_FRL.py UBS CDE01_D_X_TRANS_AGG_FRL CDE01_D_K_ACCUM_FLOW -y,", dag=dag)
CDE01_D_X_Trans_AGG = BashOperator(task_id='CDE01_D_X_Trans_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_X_Trans_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_X_TRANS_AGG.py UBS CDE01_D_X_TRANS_AGG CDE01_D_K_ACCUM_FLOW -y,", dag=dag)

CDE01_D_X_Caustic_ACC_V000.set_downstream(CDE01_D_X_CAUSTIC_ACC_MERGE)
CDE01_D_X_Caustic_ACC_V100.set_downstream(CDE01_D_X_CAUSTIC_ACC_MERGE)
CDE01_D_X_Caustic_ACC_V200.set_downstream(CDE01_D_X_CAUSTIC_ACC_MERGE)
CDE01_D_X_Caustic_ACC_V300.set_downstream(CDE01_D_X_CAUSTIC_ACC_MERGE)
CDE01_D_X_Caustic_ACC_V400.set_downstream(CDE01_D_X_CAUSTIC_ACC_MERGE)
CDE01_D_X_Trans_AGG.set_downstream(CDE01_D_X_Caustic_ACC_V000)
CDE01_D_X_Trans_AGG.set_downstream(CDE01_D_X_Caustic_ACC_V100)
CDE01_D_X_Trans_AGG.set_downstream(CDE01_D_X_Caustic_ACC_V200)
CDE01_D_X_Trans_AGG.set_downstream(CDE01_D_X_Caustic_ACC_V300)
CDE01_D_X_Trans_AGG.set_downstream(CDE01_D_X_Caustic_ACC_V400)
CDE01_D_X_HIREP_ACC_V000F.set_downstream(CDE01_D_X_HIREP_ACC_MERGE)
CDE01_D_X_HIREP_ACC_V100F.set_downstream(CDE01_D_X_HIREP_ACC_MERGE)
CDE01_D_X_HIREP_ACC_V200F.set_downstream(CDE01_D_X_HIREP_ACC_MERGE)
CDE01_D_X_HIREP_ACC_V300F.set_downstream(CDE01_D_X_HIREP_ACC_MERGE)
CDE01_D_X_HIREP_ACC_V400F.set_downstream(CDE01_D_X_HIREP_ACC_MERGE)
CDE01_D_X_Trans_AGG_FRL.set_downstream(CDE01_D_X_HIREP_ACC_V000F)
CDE01_D_X_Trans_AGG_FRL.set_downstream(CDE01_D_X_HIREP_ACC_V100F)
CDE01_D_X_Trans_AGG_FRL.set_downstream(CDE01_D_X_HIREP_ACC_V200F)
CDE01_D_X_Trans_AGG_FRL.set_downstream(CDE01_D_X_HIREP_ACC_V300F)
CDE01_D_X_Trans_AGG_FRL.set_downstream(CDE01_D_X_HIREP_ACC_V400F)
CDE00_D_X_TRANSACTION_HIST_FRL.set_downstream(CDE01_D_X_Trans_AGG_FRL)
CDE00_D_X_FRL_DAILY_ALL.set_downstream(CDE01_D_X_Trans_AGG_FRL)
CDE00_D_X_ACCOUNT_MASTER_DAILY.set_downstream(CDE01_D_X_Trans_AGG)
CDE00_D_X_LOAN_DETAILS.set_downstream(CDE01_D_X_Trans_AGG)
CDE00_D_X_TRANSACTION_HIST.set_downstream(CDE01_D_X_Trans_AGG)
CDE00_D_X_BRANCH.set_downstream(CDE01_D_X_Trans_AGG)
CDE00_D_X_ACCOUNT_TYPE.set_downstream(CDE01_D_X_Trans_AGG)
CDE00_D_X_ACCOUNT_MASTER_ALL.set_downstream(CDE01_D_X_Trans_AGG)
#CDE01_D_X_CAUSTIC_ACC_MERGE.set_downstream(CDE99_D_X_PRB_REMOVE_OK)
#CDE01_D_X_HIREP_ACC_MERGE.set_downstream(CDE99_D_X_PRB_REMOVE_OK)

## Dependency management within the ACCUM subflow
dag_start_accum.set_downstream(CDE00_D_X_BRANCH)
dag_start_accum.set_downstream(CDE00_D_X_LOAN_DETAILS)
dag_start_accum.set_downstream(CDE00_D_X_TRANSACTION_HIST)
dag_start_accum.set_downstream(CDE00_D_X_ACCOUNT_MASTER_ALL)
dag_start_accum.set_downstream(CDE00_D_X_ACCOUNT_MASTER_DAILY)
dag_start_accum.set_downstream(CDE00_D_X_ACCOUNT_TYPE)
dag_start_accum.set_downstream(CDE00_D_X_FRL_DAILY_ALL)
dag_start_accum.set_downstream(CDE00_D_X_TRANSACTION_HIST_FRL)


dag_end_accum.set_upstream(CDE01_D_X_HIREP_ACC_MERGE)
dag_end_accum.set_upstream(CDE01_D_X_CAUSTIC_ACC_MERGE)

#CDE06_D_K_PROBE_Extracts
# CDE06_D_X_CUST_ACCT = BashOperator(task_id='CDE06_D_X_CUST_ACCT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_CUST_ACCT')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_CUST_ACCT.py UBS CDE06_D_X_CUST_ACCT CDE06_D_K_PROBE_Extracts -y,", dag=dag)
# CDE06_D_X_LOAN_ACMAS = BashOperator(task_id='CDE06_D_X_LOAN_ACMAS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_LOAN_ACMAS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_LOAN_ACMAS.py UBS CDE06_D_X_LOAN_ACMAS CDE06_D_K_PROBE_Extracts -y,", dag=dag)
# CDE06_D_X_VLNDETS = BashOperator(task_id='CDE06_D_X_VLNDETS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_VLNDETS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_VLNDETS.py UBS CDE06_D_X_VLNDETS CDE06_D_K_PROBE_Extracts -y,", dag=dag)
CDE06_D_X_PROBE_EXTRACTS = BashOperator(task_id='CDE06_D_X_PROBE_EXTRACTS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_PROBE_EXTRACTS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_PROBE_EXTRACTS.py UBS CDE06_D_X_PROBE_EXTRACTS CDE06_D_K_PROBE_Extracts -y,", dag=dag)

SOURCING_CHECK= BashOperator(task_id='SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE99_D_K_PROBE_ACCUM_FLOW -y,", dag=dag)

CDE06_D_X_PROBE_EXTRACTS.set_downstream(dag_start_accum)

START.set_downstream(LAST_RUN_CHECK)
LAST_RUN_CHECK.set_downstream(DEPENDENCY_CHECK_D_K_BATCH_CTRL_FLOW)
DEPENDENCY_CHECK_D_K_BATCH_CTRL_FLOW.set_downstream(SOURCING_CHECK)
SOURCING_CHECK.set_downstream(CDE06_D_X_PROBE_EXTRACTS)

dag_end_accum.set_downstream(END)

RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)