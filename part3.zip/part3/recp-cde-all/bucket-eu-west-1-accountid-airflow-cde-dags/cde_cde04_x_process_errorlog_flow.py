try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO
import botocore.session # pylint: disable=import-error
from os.path import join, abspath
import traceback
from collections import namedtuple
import yaml
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from airflow.operators.python_operator import BranchPythonOperator
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
import boto3
import botocore.session 
import json
import yaml
import os

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)



SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
ENV = DAG_CONFIG_DICT["CDE_ENV"]
dag_job_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
DAG_JOB_CONFIG_FILE = read_s3_file(dag_job_config_yaml_path)
DAG_JOB_CONFIG_DICT = yaml.safe_load(DAG_JOB_CONFIG_FILE)
cde_env = DAG_JOB_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_JOB_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_JOB_CONFIG_DICT["JOB_PATH"]

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]
CDE_FILE_LOC=DAG_CONFIG_DICT["CDE_FILE_LOC"]

file = open(MASTER_IP,"r")
IP = file.read()
file.close


flow_name='CDE04_X_PROCESS_ERRORLOG_FLOW'
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"

def run_check_fun_dag(flowname):
    return_val_errlog = 'No_Errorlog_processing'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flowname:
            print("\n DAG scheduled for today")
            return_val_errlog = 'Errorlog_processing'    
    return return_val_errlog

default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date':  datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

dag = DAG('CDE04_X_PROCESS_ERRORLOG_FLOW' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1)


START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE04_X_PROCESS_ERRORLOG_FLOW -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE04_X_PROCESS_ERRORLOG_FLOW -y,", dag=dag)

errorlog_details_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/Errorlog_details.yaml"
ERRORLOG_CONFIG_FILE = read_s3_file(errorlog_details_yaml_path)
ERRORLOG_CONFIG_DICT = yaml.safe_load(ERRORLOG_CONFIG_FILE)

JOB_FILE_DICT_RBS = ERRORLOG_CONFIG_DICT["RBS"]
JOB_FILE_DICT_NWB = ERRORLOG_CONFIG_DICT["NWB"]
JOB_FILE_DICT_UBN = ERRORLOG_CONFIG_DICT["UBN"]
JOB_FILE_DICT_UBS = ERRORLOG_CONFIG_DICT["UBS"]
JOB_FILE_DICT_GRP = ERRORLOG_CONFIG_DICT["GRP"]


RBS = DummyOperator(
    task_id='RBS',
    dag=dag,)

NWB = DummyOperator(
    task_id='NWB',
    dag=dag,)

UBN = DummyOperator(
    task_id='UBN',
    dag=dag,)

UBS = DummyOperator(
    task_id='UBS',
    dag=dag,)
	
GRP = DummyOperator(
    task_id='GRP',
    dag=dag,)


for File in JOB_FILE_DICT_RBS:
    dependent_flow_name=JOB_FILE_DICT_RBS[File][0]
    polling_job=JOB_FILE_DICT_RBS[File][1]+".py"  
    File_name=JOB_FILE_DICT_RBS[File][2]  
    job_name=JOB_FILE_DICT_RBS[File][3]
    jobname=job_name+".py"
    execution_flag=run_check_fun_dag(dependent_flow_name)
    if execution_flag=='Errorlog_processing':		
        task_id_poll = "RBS_{}_POLL".format(File)
        task_id_job = "RBS_{}".format(job_name)
        task_var1= BashOperator(task_id=task_id_poll , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " python3  "+JOB_PATH+polling_job+" RBS "+File_name+" -y,", dag=dag)
        task_var2= BashOperator(task_id=task_id_job , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job(job_name)+" "+cmd_part+"\" "+JOB_PATH+jobname+" RBS "+job_name+" "+flow_name+" "+File_name+"  -y,", dag=dag)
        RBS.set_downstream(task_var1)
        task_var1.set_downstream(task_var2)
        task_var2.set_downstream(END)
    else:
        task_id_no_exec="RBS_{}_NOEXEC".format(File)
        RBS_No_execution = DummyOperator(task_id=task_id_no_exec,dag=dag,)     
        RBS.set_downstream(RBS_No_execution)
        RBS_No_execution.set_downstream(END)

for File in JOB_FILE_DICT_NWB:
    dependent_flow_name=JOB_FILE_DICT_NWB[File][0]
    polling_job=JOB_FILE_DICT_NWB[File][1]+".py"       
    File_name=JOB_FILE_DICT_NWB[File][2]
    job_name=JOB_FILE_DICT_NWB[File][3]
    jobname=job_name+".py"	
    execution_flag=run_check_fun_dag(dependent_flow_name)
    if execution_flag=='Errorlog_processing':
        task_id_poll = "NWB_{}_POLL".format(File)
        task_id_job = "NWB_{}".format(job_name)
        task_var1= BashOperator(task_id=task_id_poll , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " python3  "+JOB_PATH+polling_job+" NWB "+File_name+" -y,", dag=dag)
        task_var2= BashOperator(task_id=task_id_job , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job(job_name)+" "+cmd_part+"\" "+JOB_PATH+jobname+" NWB "+job_name+" "+flow_name+" "+File_name+"  -y,", dag=dag)
        NWB.set_downstream(task_var1)
        task_var1.set_downstream(task_var2)
        task_var2.set_downstream(END)
    else:
        task_id_no_exec="NWB_{}_NOEXEC".format(File)
        NWB_No_execution = DummyOperator(task_id=task_id_no_exec,dag=dag,)
        NWB.set_downstream(NWB_No_execution)
        NWB_No_execution.set_downstream(END)

for File in JOB_FILE_DICT_UBN:
    dependent_flow_name=JOB_FILE_DICT_UBN[File][0]
    polling_job=JOB_FILE_DICT_UBN[File][1]+".py"      
    File_name=JOB_FILE_DICT_UBN[File][2]  
    job_name=JOB_FILE_DICT_UBN[File][3]
    jobname=job_name+".py"
    execution_flag=run_check_fun_dag(dependent_flow_name)
    if execution_flag=='Errorlog_processing':
        task_id_poll = "UBN_{}_POLL".format(File)
        task_id_job = "UBN_{}".format(job_name)
        task_var1= BashOperator(task_id=task_id_poll , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " python3  "+JOB_PATH+polling_job+" UBN "+File_name+" -y,", dag=dag)
        task_var2= BashOperator(task_id=task_id_job , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job(job_name)+" "+cmd_part+"\" "+JOB_PATH+jobname+" UBN "+job_name+" "+flow_name+" "+File_name+"  -y,", dag=dag)
        UBN.set_downstream(task_var1)
        task_var1.set_downstream(task_var2)
        task_var2.set_downstream(END)
    else:
        task_id_no_exec="UBN_{}_NOEXEC".format(File)
        UBN_No_execution = DummyOperator(task_id=task_id_no_exec,dag=dag,)
        UBN.set_downstream(UBN_No_execution)
        UBN_No_execution.set_downstream(END)

for File in JOB_FILE_DICT_UBS:
    dependent_flow_name=JOB_FILE_DICT_UBS[File][0]
    polling_job=JOB_FILE_DICT_UBS[File][1]+".py"      
    File_name=JOB_FILE_DICT_UBS[File][2]  
    job_name=JOB_FILE_DICT_UBS[File][3]
    jobname=job_name+".py"
    execution_flag=run_check_fun_dag(dependent_flow_name)
    if execution_flag=='Errorlog_processing':
        task_id_poll = "UBS_{}_POLL".format(File)
        task_id_job = "UBS_{}".format(job_name)
        task_var1= BashOperator(task_id=task_id_poll , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " python3  "+JOB_PATH+polling_job+" UBS "+File_name+" -y,", dag=dag)
        task_var2= BashOperator(task_id=task_id_job , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job(job_name)+" "+cmd_part+"\" "+JOB_PATH+jobname+" UBS "+job_name+" "+flow_name+" "+File_name+"  -y,", dag=dag)
        UBS.set_downstream(task_var1)
        task_var1.set_downstream(task_var2)
        task_var2.set_downstream(END)
    else:
        task_id_no_exec="UBS_{}_NOEXEC".format(File)
        UBS_No_execution = DummyOperator(task_id=task_id_no_exec,dag=dag,)
        UBS.set_downstream(UBS_No_execution)
        UBS_No_execution.set_downstream(END)

for File in JOB_FILE_DICT_GRP:
    dependent_flow_name=JOB_FILE_DICT_GRP[File][0]
    polling_job=JOB_FILE_DICT_GRP[File][1]+".py"   
    File_name=JOB_FILE_DICT_GRP[File][2]
    job_name=JOB_FILE_DICT_GRP[File][3] 
    jobname=job_name+".py"
    execution_flag=run_check_fun_dag(dependent_flow_name)
    if execution_flag=='Errorlog_processing':	
        task_id_poll = "GRP_{}_POLL".format(File)
        task_id_job = "GRP_{}".format(job_name)
        task_var1= BashOperator(task_id=task_id_poll , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " python3  "+JOB_PATH+polling_job+" GRP "+File_name+" -y,", dag=dag)
        task_var2= BashOperator(task_id=task_id_job , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job(job_name)+" "+cmd_part+"\" "+JOB_PATH+jobname+" GRP "+job_name+" "+flow_name+" "+File_name+"  -y,", dag=dag)
        GRP.set_downstream(task_var1)
        task_var1.set_downstream(task_var2)
        task_var2.set_downstream(END)
    else:
        task_id_no_exec="GRP_{}_NOEXEC".format(File)
        GRP_No_execution = DummyOperator(task_id=task_id_no_exec,dag=dag,)
        GRP.set_downstream(GRP_No_execution)
        GRP_No_execution.set_downstream(END)

START.set_downstream(RBS)
START.set_downstream(NWB)
START.set_downstream(UBN)
START.set_downstream(UBS)
START.set_downstream(GRP)

