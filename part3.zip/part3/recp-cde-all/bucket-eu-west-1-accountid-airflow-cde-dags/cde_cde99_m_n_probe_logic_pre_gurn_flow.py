from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from datetime import date, datetime, time, timedelta
import os
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
from airflow.operators.subdag_operator import SubDagOperator

import boto3
import botocore.session 
import json
import yaml

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]
FLOW_DEPENDENCY = BASE_PATH+DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
CONCURRENCY_M_PROBE_LOGIC_FLOW = DAG_CONFIG_DICT["CONCURRENCY_M_PROBE_LOGIC_FLOW"]
MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	
TACTICAL_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["TACTICAL_SOURCING_CHECK"]
SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]
CDE_CONTROL = DAG_CONFIG_DICT["CDE_CONTROL"]
TRANSFORMATION_LOC = "s3://bucket-eu-west-1-"+account_id+"-processed-data/transformation/cde"
script_loc="scripts/airflow/"
script_name="subflow_trigger.sh"

file = open(MASTER_IP,"r")
IP = file.read()
file.close

# Dependency Code check 
def call_dagbag(*op_args):
    flow_name = op_args[0]
    print('Check DAG '+str(flow_name))
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    
    dag_bag_list = dagbag.dags[flow_name] #dagid     
    call_status_check(dag_bag_list) # last dag state
   

def call_status_check(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_state = last_instance.get_state() # last dag state
        print('\n Last Execution state'+str(dag_state))

        if(str(dag_state) == 'success') :
            print ('Dependency Met')    
        else :
            print ('Dependency Not Met')
            call_wait(dag_bag_list)   
  
def call_wait(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(300)    # Sleep
    call_status_check(dag_bag_list)

flow_name="CDE99_M_N_PROBE_LOGIC_PRE_GURN_FLOW"
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_CDE99_M_N_PROBE_LOGIC_PRE_GURN_FLOW"#+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]
	
cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name	
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key] 
    return str(polling_time)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val
	
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,11),
    'end_date': datetime(2099,12,31),
}

dag = DAG('CDE99_M_N_PROBE_LOGIC_PRE_GURN_FLOW' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1, concurrency = CONCURRENCY_M_PROBE_LOGIC_FLOW)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
	
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)
	
'''Dummy_Start = DummyOperator(
    task_id='Dummy_Start',
    dag=dag,)
	
Dummy_End = DummyOperator(
    task_id='Dummy_End',
    dag=dag,)'''

	
CDE01_M_N_FULLEX_FLOW_Start = DummyOperator(
    task_id='CDE01_M_N_FULLEX_FLOW_Start',
    dag=dag,)

CDE01_M_N_FULLEX_FLOW_End = DummyOperator(
    task_id='CDE01_M_N_FULLEX_FLOW_End',
    dag=dag,)	
	
START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE99_M_N_PROBE_LOGIC_PRE_GURN_FLOW -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE99_M_N_PROBE_LOGIC_PRE_GURN_FLOW -y,", dag=dag)
#CDER-5685
DEPENDENCY_CHECK_D_N_PROBE_ACCUM= BashOperator(task_id='DEPENDENCY_CHECK_D_N_PROBE_ACCUM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_D_N_PROBE_ACCUM_FLOW "+get_polling_time('CDE99_D_N_PROBE_ACCUM_FLOW')+" -y,", dag=dag)

# added for [master flow sourcing check]
SOURCING_CHECK= BashOperator(task_id='SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE99_M_N_PROBE_LOGIC_PRE_GURN_FLOW -y,", dag=dag)
START.set_downstream(SOURCING_CHECK)
SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_D_N_PROBE_ACCUM)

# added for [master flow tactical check] CDER-5651
# removal of dependency as it is not required
#TACTICAL_SOURCING_CHECK= BashOperator(task_id='TACTICAL_SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('TACTICAL_SOURCING_CHECK')+" "+cmd_part+"\" "+TACTICAL_CHECK_PATH + " CDE99_M_N_PROBE_LOGIC_PRE_GURN_FLOW -y,", dag=dag)
#START.set_downstream(TACTICAL_SOURCING_CHECK)
#TACTICAL_SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_D_N_PROBE_ACCUM)



# START.set_downstream(DEPENDENCY_CHECK_D_N_PROBE_ACCUM)

#CDE06_M_N_PROBE_Extracts
CDE06_M_X_PROBE_EXTRACTS = BashOperator(task_id='CDE06_M_X_PROBE_EXTRACTS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_PROBE_EXTRACTS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_PROBE_EXTRACTS.py NWB CDE06_M_X_PROBE_EXTRACTS CDE06_M_N_PROBE_EXTRACTS -y,", dag=dag)
#CDE06_M_X_EMP_COLL = BashOperator(task_id='CDE06_M_X_EMP_COLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_EMP_COLL')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_EMP_COLL.py NWB CDE06_M_X_EMP_COLL CDE06_M_N_PROBE_Extracts -y,", dag=dag)
#CDE06_M_X_REF_COLL = BashOperator(task_id='CDE06_M_X_REF_COLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_REF_COLL')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_REF_COLL.py NWB CDE06_M_X_REF_COLL CDE06_M_N_PROBE_Extracts -y,", dag=dag)
#CDE06_M_X_SERV_CHG_PLTFRM = BashOperator(task_id='CDE06_M_X_SERV_CHG_PLTFRM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_SERV_CHG_PLTFRM')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_SERV_CHG_PLTFRM.py NWB CDE06_M_X_SERV_CHG_PLTFRM CDE06_M_N_PROBE_Extracts -y,", dag=dag)
#CDE06_M_X_BUS_PAL_REF_IND_CODE = BashOperator(task_id='CDE06_M_X_BUS_PAL_REF_IND_CODE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_BUS_PAL_REF_IND_CODE')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_BUS_PAL_REF_IND_CODE.py NWB CDE06_M_X_BUS_PAL_REF_IND_CODE CDE06_M_N_PROBE_Extracts -y,", dag=dag)
#CDE06_M_X_PAL_CCARD_BIS_CC = BashOperator(task_id='CDE06_M_X_PAL_CCARD_BIS_CC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_PAL_CCARD_BIS_CC')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_PAL_CCARD_BIS_CC.py NWB CDE06_M_X_PAL_CCARD_BIS_CC CDE06_M_N_PROBE_Extracts -y,", dag=dag)
#DEPENDENCY_CHECK_D_N_PROBE_ACCUM.set_downstream(CDE06_M_X_EMP_COLL)
#CDE06_M_X_EMP_COLL.set_downstream(CDE06_M_X_REF_COLL)
#CDE06_M_X_REF_COLL.set_downstream(CDE06_M_X_SERV_CHG_PLTFRM)
#CDE06_M_X_SERV_CHG_PLTFRM.set_downstream(CDE06_M_X_BUS_PAL_REF_IND_CODE)
#CDE06_M_X_BUS_PAL_REF_IND_CODE.set_downstream(CDE06_M_X_PAL_CCARD_BIS_CC)
DEPENDENCY_CHECK_D_N_PROBE_ACCUM.set_downstream(CDE06_M_X_PROBE_EXTRACTS)


#CDE01_M_N_GMB_PYDYL_TRANS


CDE01_M_X_DB_TRANS_FLAG_AGG = BashOperator(task_id='CDE01_M_X_DB_TRANS_FLAG_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_DB_TRANS_FLAG_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_DB_TRANS_FLAG_AGG.py NWB CDE01_M_X_DB_TRANS_FLAG_AGG CDE01_M_N_GMB_PYDYL_TRANS -y,", dag=dag)
CDE01_M_X_DB_TRANS_FLAG = BashOperator(task_id='CDE01_M_X_DB_TRANS_FLAG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_DB_TRANS_FLAG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_DB_TRANS_FLAG.py NWB CDE01_M_X_DB_TRANS_FLAG CDE01_M_N_GMB_PYDYL_TRANS -y,", dag=dag)
CDE01_M_X_INC_CALC = BashOperator(task_id='CDE01_M_X_INC_CALC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_INC_CALC')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_INC_CALC.py NWB CDE01_M_X_INC_CALC CDE01_M_N_GMB_PYDYL_TRANS -y,", dag=dag)
CDE01_M_X_TRANS_FLAG_AGG = BashOperator(task_id='CDE01_M_X_TRANS_FLAG_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_TRANS_FLAG_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_TRANS_FLAG_AGG.py NWB CDE01_M_X_TRANS_FLAG_AGG CDE01_M_N_GMB_PYDYL_TRANS -y,", dag=dag)
CDE01_M_X_TRANS_FLAG = BashOperator(task_id='CDE01_M_X_TRANS_FLAG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_TRANS_FLAG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_TRANS_FLAG.py NWB CDE01_M_X_TRANS_FLAG CDE01_M_N_GMB_PYDYL_TRANS -y,", dag=dag)
CDE01_M_X_DB_TRANS_FLAG.set_downstream(CDE01_M_X_DB_TRANS_FLAG_AGG)
CDE01_M_X_TRANS_FLAG.set_downstream(CDE01_M_X_TRANS_FLAG_AGG)

DEPENDENCY_CHECK_D_N_PROBE_ACCUM.set_downstream(CDE01_M_X_TRANS_FLAG)
DEPENDENCY_CHECK_D_N_PROBE_ACCUM.set_downstream(CDE01_M_X_DB_TRANS_FLAG)
DEPENDENCY_CHECK_D_N_PROBE_ACCUM.set_downstream(CDE01_M_X_INC_CALC)


#CDE01_M_N_CUST_MASTER_BUS_FLOW


CDE01_M_X_CUSTOMER_DERIVATIONS_BUS = BashOperator(task_id='CDE01_M_X_CUSTOMER_DERIVATIONS_BUS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CUSTOMER_DERIVATIONS_BUS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CUSTOMER_DERIVATIONS_BUS.py NWB CDE01_M_X_CUSTOMER_DERIVATIONS_BUS CDE01_M_N_CUST_MASTER_BUS_FLOW -y,", dag=dag)
#CDE06_M_X_PAL_CCARD_BIS_CC.set_downstream(CDE01_M_X_CUSTOMER_DERIVATIONS_BUS)
CDE06_M_X_PROBE_EXTRACTS.set_downstream(CDE01_M_X_CUSTOMER_DERIVATIONS_BUS)

#CDE01_M_N_Driver_Account_FLOW 

#CDE00_M_X_ACCOUNT_HISTORY_PERS = BashOperator(task_id='CDE00_M_X_ACCOUNT_HISTORY_PERS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('XXXXXX')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_ACCOUNT_HISTORY_PERS.py NWB CDE01_M_N_Driver_Account_FLOW -y,", dag=dag)
CDE00_M_X_FRL_ACCOUNT_MASTER = BashOperator(task_id='CDE00_M_X_FRL_ACCOUNT_MASTER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_FRL_ACCOUNT_MASTER')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_FRL_ACCOUNT_MASTER.py NWB CDE00_M_X_FRL_ACCOUNT_MASTER CDE01_M_N_Driver_Account_FLOW -y,", dag=dag)
CDE00_M_X_FRL_ARREARS = BashOperator(task_id='CDE00_M_X_FRL_ARREARS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_FRL_ARREARS')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_FRL_ARREARS.py NWB CDE00_M_X_FRL_ARREARS CDE01_M_N_Driver_Account_FLOW -y,", dag=dag)
CDE00_M_X_LOAN_ACC_MASTER = BashOperator(task_id='CDE00_M_X_LOAN_ACC_MASTER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_LOAN_ACC_MASTER')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_LOAN_ACC_MASTER.py NWB CDE00_M_X_LOAN_ACC_MASTER CDE01_M_N_Driver_Account_FLOW -y,", dag=dag)
CDE01_M_X_Driver_Account_Extract_V000 = BashOperator(task_id='CDE01_M_X_Driver_Account_Extract_V000' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_Driver_Account_Extract_V000')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_DRIVER_ACCOUNT_EXTRACT_V000.py NWB CDE01_M_X_DRIVER_ACCOUNT_EXTRACT_V000 CDE01_M_N_Driver_Account_FLOW -y,", dag=dag)
CDE01_M_X_Driver_Account_Extract_V100 = BashOperator(task_id='CDE01_M_X_Driver_Account_Extract_V100' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_Driver_Account_Extract_V100')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_DRIVER_ACCOUNT_EXTRACT_V100.py NWB CDE01_M_X_DRIVER_ACCOUNT_EXTRACT_V100 CDE01_M_N_Driver_Account_FLOW -y,", dag=dag)
CDE01_M_X_Driver_Account_Extract_V200F = BashOperator(task_id='CDE01_M_X_Driver_Account_Extract_V200F' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_Driver_Account_Extract_V200F')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_DRIVER_ACCOUNT_EXTRACT_V200F.py NWB CDE01_M_X_DRIVER_ACCOUNT_EXTRACT_V200F CDE01_M_N_Driver_Account_FLOW -y,", dag=dag)
CDE01_M_X_Driver_Account_Extract_V200 = BashOperator(task_id='CDE01_M_X_Driver_Account_Extract_V200' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_Driver_Account_Extract_V200')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_DRIVER_ACCOUNT_EXTRACT_V200.py NWB CDE01_M_X_DRIVER_ACCOUNT_EXTRACT_V200 CDE01_M_N_Driver_Account_FLOW -y,", dag=dag)
CDE01_M_X_Driver_Account_Merge = BashOperator(task_id='CDE01_M_X_Driver_Account_Merge' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_Driver_Account_Merge')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_DRIVER_ACCOUNT_MERGE.py NWB CDE01_M_X_DRIVER_ACCOUNT_MERGE CDE01_M_N_Driver_Account_FLOW -y,", dag=dag)
CDE01_M_X_CDE_RELATED_ACCT = BashOperator(task_id='CDE01_M_X_CDE_RELATED_ACCT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CDE_RELATED_ACCT')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CDE_RELATED_ACCT.py NWB CDE01_M_X_CDE_RELATED_ACCT CDE01_M_N_Driver_Account_FLOW -y,", dag=dag)
CDE00_M_X_LOAN_ACC_MASTER.set_downstream(CDE01_M_X_Driver_Account_Extract_V000)
#CDE00_M_X_ACCOUNT_HISTORY_PERS.set_downstream(CDE01_M_X_Driver_Account_Extract_V100)
CDE00_M_X_LOAN_ACC_MASTER.set_downstream(CDE01_M_X_Driver_Account_Extract_V100)
CDE00_M_X_FRL_ACCOUNT_MASTER.set_downstream(CDE01_M_X_Driver_Account_Extract_V200F)
CDE00_M_X_FRL_ARREARS.set_downstream(CDE01_M_X_Driver_Account_Extract_V200F)
CDE00_M_X_LOAN_ACC_MASTER.set_downstream(CDE01_M_X_Driver_Account_Extract_V200)
CDE01_M_X_Driver_Account_Extract_V000.set_downstream(CDE01_M_X_Driver_Account_Merge)
CDE01_M_X_Driver_Account_Extract_V100.set_downstream(CDE01_M_X_Driver_Account_Merge)
CDE01_M_X_Driver_Account_Extract_V200.set_downstream(CDE01_M_X_Driver_Account_Merge)
CDE01_M_X_Driver_Account_Extract_V200F.set_downstream(CDE01_M_X_Driver_Account_Merge)
CDE01_M_X_Driver_Account_Merge.set_downstream(CDE01_M_X_CDE_RELATED_ACCT)

#CDE06_M_X_PAL_CCARD_BIS_CC.set_downstream(CDE00_M_X_FRL_ACCOUNT_MASTER)
#CDE06_M_X_PAL_CCARD_BIS_CC.set_downstream(CDE00_M_X_FRL_ARREARS)
#CDE06_M_X_PAL_CCARD_BIS_CC.set_downstream(CDE00_M_X_LOAN_ACC_MASTER)
CDE06_M_X_PROBE_EXTRACTS.set_downstream(CDE00_M_X_FRL_ACCOUNT_MASTER)
CDE06_M_X_PROBE_EXTRACTS.set_downstream(CDE00_M_X_FRL_ARREARS)
CDE06_M_X_PROBE_EXTRACTS.set_downstream(CDE00_M_X_LOAN_ACC_MASTER)
#CDE01_M_N_CINTOACCA_FLOW


CDE01_M_X_PAL_RANKED_AGG = BashOperator(task_id='CDE01_M_X_PAL_RANKED_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PAL_RANKED_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PAL_RANKED_AGG.py NWB CDE01_M_X_PAL_RANKED_AGG CDE01_M_N_CINtoACCa_FLOW -y,", dag=dag)
CDE01_M_X_PAL_UNRANKED_AGG = BashOperator(task_id='CDE01_M_X_PAL_UNRANKED_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PAL_UNRANKED_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PAL_UNRANKED_AGG.py NWB CDE01_M_X_PAL_UNRANKED_AGG CDE01_M_N_CINtoACCa_FLOW -y,", dag=dag)
CDE01_M_X_PAL_RANKED_AGG.set_downstream(CDE01_M_X_PAL_UNRANKED_AGG)

#CDE06_M_X_PAL_CCARD_BIS_CC.set_downstream(CDE01_M_X_PAL_RANKED_AGG)
CDE06_M_X_PROBE_EXTRACTS.set_downstream(CDE01_M_X_PAL_RANKED_AGG)
# CDE01_M_N_CINTOACCB_FLOW


CDE00_M_X_PERSONAL_CUSTOMER = BashOperator(task_id='CDE00_M_X_PERSONAL_CUSTOMER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_PERSONAL_CUSTOMER')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_PERSONAL_CUSTOMER.py NWB CDE00_M_X_PERSONAL_CUSTOMER CDE01_M_N_CINtoACCb_FLOW -y,", dag=dag)
CDE01_M_X_PC_RANKED_AGG = BashOperator(task_id='CDE01_M_X_PC_RANKED_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PC_RANKED_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PC_RANKED_AGG.py NWB CDE01_M_X_PC_RANKED_AGG CDE01_M_N_CINtoACCb_FLOW -y,", dag=dag)
CDE00_M_X_PERSONAL_CUSTOMER.set_downstream(CDE01_M_X_PC_RANKED_AGG)

#CDE06_M_X_PAL_CCARD_BIS_CC.set_downstream(CDE00_M_X_PERSONAL_CUSTOMER)
CDE06_M_X_PROBE_EXTRACTS.set_downstream(CDE00_M_X_PERSONAL_CUSTOMER)
#CDE01_M_N_FULLEX_FLOW

CDE01_M_X_CUSTOMER_DERIVATIONS_BUS.set_downstream(CDE01_M_N_FULLEX_FLOW_Start)
CDE01_M_X_CDE_RELATED_ACCT.set_downstream(CDE01_M_N_FULLEX_FLOW_Start)
CDE01_M_X_PAL_UNRANKED_AGG.set_downstream(CDE01_M_N_FULLEX_FLOW_Start)
CDE01_M_X_PC_RANKED_AGG.set_downstream(CDE01_M_N_FULLEX_FLOW_Start)


#CDE_M_N_AUTO_TRANSFER_DATA_LOAD = BashOperator(task_id='CDE_M_N_AUTO_TRANSFER_DATA_LOAD' , bash_command="ssh -o StrictHostKeyChecking=no -t -i /usr/local/airflow/ssh/cde-emr-ec2-key.pem hadoop@" + IP + " sh /home/hadoop/cde/scripts/airflow/CDE_AUTO_TRANSFER_UBN.sh CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
#CDE00_M_X_ACCOUNT_HISTORY = BashOperator(task_id='CDE00_M_X_ACCOUNT_HISTORY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_ACCOUNT_HISTORY')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_ACCOUNT_HISTORY.py NWB CDE00_M_X_ACCOUNT_HISTORY CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE00_M_X_ACCOUNT_MASTER = BashOperator(task_id='CDE00_M_X_ACCOUNT_MASTER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_ACCOUNT_MASTER')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_ACCOUNT_MASTER.py NWB CDE00_M_X_ACCOUNT_MASTER CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE00_M_X_CDE_APPLICATION = BashOperator(task_id='CDE00_M_X_CDE_APPLICATION' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_CDE_APPLICATION')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_CDE_APPLICATION.py NWB CDE00_M_X_CDE_APPLICATION CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE00_M_X_CDE_PRE_EMP_COLL = BashOperator(task_id='CDE00_M_X_CDE_PRE_EMP_COLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_CDE_PRE_EMP_COLL')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_CDE_PRE_EMP_COLL.py NWB CDE00_M_X_CDE_PRE_EMP_COLL CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE00_M_X_CDE_REF_COLL = BashOperator(task_id='CDE00_M_X_CDE_REF_COLL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_CDE_REF_COLL')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_CDE_REF_COLL.py NWB CDE00_M_X_CDE_REF_COLL CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE00_M_X_CDE_SCP_CHARGES = BashOperator(task_id='CDE00_M_X_CDE_SCP_CHARGES' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_CDE_SCP_CHARGES')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_CDE_SCP_CHARGES.py NWB CDE00_M_X_CDE_SCP_CHARGES CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE00_M_X_TBBPROA_PROBE_OA = BashOperator(task_id='CDE00_M_X_TBBPROA_PROBE_OA' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_TBBPROA_PROBE_OA')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_TBBPROA_PROBE_OA.py NWB CDE00_M_X_TBBPROA_PROBE_OA CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE00_M_X_TBBUNPA_EVENT_ACM = BashOperator(task_id='CDE00_M_X_TBBUNPA_EVENT_ACM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_TBBUNPA_EVENT_ACM')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_TBBUNPA_EVENT_ACM.py NWB CDE00_M_X_TBBUNPA_EVENT_ACM CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE00_M_X_TBRCAMN_CAM_NV_AUD = BashOperator(task_id='CDE00_M_X_TBRCAMN_CAM_NV_AUD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_TBRCAMN_CAM_NV_AUD')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_TBRCAMN_CAM_NV_AUD.py NWB CDE00_M_X_TBRCAMN_CAM_NV_AUD CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE00_M_X_TDBACEL_AC_ELEMENT = BashOperator(task_id='CDE00_M_X_TDBACEL_AC_ELEMENT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE00_M_X_TDBACEL_AC_ELEMENT')+" "+cmd_part+"\" "+JOB_PATH+"CDE00_M_X_TDBACEL_AC_ELEMENT.py NWB CDE00_M_X_TDBACEL_AC_ELEMENT CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_ACCOUNT_ELEMENTS = BashOperator(task_id='CDE01_M_X_ACCOUNT_ELEMENTS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_ACCOUNT_ELEMENTS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_ACCOUNT_ELEMENTS.py NWB CDE01_M_X_ACCOUNT_ELEMENTS CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_APPLICATION_FULLEX = BashOperator(task_id='CDE01_M_X_APPLICATION_FULLEX' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_APPLICATION_FULLEX')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_APPLICATION_FULLEX.py NWB CDE01_M_X_APPLICATION_FULLEX CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_AUTO_TRANSFER_FULLEX = BashOperator(task_id='CDE01_M_X_AUTO_TRANSFER_FULLEX' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_AUTO_TRANSFER_FULLEX')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_AUTO_TRANSFER_FULLEX.py NWB CDE01_M_X_AUTO_TRANSFER_FULLEX CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_BRANCH_ACCOUNT = BashOperator(task_id='CDE01_M_X_BRANCH_ACCOUNT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_BRANCH_ACCOUNT')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_BRANCH_ACCOUNT.py NWB CDE01_M_X_BRANCH_ACCOUNT CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_CARD_TYPE_FULLEX = BashOperator(task_id='CDE01_M_X_CARD_TYPE_FULLEX' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CARD_TYPE_FULLEX')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CARD_TYPE_FULLEX.py NWB CDE01_M_X_CARD_TYPE_FULLEX CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_CA_MORTGAGE = BashOperator(task_id='CDE01_M_X_CA_MORTGAGE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CA_MORTGAGE')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CA_MORTGAGE.py NWB CDE01_M_X_CA_MORTGAGE CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_CUST_DUAL_FULLEX = BashOperator(task_id='CDE01_M_X_CUST_DUAL_FULLEX' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CUST_DUAL_FULLEX')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CUST_DUAL_FULLEX.py NWB CDE01_M_X_CUST_DUAL_FULLEX CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_CUST_PRIOR_FULLEX_MB = BashOperator(task_id='CDE01_M_X_CUST_PRIOR_FULLEX_MB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CUST_PRIOR_FULLEX_MB')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CUST_PRIOR_FULLEX_MB.py NWB CDE01_M_X_CUST_PRIOR_FULLEX_MB CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_CUST_PRIOR_FULLEX_PC = BashOperator(task_id='CDE01_M_X_CUST_PRIOR_FULLEX_PC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CUST_PRIOR_FULLEX_PC')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CUST_PRIOR_FULLEX_PC.py NWB CDE01_M_X_CUST_PRIOR_FULLEX_PC CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_CUST_PRIOR_R_FULLEX_PAL = BashOperator(task_id='CDE01_M_X_CUST_PRIOR_R_FULLEX_PAL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CUST_PRIOR_R_FULLEX_PAL')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CUST_PRIOR_R_FULLEX_PAL.py NWB CDE01_M_X_CUST_PRIOR_R_FULLEX_PAL CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_CUST_UNRANKED_PC = BashOperator(task_id='CDE01_M_X_CUST_UNRANKED_PC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CUST_UNRANKED_PC')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CUST_UNRANKED_PC.py NWB CDE01_M_X_CUST_UNRANKED_PC CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_EID_1_AGG = BashOperator(task_id='CDE01_M_X_EID_1_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_EID_1_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_EID_1_AGG.py NWB CDE01_M_X_EID_1_AGG CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_EID_2_AGG = BashOperator(task_id='CDE01_M_X_EID_2_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_EID_2_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_EID_2_AGG.py NWB CDE01_M_X_EID_2_AGG CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_EID_3_AGG = BashOperator(task_id='CDE01_M_X_EID_3_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_EID_3_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_EID_3_AGG.py NWB CDE01_M_X_EID_3_AGG CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_EID_4_AGG = BashOperator(task_id='CDE01_M_X_EID_4_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_EID_4_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_EID_4_AGG.py NWB CDE01_M_X_EID_4_AGG CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_Load_Full_Extract = BashOperator(task_id='CDE01_M_X_Load_Full_Extract' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_Load_Full_Extract')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_LOAD_FULL_EXTRACT.py NWB CDE01_M_X_LOAD_FULL_EXTRACT CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_REF_COLL_AGG = BashOperator(task_id='CDE01_M_X_REF_COLL_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_REF_COLL_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_REF_COLL_AGG.py NWB CDE01_M_X_REF_COLL_AGG CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_RELATED_ACCOUNTS_BA = BashOperator(task_id='CDE01_M_X_RELATED_ACCOUNTS_BA' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_RELATED_ACCOUNTS_BA')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_RELATED_ACCOUNTS_BA.py NWB CDE01_M_X_RELATED_ACCOUNTS_BA CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_RELATED_ACCOUNTS_CA = BashOperator(task_id='CDE01_M_X_RELATED_ACCOUNTS_CA' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_RELATED_ACCOUNTS_CA')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_RELATED_ACCOUNTS_CA.py NWB CDE01_M_X_RELATED_ACCOUNTS_CA CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_RELATED_ACCOUNTS_COMB = BashOperator(task_id='CDE01_M_X_RELATED_ACCOUNTS_COMB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_RELATED_ACCOUNTS_COMB')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_RELATED_ACCOUNTS_COMB.py NWB CDE01_M_X_RELATED_ACCOUNTS_COMB CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_RELATED_ACCOUNTS_LA = BashOperator(task_id='CDE01_M_X_RELATED_ACCOUNTS_LA' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_RELATED_ACCOUNTS_LA')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_RELATED_ACCOUNTS_LA.py NWB CDE01_M_X_RELATED_ACCOUNTS_LA CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_RELATED_ACCOUNTS_MA = BashOperator(task_id='CDE01_M_X_RELATED_ACCOUNTS_MA' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_RELATED_ACCOUNTS_MA')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_RELATED_ACCOUNTS_MA.py NWB CDE01_M_X_RELATED_ACCOUNTS_MA CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_RELATED_ACCOUNTS_SA = BashOperator(task_id='CDE01_M_X_RELATED_ACCOUNTS_SA' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_RELATED_ACCOUNTS_SA')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_RELATED_ACCOUNTS_SA.py NWB CDE01_M_X_RELATED_ACCOUNTS_SA CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_SCP_CHARGES_AGG = BashOperator(task_id='CDE01_M_X_SCP_CHARGES_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_SCP_CHARGES_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_SCP_CHARGES_AGG.py NWB CDE01_M_X_SCP_CHARGES_AGG CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE01_M_X_UNPAID_REFERS = BashOperator(task_id='CDE01_M_X_UNPAID_REFERS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_UNPAID_REFERS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_UNPAID_REFERS.py NWB CDE01_M_X_UNPAID_REFERS CDE01_M_N_FULLEX_FLOW -y,", dag=dag)
CDE00_M_X_TDBACEL_AC_ELEMENT.set_downstream(CDE01_M_X_ACCOUNT_ELEMENTS)
CDE00_M_X_CDE_APPLICATION.set_downstream(CDE01_M_X_APPLICATION_FULLEX)
CDE00_M_X_TBBPROA_PROBE_OA.set_downstream(CDE01_M_X_CA_MORTGAGE)
CDE00_M_X_TBRCAMN_CAM_NV_AUD.set_downstream(CDE01_M_X_CA_MORTGAGE)
CDE01_M_X_ACCOUNT_ELEMENTS.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_EID_1_AGG.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_EID_2_AGG.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_EID_3_AGG.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_SCP_CHARGES_AGG.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_UNPAID_REFERS.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_RELATED_ACCOUNTS_MA.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_RELATED_ACCOUNTS_LA.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_RELATED_ACCOUNTS_COMB.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_RELATED_ACCOUNTS_CA.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_RELATED_ACCOUNTS_BA.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_EID_4_AGG.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_CUST_UNRANKED_PC.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_CUST_PRIOR_R_FULLEX_PAL.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_CUST_PRIOR_FULLEX_PC.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_CUST_PRIOR_FULLEX_MB.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_CUST_DUAL_FULLEX.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_CARD_TYPE_FULLEX.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_CA_MORTGAGE.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_BRANCH_ACCOUNT.set_downstream(CDE01_M_X_Load_Full_Extract)
#	CDE_M_N_AUTO_TRANSFER_DATA_LOAD.set_downstream(CDE01_M_X_AUTO_TRANSFER_FULLEX)
CDE01_M_X_AUTO_TRANSFER_FULLEX.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE01_M_X_APPLICATION_FULLEX.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE00_M_X_CDE_PRE_EMP_COLL.set_downstream(CDE01_M_X_Load_Full_Extract)
CDE00_M_X_CDE_REF_COLL.set_downstream(CDE01_M_X_REF_COLL_AGG)
CDE01_M_X_RELATED_ACCOUNTS_SA.set_downstream(CDE01_M_X_RELATED_ACCOUNTS_BA)
CDE01_M_X_RELATED_ACCOUNTS_SA.set_downstream(CDE01_M_X_RELATED_ACCOUNTS_CA)
CDE01_M_X_RELATED_ACCOUNTS_SA.set_downstream(CDE01_M_X_RELATED_ACCOUNTS_COMB)
CDE01_M_X_RELATED_ACCOUNTS_SA.set_downstream(CDE01_M_X_RELATED_ACCOUNTS_LA)
CDE01_M_X_RELATED_ACCOUNTS_SA.set_downstream(CDE01_M_X_RELATED_ACCOUNTS_MA)
#CDE00_M_X_ACCOUNT_HISTORY.set_downstream(CDE01_M_X_RELATED_ACCOUNTS_SA)
CDE00_M_X_ACCOUNT_MASTER.set_downstream(CDE01_M_X_RELATED_ACCOUNTS_SA)
CDE00_M_X_CDE_SCP_CHARGES.set_downstream(CDE01_M_X_SCP_CHARGES_AGG)
CDE01_M_X_REF_COLL_AGG.set_downstream(CDE01_M_X_UNPAID_REFERS)
CDE00_M_X_TBBUNPA_EVENT_ACM.set_downstream(CDE01_M_X_UNPAID_REFERS)
CDE00_M_X_TDBACEL_AC_ELEMENT.set_downstream(CDE01_M_X_UNPAID_REFERS)
CDE00_M_X_TBBPROA_PROBE_OA.set_downstream(CDE01_M_X_UNPAID_REFERS)

#CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE00_M_X_ACCOUNT_HISTORY)
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE00_M_X_ACCOUNT_MASTER) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE00_M_X_CDE_APPLICATION) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE00_M_X_CDE_PRE_EMP_COLL) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE00_M_X_CDE_REF_COLL) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE00_M_X_CDE_SCP_CHARGES)
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE00_M_X_TBBPROA_PROBE_OA) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE00_M_X_TBBUNPA_EVENT_ACM) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE00_M_X_TBRCAMN_CAM_NV_AUD) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE00_M_X_TDBACEL_AC_ELEMENT) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_AUTO_TRANSFER_FULLEX) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_BRANCH_ACCOUNT) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_CARD_TYPE_FULLEX) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_CUST_DUAL_FULLEX) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_CUST_PRIOR_FULLEX_MB) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_CUST_PRIOR_FULLEX_PC) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_CUST_PRIOR_R_FULLEX_PAL)
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_CUST_UNRANKED_PC) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_EID_1_AGG) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_EID_2_AGG) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_EID_3_AGG) 
CDE01_M_N_FULLEX_FLOW_Start.set_downstream(CDE01_M_X_EID_4_AGG) 

CDE01_M_X_Load_Full_Extract.set_downstream(CDE01_M_N_FULLEX_FLOW_End) 

#CDE01_M_N_PROBE_DERVS_FLOW
CDE01_M_X_PROBE_DERVS_FLOW = BashOperator(task_id='CDE01_M_X_PROBE_DERVS_FLOW' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ BASE_PATH+script_loc+script_name+" "+JOB_PATH+" NWB CDE01_M_N_PROBE_DERVS_FLOW "+BASE_PATH+script_loc+"CDE01_M_PROBE_DERVS_FLOW.ini"+" " +TRANSFORMATION_LOC+" "+CDE_CONTROL+" -y,", dag=dag)


#CDE01_D_G_PROBE_DERIVATIONS_01 = BashOperator(task_id='CDE01_D_G_PROBE_DERIVATIONS_01' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_PROBE_DERIVATIONS_01')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_PROBE_DERIVATIONS_01.py NWB CDE01_D_G_PROBE_DERIVATIONS_01 CDE01_M_N_PROBE_DERVS_FLOW -y,", dag=dag)
#CDE01_D_G_PROBE_DERIVATIONS_02 = BashOperator(task_id='CDE01_D_G_PROBE_DERIVATIONS_02' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_PROBE_DERIVATIONS_02')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_PROBE_DERIVATIONS_02.py NWB CDE01_D_G_PROBE_DERIVATIONS_02 CDE01_M_N_PROBE_DERVS_FLOW -y,", dag=dag)
#CDE01_D_G_PROBE_DERIVATIONS_03 = BashOperator(task_id='CDE01_D_G_PROBE_DERIVATIONS_03' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_PROBE_DERIVATIONS_03')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_PROBE_DERIVATIONS_03.py NWB CDE01_D_G_PROBE_DERIVATIONS_03 CDE01_M_N_PROBE_DERVS_FLOW -y,", dag=dag)
#CDE01_D_G_PROBE_DERIVATIONS_04 = BashOperator(task_id='CDE01_D_G_PROBE_DERIVATIONS_04' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_PROBE_DERIVATIONS_04')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_PROBE_DERIVATIONS_04.py NWB CDE01_D_G_PROBE_DERIVATIONS_04 CDE01_M_N_PROBE_DERVS_FLOW -y,", dag=dag)
#CDE01_M_G_PROBE_DERIVATIONS_00 = BashOperator(task_id='CDE01_M_G_PROBE_DERIVATIONS_00' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_PROBE_DERIVATIONS_00')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_PROBE_DERIVATIONS_00.py NWB CDE01_M_G_PROBE_DERIVATIONS_00 CDE01_M_N_PROBE_DERVS_FLOW -y,", dag=dag)
#CDE01_M_G_PROBE_DERIVATIONS_09 = BashOperator(task_id='CDE01_M_G_PROBE_DERIVATIONS_09' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_PROBE_DERIVATIONS_09')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_PROBE_DERIVATIONS_09.py NWB CDE01_M_G_PROBE_DERIVATIONS_09 CDE01_M_N_PROBE_DERVS_FLOW -y,", dag=dag)
#CDE01_D_G_PROBE_DERIVATIONS_10 = BashOperator(task_id='CDE01_D_G_PROBE_DERIVATIONS_10' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_PROBE_DERIVATIONS_10')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_PROBE_DERIVATIONS_10.py NWB CDE01_D_G_PROBE_DERIVATIONS_10 CDE01_M_N_PROBE_DERVS_FLOW -y,", dag=dag)
#
#CDE01_M_G_PROBE_DERIVATIONS_00.set_downstream(CDE01_D_G_PROBE_DERIVATIONS_01)
#CDE01_D_G_PROBE_DERIVATIONS_01.set_downstream(CDE01_D_G_PROBE_DERIVATIONS_02)
#CDE01_D_G_PROBE_DERIVATIONS_02.set_downstream(CDE01_D_G_PROBE_DERIVATIONS_03)
#CDE01_D_G_PROBE_DERIVATIONS_03.set_downstream(CDE01_D_G_PROBE_DERIVATIONS_04)
#CDE01_D_G_PROBE_DERIVATIONS_04.set_downstream(CDE01_M_G_PROBE_DERIVATIONS_09)
#CDE01_M_G_PROBE_DERIVATIONS_09.set_downstream(CDE01_D_G_PROBE_DERIVATIONS_10)
#
#CDE01_M_N_FULLEX_FLOW_End.set_downstream(CDE01_M_G_PROBE_DERIVATIONS_00) 
#CDE01_M_X_DB_TRANS_FLAG_AGG.set_downstream(CDE01_M_G_PROBE_DERIVATIONS_00)
#CDE01_M_X_TRANS_FLAG_AGG.set_downstream(CDE01_M_G_PROBE_DERIVATIONS_00)
#CDE01_M_X_INC_CALC.set_downstream(CDE01_M_G_PROBE_DERIVATIONS_00)
CDE01_M_N_FULLEX_FLOW_End.set_downstream(CDE01_M_X_PROBE_DERVS_FLOW) 
CDE01_M_X_DB_TRANS_FLAG_AGG.set_downstream(CDE01_M_X_PROBE_DERVS_FLOW)
CDE01_M_X_TRANS_FLAG_AGG.set_downstream(CDE01_M_X_PROBE_DERVS_FLOW)
CDE01_M_X_INC_CALC.set_downstream(CDE01_M_X_PROBE_DERVS_FLOW)

#CDE01_M_N_CUST_EXTRACTS_FLOW 
#### Commenting Cust extracts job and handling dependency via Inter Dag dependency  ####

CDE01_M_X_ALL_PRDT_WOFFS = BashOperator(task_id='CDE01_M_X_ALL_PRDT_WOFFS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_ALL_PRDT_WOFFS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_ALL_PRDT_WOFFS.py NWB CDE01_M_X_ALL_PRDT_WOFFS CDE01_M_N_CUST_EXTRACTS_FLOW -y,", dag=dag)
###CDE01_M_X_CUST_EXTRACTS_CHECK = BashOperator(task_id='CDE01_M_X_CUST_EXTRACTS_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CUST_EXTRACTS_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CUST_EXTRACTS_CHECK.py NWB CDE01_M_X_CUST_EXTRACTS_CHECK CDE01_M_N_CUST_EXTRACTS_FLOW -y,", dag=dag)
CDE01_M_X_DB_TRANS_CUST_AGG = BashOperator(task_id='CDE01_M_X_DB_TRANS_CUST_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_DB_TRANS_CUST_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_DB_TRANS_CUST_AGG.py NWB CDE01_M_X_DB_TRANS_CUST_AGG CDE01_M_N_CUST_EXTRACTS_FLOW -y,", dag=dag)
#CDER-5685
DEPENDENCY_CHECK_D_G_GURN_MASTER= BashOperator(task_id='DEPENDENCY_CHECK_D_G_GURN_MASTER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+FLOW_DEPENDENCY+" CDE99_D_G_GURN_MASTER_FLOW "+get_polling_time('CDE99_D_G_GURN_MASTER_FLOW')+" -y,", dag=dag)
##DEPENDENCY_CHECK_D_G_GURN_MASTER.set_downstream(CDE01_M_X_CUST_EXTRACTS_CHECK)
##CDE01_M_X_CUST_EXTRACTS_CHECK.set_downstream(CDE01_M_X_ALL_PRDT_WOFFS)
##CDE01_M_X_CUST_EXTRACTS_CHECK.set_downstream(CDE01_M_X_DB_TRANS_CUST_AGG)
DEPENDENCY_CHECK_M_G_PAL_P1_DAY1_EXTRACT= BashOperator(task_id='DEPENDENCY_CHECK_M_G_PAL_P1_DAY1_EXTRACT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE06_M_G_PAL_P1_Day1_EXTRACT "+get_polling_time('CDE06_M_G_PAL_P1_Day1_EXTRACT')+" -y,", dag=dag)
DEPENDENCY_CHECK_D_G_PAL_P1_Day0_Extract= BashOperator(task_id='DEPENDENCY_CHECK_D_G_PAL_P1_Day0_Extract' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE06_D_G_PAL_P1_Day0_Extract  "+get_polling_time('CDE06_D_G_PAL_P1_Day0_Extract')+" -y,", dag=dag)
DEPENDENCY_CHECK_D_N_PAL_P1_Day0_Extract= BashOperator(task_id='DEPENDENCY_CHECK_D_N_PAL_P1_Day0_Extract' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE06_D_N_PAL_P1_Day0_Extract  "+get_polling_time('CDE06_D_N_PAL_P1_Day0_Extract')+" -y,", dag=dag)
DEPENDENCY_CHECK_D_G_GURN_MASTER.set_downstream(DEPENDENCY_CHECK_D_N_PAL_P1_Day0_Extract)
DEPENDENCY_CHECK_D_G_GURN_MASTER.set_downstream(DEPENDENCY_CHECK_D_G_PAL_P1_Day0_Extract)
DEPENDENCY_CHECK_D_N_PAL_P1_Day0_Extract.set_downstream(DEPENDENCY_CHECK_M_G_PAL_P1_DAY1_EXTRACT)
DEPENDENCY_CHECK_D_G_PAL_P1_Day0_Extract.set_downstream(DEPENDENCY_CHECK_M_G_PAL_P1_DAY1_EXTRACT)
DEPENDENCY_CHECK_M_G_PAL_P1_DAY1_EXTRACT.set_downstream(CDE01_M_X_ALL_PRDT_WOFFS)
DEPENDENCY_CHECK_M_G_PAL_P1_DAY1_EXTRACT.set_downstream(CDE01_M_X_DB_TRANS_CUST_AGG)

#CDE01_D_G_PROBE_DERIVATIONS_10.set_downstream(DEPENDENCY_CHECK_D_G_GURN_MASTER)
CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(DEPENDENCY_CHECK_D_G_GURN_MASTER)

#CDE01_M_N_POPULATIONS_FLOW 

CDE01_M_X_POPULATION_BUS_RP = BashOperator(task_id='CDE01_M_X_POPULATION_BUS_RP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_POPULATION_BUS_RP')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_POPULATION_BUS_RP.py NWB CDE01_M_X_POPULATION_BUS_RP CDE01_M_N_POPULATIONS_FLOW -y,", dag=dag)
CDE01_M_X_POPULATION_BUS = BashOperator(task_id='CDE01_M_X_POPULATION_BUS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_POPULATION_BUS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_POPULATION_BUS.py NWB CDE01_M_X_POPULATION_BUS CDE01_M_N_POPULATIONS_FLOW -y,", dag=dag)
CDE01_M_X_POPULATION_PER = BashOperator(task_id='CDE01_M_X_POPULATION_PER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_POPULATION_PER')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_POPULATION_PER.py NWB CDE01_M_X_POPULATION_PER CDE01_M_N_POPULATIONS_FLOW -y,", dag=dag)
CDE01_M_X_POPULATION_BUS.set_downstream(CDE01_M_X_POPULATION_BUS_RP)

#CDE01_D_G_PROBE_DERIVATIONS_10.set_downstream(CDE01_M_X_POPULATION_BUS)
#CDE01_D_G_PROBE_DERIVATIONS_10.set_downstream(CDE01_M_X_POPULATION_PER)
CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(CDE01_M_X_POPULATION_BUS)
CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(CDE01_M_X_POPULATION_PER)

#CDE01_M_N_ACCUM_RESETS_FLOW 

CDE01_M_X_CAUSTIC_ACTIVE = BashOperator(task_id='CDE01_M_X_CAUSTIC_ACTIVE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CAUSTIC_ACTIVE')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CAUSTIC_ACTIVE.py NWB CDE01_M_X_CAUSTIC_ACTIVE CDE01_M_N_ACCUM_RESETS_FLOW -y,", dag=dag)
CDE01_M_X_CAUSTIC_CLOSED = BashOperator(task_id='CDE01_M_X_CAUSTIC_CLOSED' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CAUSTIC_CLOSED')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CAUSTIC_CLOSED.py NWB CDE01_M_X_CAUSTIC_CLOSED CDE01_M_N_ACCUM_RESETS_FLOW -y,", dag=dag)
CDE01_M_X_CAUSTIC_MERGE = BashOperator(task_id='CDE01_M_X_CAUSTIC_MERGE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CAUSTIC_MERGE')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CAUSTIC_MERGE.py NWB CDE01_M_X_CAUSTIC_MERGE CDE01_M_N_ACCUM_RESETS_FLOW -y,", dag=dag)
CDE01_M_X_HIREP_ACTIVE = BashOperator(task_id='CDE01_M_X_HIREP_ACTIVE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_HIREP_ACTIVE')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_HIREP_ACTIVE.py NWB CDE01_M_X_HIREP_ACTIVE CDE01_M_N_ACCUM_RESETS_FLOW -y,", dag=dag)
CDE01_M_X_HIREP_CLOSED = BashOperator(task_id='CDE01_M_X_HIREP_CLOSED' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_HIREP_CLOSED')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_HIREP_CLOSED.py NWB CDE01_M_X_HIREP_CLOSED CDE01_M_N_ACCUM_RESETS_FLOW -y,", dag=dag)
CDE01_M_X_HIREP_MERGE = BashOperator(task_id='CDE01_M_X_HIREP_MERGE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_HIREP_MERGE')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_HIREP_MERGE.py NWB CDE01_M_X_HIREP_MERGE CDE01_M_N_ACCUM_RESETS_FLOW -y,", dag=dag)
CDE01_M_X_CAUSTIC_ACTIVE.set_downstream(CDE01_M_X_CAUSTIC_MERGE)
CDE01_M_X_CAUSTIC_CLOSED.set_downstream(CDE01_M_X_CAUSTIC_MERGE)
CDE01_M_X_HIREP_ACTIVE.set_downstream(CDE01_M_X_HIREP_MERGE)
CDE01_M_X_HIREP_CLOSED.set_downstream(CDE01_M_X_HIREP_MERGE)

#CDE01_D_G_PROBE_DERIVATIONS_10.set_downstream(CDE01_M_X_CAUSTIC_ACTIVE)
#CDE01_D_G_PROBE_DERIVATIONS_10.set_downstream(CDE01_M_X_CAUSTIC_CLOSED)
#CDE01_D_G_PROBE_DERIVATIONS_10.set_downstream(CDE01_M_X_HIREP_ACTIVE)
#CDE01_D_G_PROBE_DERIVATIONS_10.set_downstream(CDE01_M_X_HIREP_CLOSED)
CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(CDE01_M_X_CAUSTIC_ACTIVE)
CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(CDE01_M_X_CAUSTIC_CLOSED)
CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(CDE01_M_X_HIREP_ACTIVE)
CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(CDE01_M_X_HIREP_CLOSED)


#CDE02_M_N_BUS_SCR_AND_LIM_FLOW 

CDE02_M_X_BEH_SCORE_BUS = BashOperator(task_id='CDE02_M_X_BEH_SCORE_BUS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_X_BEH_SCORE_BUS')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_X_BEH_SCORE_BUS.py NWB CDE02_M_X_BEH_SCORE_BUS CDE02_M_N_BUS_SCR_AND_LIM_FLOW -y,", dag=dag)
CDE02_M_X_BUS_ACCT_LIMITS = BashOperator(task_id='CDE02_M_X_BUS_ACCT_LIMITS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_X_BUS_ACCT_LIMITS')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_X_BUS_ACCT_LIMITS.py NWB CDE02_M_X_BUS_ACCT_LIMITS CDE02_M_N_BUS_SCR_AND_LIM_FLOW -y,", dag=dag)
CDE02_M_X_BEH_SCORE_BUS.set_downstream(CDE02_M_X_BUS_ACCT_LIMITS)

#CDE01_D_G_PROBE_DERIVATIONS_10.set_downstream(CDE02_M_X_BEH_SCORE_BUS)
CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(CDE02_M_X_BEH_SCORE_BUS)

CDE02_M_C_BASEL_BEH_SCORE_BUS = BashOperator(task_id='CDE02_M_C_BASEL_BEH_SCORE_BUS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BASEL_BEH_SCORE_BUS')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BASEL_BEH_SCORE_BUS.py NWB CDE02_M_C_BASEL_BEH_SCORE_BUS CDE02_M_N_BUS_SCR_AND_LIM_FLOW -y,", dag=dag)

CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(CDE02_M_C_BASEL_BEH_SCORE_BUS)

#CDE02_M_N_BEH_SCORE_FLOW 

CDE02_M_C_BEH_SC011 = BashOperator(task_id='CDE02_M_C_BEH_SC011' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC011')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC011.py NWB CDE02_M_C_BEH_SC011 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC017 = BashOperator(task_id='CDE02_M_C_BEH_SC017' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC017')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC017.py NWB CDE02_M_C_BEH_SC017 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC018 = BashOperator(task_id='CDE02_M_C_BEH_SC018' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC018')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC018.py NWB CDE02_M_C_BEH_SC018 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC214 = BashOperator(task_id='CDE02_M_C_BEH_SC214' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC214')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC214.py NWB CDE02_M_C_BEH_SC214 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC814 = BashOperator(task_id='CDE02_M_C_BEH_SC814' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC814')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC814.py NWB CDE02_M_C_BEH_SC814 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC020 = BashOperator(task_id='CDE02_M_C_BEH_SC020' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC020')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC020.py NWB CDE02_M_C_BEH_SC020 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC300 = BashOperator(task_id='CDE02_M_C_BEH_SC300' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC300')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC300.py NWB CDE02_M_C_BEH_SC300 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC401 = BashOperator(task_id='CDE02_M_C_BEH_SC401' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC401')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC401.py NWB CDE02_M_C_BEH_SC401 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC402 = BashOperator(task_id='CDE02_M_C_BEH_SC402' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC402')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC402.py NWB CDE02_M_C_BEH_SC402 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC403 = BashOperator(task_id='CDE02_M_C_BEH_SC403' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC403')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC403.py NWB CDE02_M_C_BEH_SC403 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC404 = BashOperator(task_id='CDE02_M_C_BEH_SC404' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC404')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC404.py NWB CDE02_M_C_BEH_SC404 CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_CUTDOWN = BashOperator(task_id='CDE02_M_C_BEH_CUTDOWN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_CUTDOWN')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_CUTDOWN.py NWB CDE02_M_C_BEH_CUTDOWN CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_OUTPUT = BashOperator(task_id='CDE02_M_C_BEH_OUTPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_OUTPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_OUTPUT.py NWB CDE02_M_C_BEH_OUTPUT CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_POSTJOB = BashOperator(task_id='CDE02_M_C_BEH_POSTJOB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_POSTJOB')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_POSTJOB.py NWB CDE02_M_C_BEH_POSTJOB CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)
CDE02_M_C_BEH_SC_Alct = BashOperator(task_id='CDE02_M_C_BEH_SC_Alct' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_BEH_SC_Alct')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_BEH_SC_ALCT.py NWB CDE02_M_C_BEH_SC_ALCT CDE02_M_N_BEH_SCORE_FLOW -y,", dag=dag)

CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC011)
CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC017)
CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC018)
CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC214)
CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC814)
CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC020)
CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC300)
CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC401)
CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC402)
CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC403)
CDE02_M_C_BEH_SC_Alct.set_downstream(CDE02_M_C_BEH_SC404)
CDE02_M_C_BEH_SC011.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_SC017.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_SC018.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_SC020.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_SC300.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_SC401.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_SC402.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_SC403.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_SC404.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_SC214.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_SC814.set_downstream(CDE02_M_C_BEH_OUTPUT)
CDE02_M_C_BEH_OUTPUT.set_downstream(CDE02_M_C_BEH_POSTJOB)
CDE02_M_C_BEH_CUTDOWN.set_downstream(CDE02_M_C_BEH_SC_Alct)

#CDE01_D_G_PROBE_DERIVATIONS_10.set_downstream(CDE02_M_C_BEH_CUTDOWN)
CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(CDE02_M_C_BEH_CUTDOWN)

#CDE01_M_N_CUST_MASTER_PER_FLOW

CDE01_M_X_CUST_AFFORDABILITY = BashOperator(task_id='CDE01_M_X_CUST_AFFORDABILITY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CUST_AFFORDABILITY')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CUST_AFFORDABILITY.py NWB CDE01_M_X_CUST_AFFORDABILITY CDE01_M_N_CUST_MASTER_PER_FLOW -y,", dag=dag)
CDE01_M_X_CUST_DERIVATIONS = BashOperator(task_id='CDE01_M_X_CUST_DERIVATIONS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_CUST_DERIVATIONS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_CUST_DERIVATIONS.py NWB CDE01_M_X_CUST_DERIVATIONS CDE01_M_N_CUST_MASTER_PER_FLOW -y,", dag=dag)
CDE01_M_X_CUST_DERIVATIONS.set_downstream(CDE01_M_X_CUST_AFFORDABILITY)

CDE01_M_X_POPULATION_BUS_RP.set_downstream(CDE01_M_X_CUST_DERIVATIONS)
CDE01_M_X_POPULATION_PER.set_downstream(CDE01_M_X_CUST_DERIVATIONS)
CDE01_M_X_ALL_PRDT_WOFFS.set_downstream(CDE01_M_X_CUST_DERIVATIONS)
CDE01_M_X_DB_TRANS_CUST_AGG.set_downstream(CDE01_M_X_CUST_DERIVATIONS)



#CDE01_M_N_CUST_ACC_PRIOR_FLOW 


CDE01_M_X_PRIORITISED_DERVS = BashOperator(task_id='CDE01_M_X_PRIORITISED_DERVS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PRIORITISED_DERVS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PRIORITISED_DERVS.py NWB CDE01_M_X_PRIORITISED_DERVS CDE01_M_N_CUST_ACC_PRIOR_FLOW -y,", dag=dag)

CDE01_M_X_CUST_AFFORDABILITY.set_downstream(CDE01_M_X_PRIORITISED_DERVS)


#CDE02_M_N_CDE_SCORE_FLOW 
CDE02_M_X_CDE_SCORE_FLOW  = BashOperator(task_id='CDE02_M_X_CDE_SCORE_FLOW' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ BASE_PATH+script_loc+script_name+" "+JOB_PATH+" NWB CDE02_M_N_CDE_SCORE_FLOW  "+BASE_PATH+script_loc+"CDE02_M_N_CDE_SCORE_FLOW.ini"+" " +TRANSFORMATION_LOC+" "+CDE_CONTROL+" -y,", dag=dag)

#CDE02_M_C_CDE_CUTDOWN = BashOperator(task_id='CDE02_M_C_CDE_CUTDOWN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_CDE_CUTDOWN')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_CDE_CUTDOWN.py NWB CDE02_M_C_CDE_CUTDOWN CDE02_M_N_CDE_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_CDE_POSTJOB = BashOperator(task_id='CDE02_M_C_CDE_POSTJOB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_CDE_POSTJOB')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_CDE_POSTJOB.py NWB CDE02_M_C_CDE_POSTJOB CDE02_M_N_CDE_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_CDE_SC701 = BashOperator(task_id='CDE02_M_C_CDE_SC701' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_CDE_SC701')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_CDE_SC701.py NWB CDE02_M_C_CDE_SC701 CDE02_M_N_CDE_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_CDE_SC702 = BashOperator(task_id='CDE02_M_C_CDE_SC702' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_CDE_SC702')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_CDE_SC702.py NWB CDE02_M_C_CDE_SC702 CDE02_M_N_CDE_SCORE_FLOW -y,", dag=dag)
#CDE02_M_N_CDE_SC_ALCT = BashOperator(task_id='CDE02_M_N_CDE_SC_ALCT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_N_CDE_SC_ALCT')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_N_CDE_SC_ALCT.py NWB CDE02_M_N_CDE_SC_ALCT CDE02_M_N_CDE_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_CDE_SC_OUTPUT = BashOperator(task_id='CDE02_M_C_CDE_SC_OUTPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_CDE_SC_OUTPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_CDE_SC_OUTPUT.py NWB CDE02_M_C_CDE_SC_OUTPUT CDE02_M_N_CDE_SCORE_FLOW -y,", dag=dag)
#
#CDE02_M_N_CDE_SC_ALCT.set_downstream(CDE02_M_C_CDE_SC701)
#CDE02_M_N_CDE_SC_ALCT.set_downstream(CDE02_M_C_CDE_SC702)
#CDE02_M_C_CDE_CUTDOWN.set_downstream(CDE02_M_N_CDE_SC_ALCT)
#CDE02_M_C_CDE_SC701.set_downstream(CDE02_M_C_CDE_SC_OUTPUT)
#CDE02_M_C_CDE_SC702.set_downstream(CDE02_M_C_CDE_SC_OUTPUT)
#CDE02_M_C_CDE_SC_OUTPUT.set_downstream(CDE02_M_C_CDE_POSTJOB)
#
#CDE01_M_X_PRIORITISED_DERVS.set_downstream(CDE02_M_C_CDE_CUTDOWN)
#CDE02_M_C_BEH_POSTJOB.set_downstream(CDE02_M_C_CDE_CUTDOWN)
CDE01_M_X_PRIORITISED_DERVS.set_downstream(CDE02_M_X_CDE_SCORE_FLOW)
CDE02_M_C_BEH_POSTJOB.set_downstream(CDE02_M_X_CDE_SCORE_FLOW)

#CDE02_M_C_EAR_SCORE_FLOW 
CDE02_M_X_EAR_SCORE_FLOW  = BashOperator(task_id='CDE02_M_X_EAR_SCORE_FLOW' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ BASE_PATH+script_loc+script_name+" "+JOB_PATH+" NWB CDE02_M_N_EAR_SCORE_FLOW  "+BASE_PATH+script_loc+"CDE02_M_EAR_SCORE_FLOW.ini"+" " +TRANSFORMATION_LOC+" "+CDE_CONTROL+" -y,", dag=dag)

#CDE02_M_C_EAR_CUTDOWN = BashOperator(task_id='CDE02_M_C_EAR_CUTDOWN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_EAR_CUTDOWN')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_EAR_CUTDOWN.py NWB CDE02_M_C_EAR_CUTDOWN CDE02_M_N_EAR_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_EAR_Output = BashOperator(task_id='CDE02_M_C_EAR_Output' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_EAR_Output')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_EAR_OUTPUT.py NWB CDE02_M_C_EAR_OUTPUT CDE02_M_N_EAR_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_EAR_POSTJOB = BashOperator(task_id='CDE02_M_C_EAR_POSTJOB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_EAR_POSTJOB')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_EAR_POSTJOB.py NWB CDE02_M_C_EAR_POSTJOB CDE02_M_N_EAR_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_EAR_SC651 = BashOperator(task_id='CDE02_M_C_EAR_SC651' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_EAR_SC651')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_EAR_SC651.py NWB CDE02_M_C_EAR_SC651 CDE02_M_N_EAR_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_EAR_SC652 = BashOperator(task_id='CDE02_M_C_EAR_SC652' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_EAR_SC652')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_EAR_SC652.py NWB CDE02_M_C_EAR_SC652 CDE02_M_N_EAR_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_EAR_SC653 = BashOperator(task_id='CDE02_M_C_EAR_SC653' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_EAR_SC653')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_EAR_SC653.py NWB CDE02_M_C_EAR_SC653 CDE02_M_N_EAR_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_EAR_SC_Alct = BashOperator(task_id='CDE02_M_C_EAR_SC_Alct' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_EAR_SC_Alct')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_EAR_SC_ALCT.py NWB CDE02_M_C_EAR_SC_ALCT CDE02_M_N_EAR_SCORE_FLOW -y,", dag=dag)
#
#CDE02_M_C_EAR_SC651.set_downstream(CDE02_M_C_EAR_Output)
#CDE02_M_C_EAR_SC652.set_downstream(CDE02_M_C_EAR_Output)
#CDE02_M_C_EAR_SC653.set_downstream(CDE02_M_C_EAR_Output)
#CDE02_M_C_EAR_Output.set_downstream(CDE02_M_C_EAR_POSTJOB)
#CDE02_M_C_EAR_SC_Alct.set_downstream(CDE02_M_C_EAR_SC651)
#CDE02_M_C_EAR_SC_Alct.set_downstream(CDE02_M_C_EAR_SC652)
#CDE02_M_C_EAR_SC_Alct.set_downstream(CDE02_M_C_EAR_SC653)
#CDE02_M_C_EAR_CUTDOWN.set_downstream(CDE02_M_C_EAR_SC_Alct)
#
#CDE02_M_C_BEH_POSTJOB.set_downstream(CDE02_M_C_EAR_CUTDOWN)
CDE02_M_C_BEH_POSTJOB.set_downstream(CDE02_M_X_EAR_SCORE_FLOW)

#CDE02_M_N_INS_SCORE_FLOW 
CDE02_M_X_INS_SCORE_FLOW  = BashOperator(task_id='CDE02_M_X_INS_SCORE_FLOW' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ BASE_PATH+script_loc+script_name+" "+JOB_PATH+" NWB CDE02_M_N_INS_SCORE_FLOW  "+BASE_PATH+script_loc+"CDE02_M_INS_SCORE_FLOW.ini"+" " +TRANSFORMATION_LOC+" "+CDE_CONTROL+" -y,", dag=dag)
#CDE02_M_C_INS_CUTDOWN = BashOperator(task_id='CDE02_M_C_INS_CUTDOWN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_INS_CUTDOWN')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_INS_CUTDOWN.py NWB CDE02_M_C_INS_CUTDOWN CDE02_M_N_INS_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_INS_POSTJOB = BashOperator(task_id='CDE02_M_C_INS_POSTJOB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_INS_POSTJOB')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_INS_POSTJOB.py NWB CDE02_M_C_INS_POSTJOB CDE02_M_N_INS_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_INS_SC601 = BashOperator(task_id='CDE02_M_C_INS_SC601' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_INS_SC601')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_INS_SC601.py NWB CDE02_M_C_INS_SC601 CDE02_M_N_INS_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_INS_SC602 = BashOperator(task_id='CDE02_M_C_INS_SC602' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_INS_SC602')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_INS_SC602.py NWB CDE02_M_C_INS_SC602 CDE02_M_N_INS_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_INS_SC_Output = BashOperator(task_id='CDE02_M_C_INS_SC_Output' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_INS_SC_Output')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_INS_SC_OUTPUT.py NWB CDE02_M_C_INS_SC_OUTPUT CDE02_M_N_INS_SCORE_FLOW -y,", dag=dag)
#CDE02_M_C_INS_SC_alct = BashOperator(task_id='CDE02_M_C_INS_SC_alct' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_INS_SC_alct')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_INS_SC_ALCT.py NWB CDE02_M_C_INS_SC_ALCT CDE02_M_N_INS_SCORE_FLOW -y,", dag=dag)
#
#CDE02_M_C_INS_SC_Output.set_downstream(CDE02_M_C_INS_POSTJOB)
#CDE02_M_C_INS_SC_alct.set_downstream(CDE02_M_C_INS_SC601)
#CDE02_M_C_INS_SC_alct.set_downstream(CDE02_M_C_INS_SC602)
#CDE02_M_C_INS_SC601.set_downstream(CDE02_M_C_INS_SC_Output)
#CDE02_M_C_INS_SC602.set_downstream(CDE02_M_C_INS_SC_Output)
#CDE02_M_C_INS_CUTDOWN.set_downstream(CDE02_M_C_INS_SC_alct)
#
#CDE01_D_G_PROBE_DERIVATIONS_10.set_downstream(CDE02_M_C_INS_CUTDOWN)
CDE01_M_X_PROBE_DERVS_FLOW.set_downstream(CDE02_M_X_INS_SCORE_FLOW)

#CDE02_M_N_PROBE_CONS_FLOW 

#CDE01_M_X_ACCOUNT_POLICY = BashOperator(task_id='CDE01_M_X_ACCOUNT_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_ACCOUNT_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_ACCOUNT_POLICY.py NWB CDE01_M_X_ACCOUNT_POLICY CDE02_M_N_PROBE_CONS_FLOW -y,", dag=dag)
CDE02_M_C_PRSCOR_CONSOLIDATION = BashOperator(task_id='CDE02_M_C_PRSCOR_CONSOLIDATION' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_C_PRSCOR_CONSOLIDATION')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_C_PRSCOR_CONSOLIDATION.py NWB CDE02_M_C_PRSCOR_CONSOLIDATION CDE02_M_N_PROBE_CONS_FLOW -y,", dag=dag)
CDE02_M_C_PRSCOR_CONSOLIDATION.set_downstream(END)

#CDE02_M_C_INS_POSTJOB.set_downstream(CDE02_M_C_PRSCOR_CONSOLIDATION)
#CDE02_M_C_EAR_POSTJOB.set_downstream(CDE02_M_C_PRSCOR_CONSOLIDATION)
#CDE02_M_C_CDE_POSTJOB.set_downstream(CDE02_M_C_PRSCOR_CONSOLIDATION)
CDE02_M_X_INS_SCORE_FLOW.set_downstream(CDE02_M_C_PRSCOR_CONSOLIDATION)
CDE02_M_X_EAR_SCORE_FLOW.set_downstream(CDE02_M_C_PRSCOR_CONSOLIDATION)
CDE02_M_X_CDE_SCORE_FLOW.set_downstream(CDE02_M_C_PRSCOR_CONSOLIDATION)
#CDE01_M_X_ACCOUNT_POLICY.set_downstream(END)
CDE01_M_X_CAUSTIC_MERGE.set_downstream(END)
CDE02_M_X_BUS_ACCT_LIMITS.set_downstream(END)
CDE02_M_C_BASEL_BEH_SCORE_BUS.set_downstream(END)
CDE01_M_X_HIREP_MERGE.set_downstream(END)
RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)