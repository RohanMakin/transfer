try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO
import botocore.session # pylint: disable=import-error
from os.path import join, abspath
import traceback
from collections import namedtuple
import yaml
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 

import os
import sys 
import json


SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()
	
dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"

DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
ENV = DAG_CONFIG_DICT["CDE_ENV"]

script_loc="scripts/airflow/"
job_name="copy_master_data_to_hive_table.sh"

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]
TRANSFORMATION_LOC=DAG_CONFIG_DICT["TRANSFORMATION_LOC_"+ENV]
PRESENTATION_LOC=DAG_CONFIG_DICT["PRESENTATION_LOC_"+ENV]
CDE_HIVE_LOC=DAG_CONFIG_DICT["CDE_HIVE_LOC"]
SOURCING_SCRIPT_PATH=DAG_CONFIG_DICT["SOURCING_SCRIPT_PATH"]
ACS_EDW_TIER1 = DAG_CONFIG_DICT["ACS_EDW_TIER1"]
#CDE_PROCESS = DAG_CONFIG_DICT["CDE_PROCESS"]
CDE_CONTROL = DAG_CONFIG_DICT["CDE_CONTROL"]
CONTROL = DAG_CONFIG_DICT["CONTROL"]
BOP_CDE_BATCH_GRP = DAG_CONFIG_DICT["BOP_CDE_BATCH_GRP"]
BOP_CDE_BATCH_RBS = DAG_CONFIG_DICT["BOP_CDE_BATCH_RBS"]
BOP_CDE_BATCH_NWB = DAG_CONFIG_DICT["BOP_CDE_BATCH_NWB"]
BOP_CDE_BATCH_JUBUK = DAG_CONFIG_DICT["BOP_CDE_BATCH_JUBUK"]
BOP_CDE_BATCH_KUBIE = DAG_CONFIG_DICT["BOP_CDE_BATCH_KUBIE"]
BOD_CDE_GRP = DAG_CONFIG_DICT["BOD_CDE_GRP"]
BOD_CDE_RBS = DAG_CONFIG_DICT["BOD_CDE_RBS"]
BOD_CDE_NWB = DAG_CONFIG_DICT["BOD_CDE_NWB"]
BOD_CDE_JUBUK = DAG_CONFIG_DICT["BOD_CDE_JUBUK"]
BOD_CDE_KUBIE = DAG_CONFIG_DICT["BOD_CDE_KUBIE"]
BOD_CDE_GRP_M = DAG_CONFIG_DICT["BOD_CDE_GRP_M"]
BOD_CDE_RBS_M = DAG_CONFIG_DICT["BOD_CDE_RBS_M"]
BOD_CDE_NWB_M = DAG_CONFIG_DICT["BOD_CDE_NWB_M"]
BOD_CDE_JUBUK_M = DAG_CONFIG_DICT["BOD_CDE_JUBUK_M"]
BOD_CDE_KUBIE_M = DAG_CONFIG_DICT["BOD_CDE_KUBIE_M"]
BAC_RISK_DECISIONING_MART = DAG_CONFIG_DICT["BAC_RISK_DECISIONING_MART"]


file = open(MASTER_IP,"r")
IP = file.read()
file.close

dag = DAG('CDE01_TABLE_CREATION_FLOW' , default_args=default_args, schedule_interval=None, catchup=False, max_active_runs=1)

### Table Creation Tasks
CDE_TABLE_CREATION_CONTROL = BashOperator(task_id='CDE_TABLE_CREATION_CONTROL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+CDE_HIVE_LOC+"/scripts/table_view_creation/create_cde_table_cde_cde_control.sh "+TRANSFORMATION_LOC+" "+PRESENTATION_LOC+" "+CDE_HIVE_LOC+" "+CDE_CONTROL+" "+CONTROL+" "+BOP_CDE_BATCH_GRP+" -y,", dag=dag)

CDE_TABLE_CREATION_BOD = BashOperator(task_id='CDE_TABLE_CREATION_BOD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+CDE_HIVE_LOC+"/scripts/table_view_creation/create_cde_table_bod.sh "+TRANSFORMATION_LOC+" "+PRESENTATION_LOC+" "+CDE_HIVE_LOC+" "+BOD_CDE_GRP+" "+BOD_CDE_RBS+" "+BOD_CDE_NWB+" "+BOD_CDE_JUBUK+" "+BOD_CDE_KUBIE+" -y,", dag=dag)

CDE_TABLE_CREATION_BOD_M = BashOperator(task_id='CDE_TABLE_CREATION_BOD_M' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+CDE_HIVE_LOC+"/scripts/table_view_creation/create_cde_table_bod_m.sh "+TRANSFORMATION_LOC+" "+PRESENTATION_LOC+" "+CDE_HIVE_LOC+" "+BOD_CDE_GRP_M+" "+BOD_CDE_RBS_M+" "+BOD_CDE_NWB_M+" "+BOD_CDE_JUBUK_M+" "+BOD_CDE_KUBIE_M+" -y,", dag=dag)

CDE_TABLE_CREATION_BAC = BashOperator(task_id='CDE_TABLE_CREATION_BAC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+CDE_HIVE_LOC+"/scripts/table_view_creation/create_cde_table_cde_bac.sh "+TRANSFORMATION_LOC+" "+PRESENTATION_LOC+" "+CDE_HIVE_LOC+" "+BAC_RISK_DECISIONING_MART+" -y,", dag=dag)

CDE_TABLE_CREATION_BOP_GRP = BashOperator(task_id='CDE_TABLE_CREATION_BOP_GRP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+CDE_HIVE_LOC+"/scripts/table_view_creation/create_cde_table_cde_bop_batch_grp.sh "+TRANSFORMATION_LOC+" "+PRESENTATION_LOC+" "+CDE_HIVE_LOC+" "+BOP_CDE_BATCH_GRP+" -y,", dag=dag)
CDE_TABLE_CREATION_BOP_RBS = BashOperator(task_id='CDE_TABLE_CREATION_BOP_RBS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+CDE_HIVE_LOC+"/scripts/table_view_creation/create_cde_table_cde_bop_batch_rbs.sh "+TRANSFORMATION_LOC+" "+PRESENTATION_LOC+" "+CDE_HIVE_LOC+" "+BOP_CDE_BATCH_RBS+" -y,", dag=dag)
CDE_TABLE_CREATION_BOP_NWB = BashOperator(task_id='CDE_TABLE_CREATION_BOP_NWB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+CDE_HIVE_LOC+"/scripts/table_view_creation/create_cde_table_cde_bop_batch_nwb.sh "+TRANSFORMATION_LOC+" "+PRESENTATION_LOC+" "+CDE_HIVE_LOC+" "+BOP_CDE_BATCH_NWB+" -y,", dag=dag)
CDE_TABLE_CREATION_BOP_JUBUK = BashOperator(task_id='CDE_TABLE_CREATION_BOP_JUBUK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+CDE_HIVE_LOC+"/scripts/table_view_creation/create_cde_table_cde_bop_batch_jubuk.sh "+TRANSFORMATION_LOC+" "+PRESENTATION_LOC+" "+CDE_HIVE_LOC+" "+BOP_CDE_BATCH_JUBUK+" -y,", dag=dag)
CDE_TABLE_CREATION_BOP_KUBIE = BashOperator(task_id='CDE_TABLE_CREATION_BOP_KUBIE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+CDE_HIVE_LOC+"/scripts/table_view_creation/create_cde_table_cde_bop_batch_kubie.sh "+TRANSFORMATION_LOC+" "+PRESENTATION_LOC+" "+CDE_HIVE_LOC+" "+BOP_CDE_BATCH_KUBIE+" -y,", dag=dag)

#### Job Sequence 
CDE_TABLE_CREATION_CONTROL.set_downstream(CDE_TABLE_CREATION_BOD)
CDE_TABLE_CREATION_CONTROL.set_downstream(CDE_TABLE_CREATION_BOD_M)
CDE_TABLE_CREATION_BOD.set_downstream(CDE_TABLE_CREATION_BAC)
CDE_TABLE_CREATION_BOD_M.set_downstream(CDE_TABLE_CREATION_BAC)

CDE_TABLE_CREATION_BAC.set_downstream(CDE_TABLE_CREATION_BOP_GRP)
CDE_TABLE_CREATION_BOP_GRP.set_downstream(CDE_TABLE_CREATION_BOP_RBS)
CDE_TABLE_CREATION_BOP_GRP.set_downstream(CDE_TABLE_CREATION_BOP_NWB)
CDE_TABLE_CREATION_BOP_GRP.set_downstream(CDE_TABLE_CREATION_BOP_JUBUK)
CDE_TABLE_CREATION_BOP_GRP.set_downstream(CDE_TABLE_CREATION_BOP_KUBIE)

