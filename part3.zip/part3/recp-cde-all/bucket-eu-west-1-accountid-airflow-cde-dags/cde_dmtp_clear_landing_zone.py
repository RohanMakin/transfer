import json
import logging
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.utils.helpers import chain
from datetime import datetime, timedelta
import boto3

#######################################################################
AIRFLOW_FLOW_NAME='cde_dmtp_clear_landing_zone'
#######################################################################

default_args = {
    'owner': 'kaspp',
    'depends_on_past': False,
    'email': ['piotr.kasprowicz@rbs.co.uk'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'queue': 'sqs-airflow-cde',
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2021, 3, 1),
    'end_date': datetime(2099,12,31),
}

dag = DAG(AIRFLOW_FLOW_NAME, default_args=default_args, schedule_interval=None)

### ARIFLOW DAG SETUP CODE ** END ###

### PORTION FOR DAG SUBMISSION START ####
s3 = boto3.client('s3')

### Get EMR key

KEY_FILE = "/usr/local/airflow/ssh/cde-emr-ec2-key.pem"

with open("/usr/local/airflow/ssh/cde-emr-ip.txt", "r") as dmo_emr_ip:
    IP = dmo_emr_ip.read()

### Get AWS Account ID

#Extract the AWS account id
with open('/usr/local/airflow/ssh/variables.json') as json_file:
    data = json.load(json_file) 
aws_account_id = data['AccountId']
json_file.close()

run_date = "{{ (dag_run.start_date-macros.dateutil.relativedelta.relativedelta(days=1)).strftime('%Y-%m-%d') }}"

### Task definition - one per brand

SYNC_CODE = BashOperator(task_id='SYNC_CODE' , bash_command="ssh -o StrictHostKeyChecking=no -t -i "+KEY_FILE+" hadoop@" + IP + " sudo aws s3 sync s3://bucket-eu-west-1-{AWS_ACCOUNT_ID}-risk-cicd/cde/code/DMTP/release_dmtp_data_sourcing_1.0 /home/hadoop/dmo ".format(AWS_ACCOUNT_ID=aws_account_id), dag=dag)

CLEAR_LANDING_ZONE = BashOperator(task_id='CLEAR_LANDING_ZONE' , bash_command="ssh -o StrictHostKeyChecking=no -t -i "+KEY_FILE+" hadoop@" + IP + " bash /home/hadoop/dmo/scripts/clear_landing_zone.sh GRP {aws_account_id} {run_date}".format(aws_account_id=aws_account_id, run_date=run_date), dag=dag)

### Tasks flow

SYNC_CODE >> CLEAR_LANDING_ZONE