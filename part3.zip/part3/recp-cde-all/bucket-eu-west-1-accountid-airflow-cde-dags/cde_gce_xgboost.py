from airflow import DAG, utils
import boto3
import json
import base64
from botocore.exceptions import ClientError
from airflow.models.dagrun import DagRun
from airflow.configuration import conf
from airflow.models import Variable,XCom
from datetime import date, datetime, time, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.http_operator import SimpleHttpOperator
import requests
from airflow.models import Connection
from airflow import settings
from airflow.utils.db import provide_session
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import exc

#########################################################################
#DEFINE CONSTANTS 
#########################################################################

#Ip address
#file = open("/usr/local/airflow/ssh/sim-emr-ip.txt", "r")
#IP = file.read()
#file.close

#Defining the start date for the dag
START_DATE = datetime(2020,3,12)

#-------------------------------------------------------------------------------------
#Defining the default arguments of DAG
#-------------------------------------------------------------------------------------
default_args = {
  'owner': 'guptrdd',   					# required owner RACF
  'depends_on_past': False,					# required
  'email': ['rishav.gupta@natwest.com'],    # required owner email 
  'email_on_failure': False,				# required
  'email_on_retry': False,					# required 
  'queue': 'sqs-airflow-cde',				# required Job queue
  'retry_delay': timedelta(minutes = 1),	# required time after which next retry starts 
  'retries' : 1,							# required number of task retries incase of failure 
  'start_date': START_DATE,					# required can be previous/upcoming date  
  'catchup': False,							# Optional False if no backfill is needed(unnneccsary processing of previous day jobs)
  'end_date': datetime(2099, 12, 31),		# Optional by default: None 
  'schedule_interval': None,			# Optional by default: None if no scheduling is required 
  'concurrency': 3,							# required number of task that can run concurrently 
  }
 
  
dag = DAG('CDE_XGBOOST_MODEL', default_args = default_args,catchup=False)

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

json_bucket = "bucket-eu-west-1-"+account_id+"-risk-cicd"
json_file = "cde/dags/config/" + "token.json"

def read_file_from_s3(bucket, filename):
	s3 = boto3.resource('s3')
	obj = s3.Object(bucket, filename)
	return obj.get()['Body'].read()
	
file_content = read_file_from_s3(json_bucket, json_file)
json_content = json.loads(str(file_content, 'utf-8'))

content_area_url = json_content["content_area"]["content_area_url"]
content_metadata = json_content["content_area"]["content_metadata"]
encoded_data = json.dumps(content_metadata).encode('utf-8')
headers = requests.utils.default_headers()
headers.update({'Content-Type': 'application/json', "X-Correlation-Id": 'guptrdd015'})

secret_name = json_content["aws_secret"]["secret_name"]
region_name = json_content["aws_secret"]["region_name"]

def get_response_create_content(url, encoded_data, headers, secret_name, region_name):
	session = boto3.session.Session()
	client = session.client(service_name='secretsmanager', region_name=region_name)
	get_secret_value_response = client.get_secret_value(SecretId=secret_name)
	token = json.loads(get_secret_value_response['SecretString'])['accessToken']
	#token = json_content["token"]["accessToken"]
	headers.update({'X-Authorization': 'EncPK ' + token})
	get_response = requests.put(url, data = encoded_data, headers = headers, verify = False)
	print(get_response)
	print(get_response.json())

CREATE_CONTENT = PythonOperator(task_id = "CREATE_CONTENT",
                                     python_callable=get_response_create_content,
									 op_kwargs={'url': content_area_url, 'encoded_data': encoded_data, 'headers': headers, 'secret_name': secret_name, 'region_name': region_name},
                                     dag=dag)
									 
registration_url = json_content["register_model"]["registration_url"]
registration_metadata = json_content["register_model"]["registration_metadata"]
encoded_data = json.dumps(registration_metadata).encode('utf-8')

def get_response_register_model(url, encoded_data, headers, secret_name, region_name):
	session = boto3.session.Session()
	#client = session.client(service_name='secretsmanager', region_name=region_name)
	#get_secret_value_response = client.get_secret_value(SecretId=secret_name)
	#token = json.loads(get_secret_value_response['SecretString'])['accessToken']
	token = json_content["token"]["accessToken"]
	headers.update({'X-Authorization': 'EncPK ' + token})
	get_response = requests.put(url, data = encoded_data, headers = headers, verify = False)	
	print(get_response)
	print(get_response.json())


REGISTER_MODEL = PythonOperator(task_id = "REGISTER_MODEL",
                                     python_callable=get_response_register_model,
									 op_kwargs={'url': registration_url, 'encoded_data': encoded_data, 'headers': headers, 'secret_name': secret_name, 'region_name': region_name},
                                     dag=dag)									 


deploy_url = json_content["deploy_model"]["deploy_url"]
deployment_metadata = json_content["deploy_model"]["deployment_metadata"]
encoded_data = json.dumps(deployment_metadata).encode('utf-8')

def get_response_deploy_model(url, encoded_data, headers, secret_name, region_name):
	session = boto3.session.Session()
	#client = session.client(service_name='secretsmanager', region_name=region_name)
	#get_secret_value_response = client.get_secret_value(SecretId=secret_name)
	#token = json.loads(get_secret_value_response['SecretString'])['accessToken']
	token = json_content["token"]["accessToken"]
	headers.update({'X-Authorization': 'EncPK ' + token})
	get_response = requests.post(url, data = encoded_data, headers = headers, verify = False)	
	print(get_response)
	print(get_response.json())


DEPLOY_MODEL = PythonOperator(task_id = "DEPLOY_MODEL",
                                     python_callable=get_response_deploy_model,
									 op_kwargs={'url': deploy_url, 'encoded_data': encoded_data, 'headers': headers, 'secret_name': secret_name, 'region_name': region_name},
									 execution_timeout=timedelta(seconds=1600),
                                     dag=dag)

CREATE_CONTENT.set_downstream(REGISTER_MODEL)
REGISTER_MODEL.set_downstream(DEPLOY_MODEL)