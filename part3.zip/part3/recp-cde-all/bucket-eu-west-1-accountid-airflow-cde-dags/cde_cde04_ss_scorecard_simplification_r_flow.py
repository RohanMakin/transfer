from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from datetime import date, datetime, timedelta
import time
import os
import sys
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf
from airflow.models import DagBag, TaskInstance
from time import sleep
from airflow.operators.subdag_operator import SubDagOperator
import boto3
import botocore.session
import json
import yaml
from airflow.models.dagrun import DagRun
from airflow.models import Variable, XCom
from airflow.operators.http_operator import SimpleHttpOperator
import requests
from airflow.models import Connection
from airflow.utils.db import provide_session
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import exc

START_DATE = datetime(2020,3,12)
def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()


def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')


def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path' + str(path))
    bucket = path[0]
    print('bucket' + str(bucket))
    key = '/'.join(path[1:])
    print('key' + str(key))
    return bucket, key


def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)


SSH_CMD = "ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
    data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-" + account_id + "-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-" + account_id + "-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_" + cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH + DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH + DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH + DAG_CONFIG_DICT["JOB_PATH"]
CONCURRENCY_M_PROBE_LOGIC_FLOW = DAG_CONFIG_DICT["CONCURRENCY_M_PROBE_LOGIC_FLOW"]
FLOW_DEPENDENCY = BASE_PATH + DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]
SOURCING_CHECK_PATH = BASE_PATH + DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]
CDE_CONTROL = DAG_CONFIG_DICT["CDE_CONTROL"]
TRANSFORMATION_LOC = "s3://bucket-eu-west-1-" + account_id + "-processed-data/transformation/cde"
script_loc = "scripts/airflow/"
script_name = "subflow_trigger.sh"

file = open(MASTER_IP, "r")
IP = file.read()
file.close



flow_name = "CDE04_SS_SCORECARD_CLASSIFICATION_R_FLOW"
# SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
# SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
# schedule_str = "SCHEDULE_" + flow_name
# SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.sql.autoBroadcastJoinThreshold=-1 --conf spark.serializer=org.apache.spark.serializer.KryoSerializer --conf spark.executor.extraJavaOptions=\\" -XX:ThreadStackSize=81920 -XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"  -XX:ThreadStackSize=81920 -XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'
job_sizing_yaml_path = "s3://bucket-eu-west-1-" + account_id + "-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)



def get_spark_param_job(job_name):
    dict_key = flow_name + "." + job_name
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]
    spark_config_str = "SPARK_CONFIG_PARAM_" + job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]
    return spark_config_param


check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'
    return return_val



default_args = {
  'owner': 'SDA',                       # required owner RACF from  Mandira Majundar (MAJUMDM)
  'depends_on_past': False,                    # required
  'email': ['#ScoreCardSimplificationTeam@rbsres01.net'],    # required owner email
  'email_on_failure': False,                # required
  'email_on_retry': False,                    # required
  'queue': 'sqs-airflow-cde',                # required Job queue
  'retry_delay': timedelta(minutes = 1),    # required time after which next retry starts
  'retries' : 1,                            # required number of task retries incase of failure
  'start_date': START_DATE,                    # required can be previous/upcoming date
  'catchup': False,                            # Optional False if no backfill is needed(unnneccsary processing of previous day jobs)
  'end_date': datetime(2099, 12, 31),        # Optional by default: None
  'concurrency': 3,                            # required number of task that can run concurrently
  }



dag = DAG('CDE04_SS_SCORECARD_CLASSIFICATION_R_FLOW', default_args=default_args,schedule_interval=None,
          catchup=False)


RUN_CHECK = BranchPythonOperator(task_id='RUN_CHECK', python_callable=run_check_fun, dag=dag, provide_context=True)

STOP = DummyOperator(
    task_id='STOP',
    dag=dag, )


json_bucket = "bucket-eu-west-1-" + account_id + "-risk-cicd"
json_file = "cde/dags/config/" + "sda_token_RBS.json"


# change bucket name as per pre prod and appd
# json_bucket = "bucket-eu-west-1-897144472116-risk-cicd"
# json_file = "cde/dags/config/" + "nareysy_token.json"

def read_file_from_s3(bucket, filename):
    s3 = boto3.resource('s3')
    obj = s3.Object(bucket, filename)
    return obj.get()['Body'].read()


if account_id == "897144472116":
    env = 'dev'
elif account_id == "978523670193":
    env = 'uat'
elif account_id == "787511913082":
    env = 'prod'
else:
    sys.exit(1)

print("Get account_id from variables.json--->{}".format(account_id))
print("env--->{}".format(env))

file_content = read_file_from_s3(json_bucket, json_file)
json_content = json.loads(str(file_content, 'utf-8'))

if env == "dev":
    # deploy_url="https://6niritx6p5.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/deployment"
    deploy_url = json_content["url_dev"]["deploy_url"]
    # execute_url = "https://6niritx6p5.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/execution/async/execute"
    execute_url = json_content["url_dev"]["execute_url"]
    # job_url = "https://6niritx6p5.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/execution/async/job"
    job_url = json_content["url_dev"]["job_url"]
elif env == "uat":
    # deploy_url="https://zwwsoz4ws2.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/deployment"
    deploy_url = json_content["url_uat"]["deploy_url"]
    # execute_url = "https://zwwsoz4ws2.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/execution/async/execute"
    execute_url = json_content["url_uat"]["execute_url"]
    # job_url = "https://zwwsoz4ws2.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/execution/async/job"
    job_url = json_content["url_uat"]["job_url"]
elif env == "prod":
    # deploy_url="https://278iwlonyb.execute-api.eu-west-1.amazonaws.com/prod/galileo/gce/v2/deployment"
    deploy_url = json_content["url_prod"]["deploy_url"]
    # execute_url = "https://278iwlonyb.execute-api.eu-west-1.amazonaws.com/prod/galileo/gce/v2/execution/async/execute"
    execute_url = json_content["url_prod"]["execute_url"]
    # job_url = "https://278iwlonyb.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/execution/async/job"
    job_url = json_content["url_prod"]["job_url"]
else:
    sys.exit(1)
# print("deploy_url---->{}".format(deploy_url))
# print("execute url--->{}".format(execute_url))


# label_metadata={"contentAreaId": "ssmdlteam","label": "yash-deployment-label-xgb"}

# execute_url = json_content["execute_model"]["execute_url"]
execution_metadata = json_content["execute_model"]["execution_metadata"]
encoded_data = json.dumps(execution_metadata).encode('utf-8')
headers = requests.utils.default_headers()
headers.update({'Content-Type': 'application/json'})

secret_name = json_content["aws_secret"]["secret_name"]
region_name = json_content["aws_secret"]["region_name"]


# dummy = json_content["dummy"]["dummy_child"]


# print(dummy)

def get_response(url, encoded_data, headers, secret_name, region_name):
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    token = json.loads(get_secret_value_response['SecretString'])['accessToken']
    print('\m Token:' + str(token))
    headers.update({'X-Authorization': 'EncPK ' + token})

    # content_area=label_metadata.get("contentAreaId")
    content_area = json_content["label_metadata"]["contentAreaId"]
    # label_name=label_metadata.get("label")
    label_name = json_content["label_metadata"]["label_xgb"]
    print(label_name)
    label_url = "{}/contentarea/{}/label/{}".format(deploy_url, content_area, label_name)
    print("label_url:{}".format(label_url))
    r = requests.get(label_url, headers=headers, verify=False)

    deployment_id_from_label = r.json().get("deploymentId")
    print("deployment_id_from_label = {}".format(deployment_id_from_label))

    # execution_metadata = json_content["execute_model"]["execution_metadata"]
    execution_metadata.update({'deploymentId': deployment_id_from_label})

    encoded_data = json.dumps(execution_metadata).encode('utf-8')

    get_response = requests.post(url, data=encoded_data, headers=headers, verify=False)
    print(get_response)
    print(get_response.json())

    # job_url = json_content["job_url"]["url"]
    # job_url = "https://zwwsoz4ws2.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/execution/async/job"
    # job_url = "https://6niritx6p5.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/execution/async/job"
    asyncJobId = get_response.json()["asyncJobId"]
    job_status = ''
    while job_status != 'Completed':
        time.sleep(15)
        gce_response = requests.get(job_url + '/' + asyncJobId, headers=headers, verify=False)
        print(gce_response.json())
        job_status = gce_response.json()['status']
        if job_status == 'Stopped':
            raise AirflowException("Failing task because job stopped.")
        if job_status == 'Failed':
            raise AirflowException("Failing task because job failed.")


EXECUTE_XGB_MODEL = PythonOperator(task_id="EXECUTE_XGB_MODEL",
                                   python_callable=get_response,
                                   op_kwargs={'url': execute_url, 'encoded_data': encoded_data, 'headers': headers,
                                              'secret_name': secret_name, 'region_name': region_name},
                                   dag=dag)

# execute_url2 = json_content["execute_model2"]["execute_url"]
execute_url2 = execute_url
execution_metadata2 = json_content["execute_model2"]["execution_metadata"]
encoded_data2 = json.dumps(execution_metadata2).encode('utf-8')

headers2 = requests.utils.default_headers()
headers2.update({'Content-Type': 'application/json'})


def get_response2(url, encoded_data2, headers2, secret_name, region_name):
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    token2 = json.loads(get_secret_value_response['SecretString'])['accessToken']
    headers2.update({'X-Authorization': 'EncPK ' + token2})

    content_area = json_content["label_metadata"]["contentAreaId"]
    # label_name=label_metadata.get("label")
    label_name = json_content["label_metadata"]["label_xform"]
    print(label_name)
    label_url = "{}/contentarea/{}/label/{}".format(deploy_url, content_area, label_name)
    print("label_url:{}".format(label_url))
    r = requests.get(label_url, headers=headers2, verify=False)

    deployment_id_from_label = r.json().get("deploymentId")
    print("deployment_id_from_label = {}".format(deployment_id_from_label))

    # execution_metadata = json_content["execute_model"]["execution_metadata"]
    execution_metadata2.update({'deploymentId': deployment_id_from_label})

    encoded_data2 = json.dumps(execution_metadata2).encode('utf-8')

    get_response2 = requests.post(url, data=encoded_data2, headers=headers2, verify=False)
    print(get_response2)
    print(get_response2.json())

    # job_url2 = json_content["job_url"]["url"]
    job_url2 = job_url
    # job_url2 = "https://zwwsoz4ws2.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/execution/async/job"
    # job_url2 = "https://6niritx6p5.execute-api.eu-west-1.amazonaws.com/stable/galileo/gce/v2/execution/async/job"

    asyncJobId2 = get_response2.json()["asyncJobId"]
    job_status2 = ''
    while job_status2 != 'Completed':
        time.sleep(15)
        gce_response2 = requests.get(job_url2 + '/' + asyncJobId2, headers=headers2, verify=False)
        print(gce_response2.json())
        job_status2 = gce_response2.json()['status']
        if job_status2 == 'Stopped':
            raise AirflowException("Failing task because job stopped.")
        if job_status2 == 'Failed':
            raise AirflowException("Failing task because job failed.")


EXECUTE_XFORM_MODEL = PythonOperator(task_id="EXECUTE_XFORM_MODEL",
                                     python_callable=get_response2,
                                     op_kwargs={'url': execute_url2, 'encoded_data2': encoded_data2,
                                                'headers2': headers2, 'secret_name': secret_name,
                                                'region_name': region_name},
                                     dag=dag)





CDE01_M_FPF_INPUT_VAL_FLOW = BashOperator(task_id='CDE01_M_FPF_INPUT_VAL_FLOW',
                                         bash_command=SSH_CMD + " " + KEY_FILE + " hadoop@" + IP + " \"spark-submit " + get_spark_param_job(
                                             'CDE01_M_FPF_INPUT_VAL_FLOW') + " " + cmd_part + "\" " + JOB_PATH + "CDE01_M_FPF_INPUT_VAL.py RBS CDE01_M_FPF_INPUT_VAL_FLOW CDE04_SS_SCORECARD_CLASSIFICATION_R_FLOW -y,",
                                         dag=dag)
CDE01_M_FPF_OUTPUT_VAL_FLOW = BashOperator(task_id='CDE01_M_FPF_OUTPUT_VAL_FLOW',
                                         bash_command=SSH_CMD + " " + KEY_FILE + " hadoop@" + IP + " \"spark-submit " + get_spark_param_job(
                                             'CDE01_M_FPF_OUTPUT_VAL_FLOW') + " " + cmd_part + "\" " + JOB_PATH + "CDE01_M_FPF_OUTPUT_VAL.py RBS CDE01_M_FPF_OUTPUT_VAL_FLOW CDE04_SS_SCORECARD_CLASSIFICATION_R_FLOW -y,",
                                         dag=dag)




START = BashOperator(task_id='START',
                     bash_command=SSH_CMD + " " + KEY_FILE + " hadoop@" + IP + " \"spark-submit " + get_spark_param_job(
                         'START') + " " + cmd_part + "\" " + LOG_START_PATH + " CDE04_SS_SCORECARD_CLASSIFICATION_R_FLOW -y,",
                     dag=dag)
END = BashOperator(task_id='END',
                   bash_command=SSH_CMD + " " + KEY_FILE + " hadoop@" + IP + " \"spark-submit " + get_spark_param_job(
                       'END') + " " + cmd_part + "\" " + LOG_END_PATH + " CDE04_SS_SCORECARD_CLASSIFICATION_R_FLOW -y,",
                   dag=dag)

START.set_downstream(CDE01_M_FPF_INPUT_VAL_FLOW)
CDE01_M_FPF_INPUT_VAL_FLOW.set_downstream(EXECUTE_XGB_MODEL)
EXECUTE_XGB_MODEL.set_downstream(EXECUTE_XFORM_MODEL)
EXECUTE_XFORM_MODEL.set_downstream(CDE01_M_FPF_OUTPUT_VAL_FLOW)
CDE01_M_FPF_OUTPUT_VAL_FLOW.set_downstream(END)

RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)