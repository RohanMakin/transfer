try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO
import botocore.session # pylint: disable=import-error
from os.path import join, abspath
import traceback
from collections import namedtuple
import yaml
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 

import os
import sys 
import json


SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"

DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
ENV = DAG_CONFIG_DICT["CDE_ENV"]

script_loc="batch-framework/teradata-migration/"
teradata_to_aws_stg_job="cde_historical_data_loading_from_teradata_to_hive_staging_layer.py"
stg_to_aws_final_job="cde_historical_data_loading_from_hive_staging_to_final_layer.py"

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]
POLLING_FILE = DAG_CONFIG_DICT["POLLING_FILE"]
POLLING_MULTI_FILE = DAG_CONFIG_DICT["POLLING_MULTI_FILE"]
LOG_STATUS_START = DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_STATUS_END = DAG_CONFIG_DICT["LOG_STATUS_END"]
TRANSFORMATION_LOC=DAG_CONFIG_DICT["TRANSFORMATION_LOC_"+ENV]
PRESENTATION_LOC=DAG_CONFIG_DICT["PRESENTATION_LOC_"+ENV]
CDE_FILE_LOC=DAG_CONFIG_DICT["CDE_FILE_LOC"]
spark_config_param18 = DAG_CONFIG_DICT["SPARK_CONFIG_PARAM_18G"]
spark_config_param12 = DAG_CONFIG_DICT["SPARK_CONFIG_PARAM_12G"]
spark_config_param_gen = DAG_CONFIG_DICT["SPARK_CONFIG_PARAM_GEN"]

file = open(MASTER_IP,"r")
IP = file.read()
file.close

dag = DAG('LOAD_MIGRATED_DATA' , default_args=default_args, schedule_interval=None, catchup=False, max_active_runs=1)

LOAD_MIGRATED_DATA_STG1 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG1' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL1 CTL_INTERMEDIATE1 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL1 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL1' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE1 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG2 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG2' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL2 CTL_INTERMEDIATE2 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL2 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL2' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE2 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG3 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG3' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL3 CTL_INTERMEDIATE3 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL3 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL3' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE3 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG4 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG4' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL4 CTL_INTERMEDIATE4 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL4 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL4' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE4 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG5 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG5' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL5 CTL_INTERMEDIATE5 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL5 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL5' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE5 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG6 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG6' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL6 CTL_INTERMEDIATE6 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL6 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL6' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param12+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE6 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG7 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG7' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL7 CTL_INTERMEDIATE7 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL7 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL7' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param12+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE7 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG8 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG8' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL8 CTL_INTERMEDIATE8 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL8 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL8' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param12+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE8 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG9 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG9' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL9 CTL_INTERMEDIATE9 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL9 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL9' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param12+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE9 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG10 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG10' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL10 CTL_INTERMEDIATE10 -y,", dag=dag)
LOAD_MIGRATED_DATA_FINAL10 = BashOperator(task_id='LOAD_MIGRATED_DATA_FINAL10' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param12+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE10 Y -y,", dag=dag)
LOAD_MIGRATED_DATA_STG11 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG11' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL11 CTL_INTERMEDIATE11 -y,", dag=dag)
LOAD_MIGRATED_DATA_TEMP11 = BashOperator(task_id='LOAD_MIGRATED_DATA_TEMP11' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE11 N -y,", dag=dag)
LOAD_MIGRATED_DATA_STG12 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG12' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL12 CTL_INTERMEDIATE12 -y,", dag=dag)
LOAD_MIGRATED_DATA_TEMP12 = BashOperator(task_id='LOAD_MIGRATED_DATA_TEMP12' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE12 N -y,", dag=dag)
LOAD_MIGRATED_DATA_STG13 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG13' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL13 CTL_INTERMEDIATE13 -y,", dag=dag)
LOAD_MIGRATED_DATA_TEMP13 = BashOperator(task_id='LOAD_MIGRATED_DATA_TEMP13' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE13 N -y,", dag=dag)
LOAD_MIGRATED_DATA_STG14= BashOperator(task_id='LOAD_MIGRATED_DATA_STG14' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL14 CTL_INTERMEDIATE14 -y,", dag=dag)
LOAD_MIGRATED_DATA_TEMP14 = BashOperator(task_id='LOAD_MIGRATED_DATA_TEMP14' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE14 N -y,", dag=dag)
LOAD_MIGRATED_DATA_STG15 = BashOperator(task_id='LOAD_MIGRATED_DATA_STG15' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ CDE_FILE_LOC+ script_loc+ teradata_to_aws_stg_job +" CTL15 CTL_INTERMEDIATE15 -y,", dag=dag)
LOAD_MIGRATED_DATA_TEMP15 = BashOperator(task_id='LOAD_MIGRATED_DATA_TEMP15' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param18+" "+ CDE_FILE_LOC+ script_loc + stg_to_aws_final_job +" CTL_INTERMEDIATE15 N -y,", dag=dag)


LOAD_MIGRATED_DATA_STG1.set_downstream(LOAD_MIGRATED_DATA_FINAL1)
LOAD_MIGRATED_DATA_STG2.set_downstream(LOAD_MIGRATED_DATA_FINAL2)
LOAD_MIGRATED_DATA_STG3.set_downstream(LOAD_MIGRATED_DATA_FINAL3)
LOAD_MIGRATED_DATA_STG4.set_downstream(LOAD_MIGRATED_DATA_FINAL4)
LOAD_MIGRATED_DATA_STG5.set_downstream(LOAD_MIGRATED_DATA_FINAL5)
LOAD_MIGRATED_DATA_STG6.set_downstream(LOAD_MIGRATED_DATA_FINAL6)
LOAD_MIGRATED_DATA_STG7.set_downstream(LOAD_MIGRATED_DATA_FINAL7)
LOAD_MIGRATED_DATA_STG8.set_downstream(LOAD_MIGRATED_DATA_FINAL8)
LOAD_MIGRATED_DATA_STG9.set_downstream(LOAD_MIGRATED_DATA_FINAL9)
LOAD_MIGRATED_DATA_STG10.set_downstream(LOAD_MIGRATED_DATA_FINAL10)
LOAD_MIGRATED_DATA_STG11.set_downstream(LOAD_MIGRATED_DATA_TEMP11)
LOAD_MIGRATED_DATA_STG12.set_downstream(LOAD_MIGRATED_DATA_TEMP12)
LOAD_MIGRATED_DATA_STG13.set_downstream(LOAD_MIGRATED_DATA_TEMP13)
LOAD_MIGRATED_DATA_STG14.set_downstream(LOAD_MIGRATED_DATA_TEMP14)
LOAD_MIGRATED_DATA_STG15.set_downstream(LOAD_MIGRATED_DATA_TEMP15)



