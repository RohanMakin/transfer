from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from datetime import date, datetime, time, timedelta
import os
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
from airflow.operators.subdag_operator import SubDagOperator
'''from cde_cde01_m_r_pal_prep_flow import child_dag_cde01_m_r_pal_prep_flow
from cde_cde03_m_r_passes_flow import child_dag_cde03_m_r_passes_flow
from cde_cde03_m_r_pscore_flow import child_dag_cde03_m_r_pscore_flow'''
import boto3
import botocore.session 
import json
import yaml

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]
FLOW_DEPENDENCY = BASE_PATH+DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
CONCURRENCY_M_PAL_P1_LOGIC_FLOW = DAG_CONFIG_DICT["CONCURRENCY_M_PAL_P1_LOGIC_FLOW"]
SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]
CDE_CONTROL = DAG_CONFIG_DICT["CDE_CONTROL"]
TRANSFORMATION_LOC = "s3://bucket-eu-west-1-"+account_id+"-processed-data/transformation/cde"
script_loc="scripts/airflow/"
script_name="subflow_trigger.sh"

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	

file = open(MASTER_IP,"r")
IP = file.read()
file.close
def call_dagbag(*op_args):
    flow_name = op_args[0]
    print('Check DAG '+str(flow_name))
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    
    dag_bag_list = dagbag.dags[flow_name] #dagid     
    call_status_check(dag_bag_list) # last dag state
   

def call_status_check(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_state = last_instance.get_state() # last dag state
        print('\n Last Execution state'+str(dag_state))

        if(str(dag_state) == 'success') :
            print ('Dependency Met')    
        else :
            print ('Dependency Not Met')
            call_wait(dag_bag_list)  
  
def call_wait(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(300)    # Sleep
    call_status_check(dag_bag_list)
	
flow_name="CDE99_M_R_PAL_P1_LOGIC_FLOW_FBD"
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name	
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key] 
    return str(polling_time)
	
def get_spark_param_job(job_name):
    param_flow_name="CDE99_M_R_PAL_P1_LOGIC_FLOW"
    dict_key = param_flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val
	
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

dag = DAG('CDE99_M_R_PAL_P1_LOGIC_FLOW_FBD' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1, concurrency = CONCURRENCY_M_PAL_P1_LOGIC_FLOW)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
	
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)

'''subDag_cde01_m_r_pal_prep_flow = SubDagOperator(
subdag=child_dag_cde01_m_r_pal_prep_flow('CDE99_M_R_PAL_P1_LOGIC_FLOW_FBD', 'CDE01_M_R_PAL_PREP_FLOW', default_args, dag.schedule_interval),
task_id='CDE01_M_R_PAL_PREP_FLOW',
default_args=default_args,
dag=dag)

subDag_cde03_m_r_passes_flow = SubDagOperator(
subdag=child_dag_cde03_m_r_passes_flow('CDE99_M_R_PAL_P1_LOGIC_FLOW_FBD', 'CDE03_M_R_PASSES_FLOW', default_args, dag.schedule_interval),
task_id='CDE03_M_R_PASSES_FLOW',
default_args=default_args,
dag=dag)

subDag_cde03_m_r_pscore_flow = SubDagOperator(
subdag=child_dag_cde03_m_r_pscore_flow('CDE99_M_R_PAL_P1_LOGIC_FLOW_FBD', 'CDE03_M_R_PSCORE_FLOW', default_args, dag.schedule_interval),
task_id='CDE03_M_R_PSCORE_FLOW',
default_args=default_args,
dag=dag)'''

#CDE01_M_R_PAL_PREP_FLOW

CDE01_M_X_PAL_ACCOUNT_PREP = BashOperator(task_id='CDE01_M_X_PAL_ACCOUNT_PREP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PAL_ACCOUNT_PREP')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PAL_ACCOUNT_PREP.py RBS CDE01_M_X_PAL_ACCOUNT_PREP CDE01_M_R_PAL_PREP_FLOW -y,", dag=dag)
CDE01_M_X_PAL_FINAL_PREP = BashOperator(task_id='CDE01_M_X_PAL_FINAL_PREP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PAL_FINAL_PREP')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PAL_FINAL_PREP.py RBS CDE01_M_X_PAL_FINAL_PREP CDE01_M_R_PAL_PREP_FLOW -y,", dag=dag)
##	CDE01_M_X_PAL_EXTRACT_CHECK = BashOperator(task_id='CDE01_M_X_PAL_EXTRACT_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PAL_EXTRACT_CHECK')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PAL_EXTRACT_CHECK.py RBS CDE01_M_X_PAL_EXTRACT_CHECK CDE01_M_R_PAL_PREP_FLOW -y,", dag=dag)
##	CDE01_M_X_PAL_EXTRACT_CHECK.set_downstream(CDE01_M_X_PAL_ACCOUNT_PREP)
CDE01_M_X_PAL_ACCOUNT_PREP.set_downstream(CDE01_M_X_PAL_FINAL_PREP)

# CDER-4932 [Code Optimization] : calling jobs through a common sh script
# #CDE03_M_R_PASSES_FLOW
# CDE03_M_C_PASSES_RECOMM = BashOperator(task_id='CDE03_M_C_PASSES_RECOMM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PASSES_RECOMM')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PASSES_RECOMM.py RBS CDE03_M_C_PASSES_RECOMM CDE03_M_R_PASSES_FLOW -y,", dag=dag)
# #CDE03_M_C_PASSES_RECOMM.set_downstream(subDag_cde01_m_r_semi_banked_flow)


##Dependency check for CL22 scorecard [SDA]
DEPENDENCY_CL22_SCORECARD = BashOperator(task_id='DEPENDENCY_CL22_SCORECARD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE04_SDA_CL22_R_FLOW "+get_polling_time('CDE04_SDA_CL22_R_FLOW')+" -y,", dag=dag)

#CDE03_M_R_PSCORE_FLOW
CDE03_M_C_PSCORE_CC_SC2 = BashOperator(task_id='CDE03_M_C_PSCORE_CC_SC2' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PSCORE_CC_SC2')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PSCORE_CC_SC2.py RBS CDE03_M_C_PSCORE_CC_SC2 CDE03_M_R_PSCORE_FLOW -y,", dag=dag)
CDE03_M_C_PSCORE_FRL_SC77 = BashOperator(task_id='CDE03_M_C_PSCORE_FRL_SC77' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PSCORE_FRL_SC77')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PSCORE_FRL_SC77.py RBS CDE03_M_C_PSCORE_FRL_SC77 CDE03_M_R_PSCORE_FLOW -y,", dag=dag)
CDE03_M_C_PSCORE_FRL_SC79 = BashOperator(task_id='CDE03_M_C_PSCORE_FRL_SC79' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PSCORE_FRL_SC79')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PSCORE_FRL_SC79.py RBS CDE03_M_C_PSCORE_FRL_SC79 CDE03_M_R_PSCORE_FLOW -y,", dag=dag)
#CDE03_M_C_PSCORE_FRL_SC = BashOperator(task_id='CDE03_M_C_PSCORE_FRL_SC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PSCORE_FRL_SC')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PSCORE_FRL_SC.py RBS CDE03_M_C_PSCORE_FRL_SC CDE03_M_R_PSCORE_FLOW -y,", dag=dag)
CDE03_M_C_PSCORE_MTA_SC86 = BashOperator(task_id='CDE03_M_C_PSCORE_MTA_SC86' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PSCORE_MTA_SC86')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PSCORE_MTA_SC86.py RBS CDE03_M_C_PSCORE_MTA_SC86 CDE03_M_R_PSCORE_FLOW -y,", dag=dag)
CDE03_M_C_PSCORE_MTA_SC87 = BashOperator(task_id='CDE03_M_C_PSCORE_MTA_SC87' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PSCORE_MTA_SC87')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PSCORE_MTA_SC87.py RBS CDE03_M_C_PSCORE_MTA_SC87 CDE03_M_R_PSCORE_FLOW -y,", dag=dag)
#NEW JOB FOR NPBJ-1528
CDE03_M_C_PSCORE_CC18_OUTPUT = BashOperator(task_id='CDE03_M_C_PSCORE_CC18_OUTPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PSCORE_CC18_OUTPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PSCORE_CC18_OUTPUT.py RBS CDE03_M_C_PSCORE_CC18_OUTPUT CDE03_M_R_PSCORE_FLOW -y,", dag=dag)

# CDER-4932 [Code Optimization] : calling jobs through a common sh script
# CDE03_M_C_PSCORE_OUTPUT_SCORELOG = BashOperator(task_id='CDE03_M_C_PSCORE_OUTPUT_SCORELOG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PSCORE_OUTPUT_SCORELOG')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PSCORE_OUTPUT_SCORELOG.py RBS CDE03_M_C_PSCORE_OUTPUT_SCORELOG CDE03_M_R_PSCORE_FLOW -y,", dag=dag)
# CDE03_M_C_PSCORE_OUTPUT = BashOperator(task_id='CDE03_M_C_PSCORE_OUTPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PSCORE_OUTPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PSCORE_OUTPUT.py RBS CDE03_M_C_PSCORE_OUTPUT CDE03_M_R_PSCORE_FLOW -y,", dag=dag)
# CDE03_M_C_PSCORE_POSTJOB = BashOperator(task_id='CDE03_M_C_PSCORE_POSTJOB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_C_PSCORE_POSTJOB')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_C_PSCORE_POSTJOB.py RBS CDE03_M_C_PSCORE_POSTJOB CDE03_M_R_PSCORE_FLOW -y,", dag=dag)

CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW = BashOperator(task_id='CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ BASE_PATH+script_loc+script_name+" "+JOB_PATH+" RBS CDE02_M_R_PSCORE_PASSES_SEMI_BANKED_FLOW "+BASE_PATH+script_loc+"CDE02_M_PSCORE_PASSES_SEMI_BANKED_FLOW.ini"+" " +TRANSFORMATION_LOC+" "+CDE_CONTROL+" -y,", dag=dag)

# CDER-4932 [Code Optimization] : calling jobs through a common sh script and adjusting dependencies : commenting and adding
#CDE03_M_C_PSCORE_FRL_SC.set_downstream(CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW)
CDE03_M_C_PSCORE_MTA_SC87.set_downstream(CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW)
CDE03_M_C_PSCORE_MTA_SC86.set_downstream(CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW)
CDE03_M_C_PSCORE_CC_SC2.set_downstream(CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW)
CDE03_M_C_PSCORE_FRL_SC77.set_downstream(CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW)
CDE03_M_C_PSCORE_FRL_SC79.set_downstream(CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW)
#NEW JOB FOR NPBJ-1528
CDE03_M_C_PSCORE_CC18_OUTPUT.set_downstream(CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW)
#CL22 scorecard [SDA]
#DEPENDENCY_CL22_SCORECARD.set_downstream(CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW)
DEPENDENCY_CL22_SCORECARD.set_downstream(CDE03_M_C_PSCORE_FRL_SC79)
# CDE03_M_C_PSCORE_OUTPUT.set_downstream(CDE03_M_C_PSCORE_OUTPUT_SCORELOG)
# CDE03_M_C_PSCORE_FRL_SC.set_downstream(CDE03_M_C_PSCORE_OUTPUT)
# CDE03_M_C_PSCORE_MTA_SC87.set_downstream(CDE03_M_C_PSCORE_OUTPUT)
# CDE03_M_C_PSCORE_MTA_SC86.set_downstream(CDE03_M_C_PSCORE_OUTPUT)
# CDE03_M_C_PSCORE_CC_SC2.set_downstream(CDE03_M_C_PSCORE_OUTPUT)
# CDE03_M_C_PSCORE_FRL_SC77.set_downstream(CDE03_M_C_PSCORE_OUTPUT)
# CDE03_M_C_PSCORE_FRL_SC79.set_downstream(CDE03_M_C_PSCORE_OUTPUT)
# CDE03_M_C_PSCORE_OUTPUT_SCORELOG.set_downstream(CDE03_M_C_PSCORE_POSTJOB)


# CDER-4932 [Code Optimization] : Removing non functional tasks : adding new flow dependencies
# dag_start_pscore_flow= DummyOperator(task_id='START_CDE03_M_R_PSCORE_FLOW',dag=dag,)
# dag_start_pscore_flow.set_downstream(CDE03_M_C_PSCORE_FRL_SC)
# dag_start_pscore_flow.set_downstream(CDE03_M_C_PSCORE_CC_SC2)
# dag_start_pscore_flow.set_downstream(CDE03_M_C_PSCORE_FRL_SC77)
# dag_start_pscore_flow.set_downstream(CDE03_M_C_PSCORE_FRL_SC79)
# dag_start_pscore_flow.set_downstream(CDE03_M_C_PSCORE_MTA_SC86)
# dag_start_pscore_flow.set_downstream(CDE03_M_C_PSCORE_MTA_SC87)
#CDE01_M_X_PAL_FINAL_PREP.set_downstream(CDE03_M_C_PSCORE_FRL_SC)
CDE01_M_X_PAL_FINAL_PREP.set_downstream(CDE03_M_C_PSCORE_CC_SC2)
CDE01_M_X_PAL_FINAL_PREP.set_downstream(CDE03_M_C_PSCORE_FRL_SC77)
#CDE01_M_X_PAL_FINAL_PREP.set_downstream(CDE03_M_C_PSCORE_FRL_SC79)
CDE01_M_X_PAL_FINAL_PREP.set_downstream(CDE03_M_C_PSCORE_MTA_SC86)
CDE01_M_X_PAL_FINAL_PREP.set_downstream(CDE03_M_C_PSCORE_MTA_SC87)
#NEW JOB FOR NPBJ-1528
CDE01_M_X_PAL_FINAL_PREP.set_downstream(CDE03_M_C_PSCORE_CC18_OUTPUT)
#CL22 scorecard [SDA]
CDE01_M_X_PAL_FINAL_PREP.set_downstream(DEPENDENCY_CL22_SCORECARD)

# CDER-4932 [Code Optimization] : calling jobs through a common sh script and adjusting dependencies :
#CDE01_M_R_SEMI_BANKED_FLOW
# CDE01_M_X_SEMI_BANKED_POP_BRAND = BashOperator(task_id='CDE01_M_X_SEMI_BANKED_POP_BRAND' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_SEMI_BANKED_POP_BRAND')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_SEMI_BANKED_POP_BRAND.py RBS CDE01_M_X_SEMI_BANKED_POP_BRAND CDE01_M_R_SEMI_BANKED_FLOW -y,", dag=dag)
# CDE01_M_X_SEMI_BANKED_DERVS = BashOperator(task_id='CDE01_M_X_SEMI_BANKED_DERVS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_SEMI_BANKED_DERVS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_SEMI_BANKED_DERVS.py RBS CDE01_M_X_SEMI_BANKED_DERVS CDE01_M_R_SEMI_BANKED_FLOW -y,", dag=dag)
# CDE03_M_X_SEMI_BANKED_POL_SC_RECOMM = BashOperator(task_id='CDE03_M_X_SEMI_BANKED_POL_SC_RECOMM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_X_SEMI_BANKED_POL_SC_RECOMM')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_X_SEMI_BANKED_POL_SC_RECOMM.py RBS CDE03_M_X_SEMI_BANKED_POL_SC_RECOMM CDE01_M_R_SEMI_BANKED_FLOW -y,", dag=dag)

# CDE01_M_X_SEMI_BANKED_POP_BRAND.set_downstream(CDE01_M_X_SEMI_BANKED_DERVS)
# CDE01_M_X_SEMI_BANKED_DERVS.set_downstream(CDE03_M_X_SEMI_BANKED_POL_SC_RECOMM)

START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE99_M_R_PAL_P1_LOGIC_FLOW -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE99_M_R_PAL_P1_LOGIC_FLOW -y,", dag=dag)
DEPENDENCY_CHECK_M_R_PROBE_LOGIC= BashOperator(task_id='DEPENDENCY_CHECK_M_R_PROBE_LOGIC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_R_PROBE_LOGIC_POST_GURN_FLOW "+get_polling_time('CDE99_M_R_PROBE_LOGIC_POST_GURN_FLOW')+" -y,", dag=dag)
DEPENDENCY_CHECK_M_G_GURN_MASTER= BashOperator(task_id='DEPENDENCY_CHECK_M_G_GURN_MASTER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_G_GURN_MASTER_FLOW "+get_polling_time('CDE99_M_G_GURN_MASTER_FLOW')+" -y,", dag=dag)
DEPENDENCY_CHECK_M_R_BUS_LOGIC= BashOperator(task_id='DEPENDENCY_CHECK_M_R_BUS_LOGIC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_R_BUS_LOGIC_FLOW "+get_polling_time('CDE99_M_R_BUS_LOGIC_FLOW')+" -y,", dag=dag)
DEPENDENCY_CDE04_R_SS_SCORECARD= BashOperator(task_id='DEPENDENCY_CDE04_R_SS_SCORECARD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE04_SS_SCORECARD_CLASSIFICATION_R_FLOW "+get_polling_time('CDE04_SS_SCORECARD_CLASSIFICATION_R_FLOW')+" -y,", dag=dag)

# CDER-4932 [Code Optimization] : Removing non functional tasks 
# dag_start_pal_outputs= DummyOperator(task_id='START_CDE04_M_R_PAL_OUTPUTS_FLOW',dag=dag,)
# dag_end_pal_outputs= DummyOperator(task_id='END_CDE04_M_R_PAL_OUTPUTS_FLOW',dag=dag,)

CDE01_M_X_PAL_SCREEN_BUILD = BashOperator(task_id='CDE01_M_X_PAL_SCREEN_BUILD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PAL_SCREEN_BUILD')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PAL_SCREEN_BUILD.py RBS CDE01_M_X_PAL_SCREEN_BUILD CDE04_M_R_PAL_OUTPUTS_FLOW -y,", dag=dag)

# CDER-4932 [Code Optimization] : calling jobs through a common sh script and adjusting dependencies :
# CDE04_M_C_PASSES_OUTPUT_MAPPER = BashOperator(task_id='CDE04_M_C_PASSES_OUTPUT_MAPPER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_C_PASSES_OUTPUT_MAPPER')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_C_PASSES_OUTPUT_MAPPER.py RBS CDE04_M_C_PASSES_OUTPUT_MAPPER CDE04_M_R_PAL_OUTPUTS_FLOW -y,", dag=dag)

CDE05_M_X_PAL_VAL = BashOperator(task_id='CDE05_M_X_PAL_VAL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_PAL_VAL')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_PAL_VAL.py RBS CDE05_M_X_PAL_VAL CDE04_M_R_PAL_OUTPUTS_FLOW -y,", dag=dag)

# CDER-4932 [Code Optimization] : Removing non functional tasks 
# dag_start_powerc_cust_lvl= DummyOperator(task_id='START_CDE04_M_R_POWERC_CUST_LVL_FLOW',dag=dag,)
# dag_end_powerc_cust_lvl= DummyOperator(task_id='END_CDE04_M_R_POWERC_CUST_LVL_FLOW',dag=dag,)

CDE04_M_X_PAL_CUST_POWERCR = BashOperator(task_id='CDE04_M_X_PAL_CUST_POWERCR' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_X_PAL_CUST_POWERCR')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_X_PAL_CUST_POWERCR.py RBS CDE04_M_X_PAL_CUST_POWERCR CDE04_M_R_POWERC_CUST_LVL_FLOW -y,", dag=dag)

dag_start_riskmart_load= DummyOperator(task_id='START_CDE07_M_R_RISKMART_LOAD_FLOW',dag=dag,)
dag_end_riskmart_load= DummyOperator(task_id='END_CDE07_M_R_RISKMART_LOAD_FLOW',dag=dag,)

CDE07_M_X_PAL_CC18_SCL = BashOperator(task_id='CDE07_M_X_PAL_CC18_SCL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_CC18_SCL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_CC18_SCL.py RBS CDE07_M_X_PAL_CC18_SCL CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_PAL_CC_SCL = BashOperator(task_id='CDE07_M_X_PAL_CC_SCL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_CC_SCL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_CC_SCL.py RBS CDE07_M_X_PAL_CC_SCL CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_PAL_FRL_SCL = BashOperator(task_id='CDE07_M_X_PAL_FRL_SCL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_FRL_SCL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_FRL_SCL.py RBS CDE07_M_X_PAL_FRL_SCL CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_PAL_INPUT = BashOperator(task_id='CDE07_M_X_PAL_INPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_INPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_INPUT.py RBS CDE07_M_X_PAL_INPUT CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_PAL_MTA_SCL = BashOperator(task_id='CDE07_M_X_PAL_MTA_SCL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_MTA_SCL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_MTA_SCL.py RBS CDE07_M_X_PAL_MTA_SCL CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_PAL_OUT = BashOperator(task_id='CDE07_M_X_PAL_OUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_OUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_OUT.py RBS CDE07_M_X_PAL_OUT CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_PAL_SBL_SCL = BashOperator(task_id='CDE07_M_X_PAL_SBL_SCL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_SBL_SCL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_SBL_SCL.py RBS CDE07_M_X_PAL_SBL_SCL CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_PAL_SEMI_BANK = BashOperator(task_id='CDE07_M_X_PAL_SEMI_BANK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_SEMI_BANK')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_SEMI_BANK.py RBS CDE07_M_X_PAL_SEMI_BANK CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_PAL_VLD = BashOperator(task_id='CDE07_M_X_PAL_VLD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_VLD')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_VLD.py RBS CDE07_M_X_PAL_VLD CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)
CDE07_M_X_SEMI_POLICY = BashOperator(task_id='CDE07_M_X_SEMI_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_SEMI_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_SEMI_POLICY.py RBS CDE07_M_X_SEMI_POLICY CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)
#CDE07_M_X_PAL_VOL_VAL = BashOperator(task_id='CDE07_M_X_PAL_VOL_VAL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PAL_VOL_VAL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PAL_VOL_VAL.py RBS CDE07_M_R_RISKMART_LOAD_FLOW -y,", dag=dag)

# added for [master flow sourcing check]
SOURCING_CHECK= BashOperator(task_id='SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE99_M_R_PAL_P1_LOGIC_FLOW_FBD -y,", dag=dag)
START.set_downstream(SOURCING_CHECK)
SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_M_R_PROBE_LOGIC)
SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_M_G_GURN_MASTER)
SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_M_R_BUS_LOGIC)
SOURCING_CHECK.set_downstream(DEPENDENCY_CDE04_R_SS_SCORECARD)

# START.set_downstream(DEPENDENCY_CHECK_M_R_PROBE_LOGIC)
# START.set_downstream(DEPENDENCY_CHECK_M_G_GURN_MASTER)
# START.set_downstream(DEPENDENCY_CHECK_M_R_BUS_LOGIC)
DEPENDENCY_CHECK_M_R_PROBE_LOGIC.set_downstream(CDE01_M_X_PAL_ACCOUNT_PREP)
DEPENDENCY_CHECK_M_R_BUS_LOGIC.set_downstream(CDE01_M_X_PAL_ACCOUNT_PREP)
DEPENDENCY_CHECK_M_G_GURN_MASTER.set_downstream(CDE01_M_X_PAL_ACCOUNT_PREP)
DEPENDENCY_CDE04_R_SS_SCORECARD.set_downstream(CDE01_M_X_PAL_ACCOUNT_PREP)

##DEPENDENCY_CHECK_M_R_BUS_LOGIC.set_downstream(subDag_cde04_m_r_pal_outputs_flow)

# CDER-4932 [Code Optimization] : Removing non functional task dependency 
# CDE01_M_X_PAL_FINAL_PREP.set_downstream(dag_start_pscore_flow)

# CDE03_M_C_PSCORE_POSTJOB.set_downstream(CDE03_M_C_PASSES_RECOMM)
# CDE03_M_C_PASSES_RECOMM.set_downstream(CDE01_M_X_SEMI_BANKED_POP_BRAND)

# CDER-4932 [Code Optimization] : Removing non functional task dependency : adding new dependencies
# CDE03_M_X_SEMI_BANKED_POL_SC_RECOMM.set_downstream(CDE04_M_C_PASSES_OUTPUT_MAPPER)
# CDE03_M_X_SEMI_BANKED_POL_SC_RECOMM.set_downstream(dag_start_pal_outputs)
# dag_start_pal_outputs.set_downstream(CDE04_M_C_PASSES_OUTPUT_MAPPER)

# CDER-4932 [Code Optimization] : calling jobs through a common sh script and adjusting dependencies :
CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW.set_downstream(CDE01_M_X_PAL_SCREEN_BUILD)
CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW.set_downstream(CDE05_M_X_PAL_VAL)
CDE02_M_X_PSCORE_PASSES_SEMI_BANKED_FLOW.set_downstream(CDE04_M_X_PAL_CUST_POWERCR)
# CDE04_M_C_PASSES_OUTPUT_MAPPER.set_downstream(CDE01_M_X_PAL_SCREEN_BUILD)
# CDE04_M_C_PASSES_OUTPUT_MAPPER.set_downstream(CDE05_M_X_PAL_VAL)

# CDER-4932 [Code Optimization] : Removing non functional task dependency : adding new dependencies
# CDE04_M_C_PASSES_OUTPUT_MAPPER.set_downstream(CDE04_M_X_PAL_CUST_POWERCR)
CDE04_M_X_PAL_CUST_POWERCR.set_downstream(dag_start_riskmart_load)
# CDE04_M_C_PASSES_OUTPUT_MAPPER.set_downstream(dag_start_powerc_cust_lvl)
# dag_start_powerc_cust_lvl.set_downstream(CDE04_M_X_PAL_CUST_POWERCR)	
# CDE04_M_X_PAL_CUST_POWERCR.set_downstream(dag_end_powerc_cust_lvl)
# dag_end_powerc_cust_lvl.set_downstream(dag_start_riskmart_load)

CDE01_M_X_PAL_SCREEN_BUILD.set_downstream(dag_start_riskmart_load)
CDE05_M_X_PAL_VAL.set_downstream(dag_start_riskmart_load)
dag_start_riskmart_load.set_downstream(CDE07_M_X_PAL_CC18_SCL)
dag_start_riskmart_load.set_downstream(CDE07_M_X_PAL_CC_SCL)
dag_start_riskmart_load.set_downstream(CDE07_M_X_PAL_FRL_SCL)
dag_start_riskmart_load.set_downstream(CDE07_M_X_PAL_MTA_SCL)
dag_start_riskmart_load.set_downstream(CDE07_M_X_PAL_INPUT)
dag_start_riskmart_load.set_downstream(CDE07_M_X_PAL_OUT)
dag_start_riskmart_load.set_downstream(CDE07_M_X_PAL_SBL_SCL)
dag_start_riskmart_load.set_downstream(CDE07_M_X_PAL_SEMI_BANK)
dag_start_riskmart_load.set_downstream(CDE07_M_X_PAL_VLD)
dag_start_riskmart_load.set_downstream(CDE07_M_X_SEMI_POLICY)
CDE07_M_X_PAL_CC18_SCL.set_downstream(dag_end_riskmart_load)
CDE07_M_X_PAL_CC_SCL.set_downstream(dag_end_riskmart_load)
CDE07_M_X_PAL_FRL_SCL.set_downstream(dag_end_riskmart_load)
CDE07_M_X_PAL_MTA_SCL.set_downstream(dag_end_riskmart_load)
CDE07_M_X_PAL_INPUT.set_downstream(dag_end_riskmart_load)
CDE07_M_X_PAL_OUT.set_downstream(dag_end_riskmart_load)
CDE07_M_X_PAL_SBL_SCL.set_downstream(dag_end_riskmart_load)
CDE07_M_X_PAL_SEMI_BANK.set_downstream(dag_end_riskmart_load)
CDE07_M_X_PAL_VLD.set_downstream(dag_end_riskmart_load)
CDE07_M_X_SEMI_POLICY.set_downstream(dag_end_riskmart_load)

# CDER-4932 [Code Optimization] : Removing non functional task dependency : adding new dependencies
dag_end_riskmart_load.set_downstream(END)
# dag_end_riskmart_load.set_downstream(dag_end_pal_outputs)
# dag_end_pal_outputs.set_downstream(END)

RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)