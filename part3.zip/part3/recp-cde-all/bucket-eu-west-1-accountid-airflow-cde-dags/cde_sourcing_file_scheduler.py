from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from airflow.utils.db import provide_session
from datetime import  date, datetime, time, timedelta
import airflow.settings
from airflow.models import DagModel
import boto3
import botocore.session 
import json
import yaml
#from smart_open import open

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"


default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"
dag_list_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/data_ingestion_dag_list.csv"
#dag_list_schedule_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/output_sourcing_flows.csv"
dag_list_enable_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/data_ingestion_dag_list_default_enable_same_day.csv"


DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	

SCHEDULER_FILE = BASE_PATH+DAG_CONFIG_DICT["SCHEDULER_SCRIPT"]
COPY_FILE = BASE_PATH+DAG_CONFIG_DICT["FILE_COPY_SCRIPT"]
UPDATE_BATCH_FILE = BASE_PATH+DAG_CONFIG_DICT["UPDATE_BATCH_SCRIPT"]
SCHEDULER_OUTPUT_YAML_FILE = BASE_PATH+DAG_CONFIG_DICT["SCHEDULER_OUTPUT_YAML_FILE"]
SCHEDULER_OUTPUT_FLOWS = BASE_PATH+DAG_CONFIG_DICT["SCHEDULER_OUTPUT_FLOWS"]

COPY_YAML_FILES_ENV = "COPY_YAML_FILES_PATH_"+cde_env
COPY_YAML_FILES_PATH = DAG_CONFIG_DICT[COPY_YAML_FILES_ENV]
COPY_SOURCING_FILES_ENV = "COPY_SOURCING_FLOWS_PATH_"+cde_env
COPY_SOURCING_FILES_PATH = DAG_CONFIG_DICT[COPY_SOURCING_FILES_ENV]

print('\n SCHEDULER_FILE'+SCHEDULER_FILE+'\n COPY_FILE'+COPY_FILE+'\n UPDATE_BATCH_FILE'+UPDATE_BATCH_FILE+'\n SCHEDULER_OUTPUT_YAML_FILE'+SCHEDULER_OUTPUT_YAML_FILE+'\n SCHEDULER_OUTPUT_FLOWS'+SCHEDULER_OUTPUT_FLOWS)
print('\n COPY_YAML_FILES_ENV'+COPY_YAML_FILES_ENV+'\n COPY_YAML_FILES_PATH'+COPY_YAML_FILES_PATH)
print('\n COPY_SOURCING_FILES_ENV'+COPY_SOURCING_FILES_ENV+'\n COPY_SOURCING_FILES_PATH'+COPY_SOURCING_FILES_PATH)

file = open(MASTER_IP,"r")
IP = file.read()
file.close

@provide_session
def disable_dags(session=None):
    print('Disable the Dags')
    dagList = read_s3_file(dag_list_file)     
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        if(len(dagItem) == 0):
            print("Empty")
        else :
            print(dagItem)
            qry = session.query(DagModel).filter(DagModel.dag_id == dagItem)
            d = qry.first()
            d.is_paused = True
            print('DAG disabled')
            session.commit()
    print('DAGS disabled')

@provide_session
def enable_dags(session=None):
    print('Enable the DAGS')    
    dagList = read_s3_file(dag_list_file)    
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        if(len(dagItem) == 0):
            print("Empty")
        else :
            print(dagItem)
            qry = session.query(DagModel).filter(DagModel.dag_id == dagItem)
            d = qry.first()
            d.is_paused = False
            print('DAG enabled')
            session.commit()
    print('DAGS enabled')	

'''@provide_session	
def enable_schedule_dags(session=None):
    print('Enable the Scheduled DAGS')    
    dagList = read_s3_file(dag_list_schedule_file)    
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        if(len(dagItem) == 0):
            print("Empty")
        else :
            print(dagItem)
            qry = session.query(DagModel).filter(DagModel.dag_id == dagItem)
            d = qry.first()
            d.is_paused = False
            print('DAG enabled')
            session.commit()
    print('Scheduled DAGS enabled')		'''
	
with DAG('CDE_SOURCING_FILE_SCHEDULER', description='CDE_SOURCING_FILE_SCHEDULER', default_args=default_args, schedule_interval="00 20 * * 0-6", catchup=False, max_active_runs=1) as dag:    
    disable_dags = PythonOperator(task_id='DISABLE_DAGS', retries=1, python_callable=disable_dags)
    set_permission = BashOperator(task_id='SET_PERMISSION' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sudo chown -R hadoop:hadoop /home/hadoop/cde", dag=dag)	
    generate_config = BashOperator(task_id='GENERATE_CONFIG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sudo spark-submit "+SCHEDULER_FILE+" "+SCHEDULER_OUTPUT_YAML_FILE+" "+SCHEDULER_OUTPUT_FLOWS+" -y,", dag=dag)
    copy_files =  BashOperator(task_id='COPY_FILES' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+COPY_FILE+" "+SCHEDULER_OUTPUT_YAML_FILE+" "+COPY_YAML_FILES_PATH+" "+SCHEDULER_OUTPUT_FLOWS+" "+COPY_SOURCING_FILES_PATH+" -y,", dag=dag)    
    update_batch =  BashOperator(task_id='UPDATE_BATCH' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+UPDATE_BATCH_FILE+" -y,", dag=dag)
    enable_dags	= PythonOperator(task_id='ENABLE_DAGS',  retries=1, python_callable=enable_dags)
    #enable_schedule_dags = PythonOperator(task_id='ENABLE_SCHEDULE_DAGS',  retries=1, python_callable=enable_schedule_dags)
    disable_dags.set_downstream(set_permission)	
    set_permission.set_downstream(generate_config)
    generate_config.set_downstream(copy_files)
    copy_files.set_downstream(update_batch)
    update_batch.set_downstream(enable_dags)    
    #enable_dags.set_downstream(enable_schedule_dags)