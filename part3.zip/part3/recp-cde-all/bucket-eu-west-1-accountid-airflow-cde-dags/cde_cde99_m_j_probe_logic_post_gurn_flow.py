from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from datetime import date, datetime, time, timedelta
import os
import sys
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
from airflow.operators.subdag_operator import SubDagOperator
import boto3
import botocore.session 
import json
import yaml
from airflow.models.dagrun import DagRun
from airflow.models import Variable,XCom
from airflow.operators.http_operator import SimpleHttpOperator
import requests
from airflow.models import Connection
from airflow.utils.db import provide_session
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import exc

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]
CONCURRENCY_M_PROBE_LOGIC_FLOW = DAG_CONFIG_DICT["CONCURRENCY_M_PROBE_LOGIC_FLOW"]
FLOW_DEPENDENCY = BASE_PATH+DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	

SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]

CDE_CONTROL = DAG_CONFIG_DICT["CDE_CONTROL"]
TRANSFORMATION_LOC = "s3://bucket-eu-west-1-"+account_id+"-processed-data/transformation/cde"
script_loc="scripts/airflow/"
script_name="subflow_trigger.sh"


file = open(MASTER_IP,"r")
IP = file.read()
file.close

# Dependency Code check 
def call_dagbag(*op_args):
    flow_name = op_args[0]
    print('Check DAG '+str(flow_name))
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    
    dag_bag_list = dagbag.dags[flow_name] #dagid     
    call_status_check(dag_bag_list) # last dag state
   

def call_status_check(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_state = last_instance.get_state() # last dag state
        print('\n Last Execution state'+str(dag_state))

        if(str(dag_state) == 'success') :
            print ('Dependency Met')    
        else :
            print ('Dependency Not Met')
            call_wait(dag_bag_list)   
  
def call_wait(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(300)    # Sleep
    call_status_check(dag_bag_list)

def call_dagbag_subdag(*op_args):
    dag_name = op_args[0]
    print('Check DAG '+str(dag_name))	
    dag_name_arr = dag_name.split(".")
    master_dag = dag_name_arr[0]
    
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    

    master_dag_bag_list = dagbag.dags[master_dag] #dagid     
    check_dag_status(master_dag_bag_list,dag_name,dagbag) # last dag state 		

def call_status_check_subdag(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run

    if last_instance is not None :   
        dag_state = last_instance.get_state() # last dag state
        exec_date_str = last_instance.execution_date
        execDate = exec_date_str.strftime("%Y-%m-%d")	
        print('\n Last Execution state of subFlow: '+str(dag_state)+" Execution Date: "+str(execDate))			
		
        now = datetime.now()		
        todayDate = now.strftime("%Y-%m-%d")		
        previous_date = now - timedelta(days=1)
        previousDay = previous_date.strftime("%Y-%m-%d")
				
        if(str(dag_state) == 'success') :
            if(execDate == previousDay or execDate == todayDate) :
                print ('Dependency Met')    
            else :
                call_wait_subdag(dag_bag_list)			
                print ('Dependency Not Met')	
            				
        else :
            print ('Dependency Not Met')
            call_wait_subdag(dag_bag_list)				
		
def check_dag_status(dag_bag_list,dag_name,dagbag) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_status = last_instance.get_state() # last dag state
        if(str(dag_status) == 'success') :
            print ('Dependency Met') 
        else  :	
            print('\n Dependent Master flow is either in Running state or Failed state')
            sub_dag_bag_list = dagbag.dags[dag_name] #dagid     
            call_status_check_subdag(sub_dag_bag_list)  

def call_wait_subdag(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(300)    # Sleep
    call_status_check_subdag(dag_bag_list)		
	
flow_name="CDE99_M_J_PROBE_LOGIC_POST_GURN_FLOW"
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]
	
cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name	
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key] 
    return str(polling_time)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val

json_bucket = "bucket-eu-west-1-"+account_id+"-risk-cicd"
json_file = "cde/dags/config/" + "token.json"	

def read_file_from_s3(bucket, filename):
	s3 = boto3.resource('s3')
	obj = s3.Object(bucket, filename)
	return obj.get()['Body'].read()
	
file_content = read_file_from_s3(json_bucket, json_file)

json_content = json.loads(str(file_content, 'utf-8'))
	
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,2),
    'end_date': datetime(2099,12,31),
}

dag = DAG('CDE99_M_J_PROBE_LOGIC_POST_GURN_FLOW' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1)

#EXECUTE_MODEL = PythonOperator(task_id = "EXECUTE_MODEL",
#                                     python_callable=get_response,
#									 op_kwargs={'url': execute_url, 'encoded_data': encoded_data, 'headers': headers, 'secret_name': secret_name, 'region_name': region_name},
#                                     dag=dag)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
	
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)

# Commneting subflows and adding additional sourcing check

#NPROBESM_SOURCING_CHECK= BashOperator(task_id='NPROBESM_SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE99_M_J_PROBE_LOGIC_POST_GURN_NPROBESM_SUBFLOW -y,", dag=dag)

# subDag_jubuk_probe_nprobesm_result = SubDagOperator(
# subdag=child_dag_jubuk_probe_nprobesm_result('CDE99_M_J_PROBE_LOGIC_POST_GURN_FLOW', 'JUBUK_PROBE_NPROBESM_RESULT', default_args, dag.schedule_interval),
# task_id='JUBUK_PROBE_NPROBESM_RESULT',
# default_args=default_args,
# dag=dag)

# subDag_jubuk_probe_nprobesm_feedback = SubDagOperator(
# subdag=child_dag_jubuk_probe_nprobesm_feedback('CDE99_M_J_PROBE_LOGIC_POST_GURN_FLOW', 'JUBUK_PROBE_NPROBESM_FEEDBACK', default_args, dag.schedule_interval),
# task_id='JUBUK_PROBE_NPROBESM_FEEDBACK',
# default_args=default_args,
# dag=dag)		


#CDER-5685
DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN= BashOperator(task_id='DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_J_PROBE_LOGIC_PRE_GURN_FLOW "+get_polling_time('CDE99_M_J_PROBE_LOGIC_PRE_GURN_FLOW')+" -y,", dag=dag)

START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE99_M_J_PROBE_LOGIC_POST_GURN_FLOW -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE99_M_J_PROBE_LOGIC_POST_GURN_FLOW -y,", dag=dag)

CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY = BashOperator(task_id='CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY')+" "+cmd_part+"\" "+JOB_PATH+"CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.py UBN CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY CDE99_M_J_PROBE_LOGIC_FLOW -y,", dag=dag)
CDE99_M_X_PRB_REMOVE_OK = BashOperator(task_id='CDE99_M_X_PRB_REMOVE_OK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE99_M_X_PRB_REMOVE_OK')+" "+cmd_part+"\" "+JOB_PATH+"CDE99_M_X_PRB_REMOVE_OK.py UBN CDE99_M_X_PRB_REMOVE_OK CDE99_M_J_PROBE_LOGIC_FLOW -y,", dag=dag)
#CDE06_M_X_PROBE_FBACK = BashOperator(task_id='CDE06_M_X_PROBE_FBACK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_PROBE_FBACK')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_PROBE_FBACK.py UBN CDE06_M_X_PROBE_FBACK CDE99_M_J_PROBE_LOGIC_FLOW -y,", dag=dag)
#CDE06_M_X_PROBE_RESULTS = BashOperator(task_id='CDE06_M_X_PROBE_RESULTS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_PROBE_RESULTS')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_PROBE_RESULTS.py UBN CDE06_M_X_PROBE_RESULTS CDE99_M_J_PROBE_LOGIC_FLOW -y,", dag=dag)


#CDE01_M_J_CUST_POLICY_FLOW 
CDE01_M_X_CUSTOMER_POLICY = BashOperator(task_id='CDE01_M_X_CUSTOMER_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+JOB_PATH+"CDE01_M_X_CUSTOMER_POLICY.py UBN CDE01_M_X_CUSTOMER_POLICY CDE01_M_J_CUST_POLICY_FLOW -y,", dag=dag)
# commented for code tuning - running jobs through sh script, single task
# CDE01_M_X_PRIORITISE_POLICY = BashOperator(task_id='CDE01_M_X_PRIORITISE_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+JOB_PATH+"CDE01_M_X_PRIORITISE_POLICY.py UBN CDE01_M_X_PRIORITISE_POLICY CDE01_M_J_CUST_POLICY_FLOW -y,", dag=dag)

#CDER-5685
DEPENDENCY_CHECK_M_G_GURN_MASTER= BashOperator(task_id='DEPENDENCY_CHECK_M_G_GURN_MASTER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_G_GURN_MASTER_FLOW "+get_polling_time('CDE99_M_G_GURN_MASTER_FLOW')+" -y,", dag=dag)

# added for [master flow sourcing check]
SOURCING_CHECK= BashOperator(task_id='SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE99_M_J_PROBE_LOGIC_POST_GURN_FLOW -y,", dag=dag)
START.set_downstream(SOURCING_CHECK)
SOURCING_CHECK.set_downstream(DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN)# START.set_downstream(DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN)


# commented and added for code tuning - running jobs through sh script, single task
CDE02_M_X_PRB_RECOD_APS_AOD_FLOW = BashOperator(task_id='CDE02_M_X_PRB_RECOD_APS_AOD_FLOW' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ BASE_PATH+script_loc+script_name+" "+JOB_PATH+" UBN CDE02_M_J_PRB_RECOD_APS_AOD_FLOW "+BASE_PATH+script_loc+"CDE02_M_PRB_RECOD_APS_AOD_FLOW.ini"+" " +TRANSFORMATION_LOC+" "+CDE_CONTROL+" -y,", dag=dag)
DEPENDENCY_CHECK_M_G_GURN_MASTER.set_downstream(CDE02_M_X_PRB_RECOD_APS_AOD_FLOW)
CDE01_M_X_CUSTOMER_POLICY.set_downstream(CDE02_M_X_PRB_RECOD_APS_AOD_FLOW)
CDE04_M_X_CLOSED_ACC_POP = BashOperator(task_id='CDE04_M_X_CLOSED_ACC_POP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_X_CLOSED_ACC_POP')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_X_CLOSED_ACC_POP.py UBN CDE04_M_X_CLOSED_ACC_POP CDE04_M_N_OUTPUT_MAP_FLOW -y,", dag=dag)

#CDE04_M_X_CLOSED_ACC_RESULTS = BashOperator(task_id='CDE04_M_X_CLOSED_ACC_RESULTS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_X_CLOSED_ACC_RESULTS')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_X_CLOSED_ACC_RESULTS.py UBN CDE04_M_X_CLOSED_ACC_RESULTS CDE04_M_J_OUTPUT_MAP_FLOW -y,", dag=dag)
#CDE04_M_X_CLOSED_ACC_FEEDBACK = BashOperator(task_id='CDE04_M_X_CLOSED_ACC_FEEDBACK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_X_CLOSED_ACC_FEEDBACK')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_X_CLOSED_ACC_FEEDBACK.py UBN CDE04_M_X_CLOSED_ACC_FEEDBACK CDE04_M_J_OUTPUT_MAP_FLOW -y,", dag=dag)

# DEPENDENCY_CHECK_M_G_GURN_MASTER.set_downstream(CDE01_M_X_PRIORITISE_POLICY)

# CDE01_M_X_CUSTOMER_POLICY.set_downstream(CDE01_M_X_PRIORITISE_POLICY)


#DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN.set_downstream(CDE01_M_X_CUSTOMER_POLICY)	
DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN.set_downstream(DEPENDENCY_CHECK_M_G_GURN_MASTER)	

#CDE02_M_J_PRB_RECOD_FLOW
	
#CDE01_M_X_PROBE_BESTAC_COMBINED = BashOperator(task_id='CDE01_M_X_PROBE_BESTAC_COMBINED' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('XXXXXX')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PROBE_BESTAC_COMBINED.py UBN CDE02_M_J_PRB_RECOD_FLOW -y,", dag=dag)
# commented and added for code tuning - running jobs through sh script, single task

# CDE02_M_X_LIMIT_FACTORS = BashOperator(task_id='CDE02_M_X_LIMIT_FACTORS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_X_LIMIT_FACTORS')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_X_LIMIT_FACTORS.py UBN CDE02_M_X_LIMIT_FACTORS CDE02_M_J_PRB_RECOD_FLOW -y,", dag=dag)
# CDE02_M_X_PRB_RECOD = BashOperator(task_id='CDE02_M_X_PRB_RECOD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_X_PRB_RECOD')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_X_PRB_RECOD.py UBN CDE02_M_X_PRB_RECOD CDE02_M_J_PRB_RECOD_FLOW -y,", dag=dag)
# CDE02_M_X_PRIOR_PRB_RECOD = BashOperator(task_id='CDE02_M_X_PRIOR_PRB_RECOD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_X_PRIOR_PRB_RECOD')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_X_PRIOR_PRB_RECOD.py UBN CDE02_M_X_PRIOR_PRB_RECOD CDE02_M_J_PRB_RECOD_FLOW -y,", dag=dag)
# #CDE02_M_X_PRIOR_PRB_RECOD.set_downstream(CDE01_M_X_PROBE_BESTAC_COMBINED)
# CDE02_M_X_LIMIT_FACTORS.set_downstream(CDE02_M_X_PRB_RECOD)
# CDE02_M_X_PRB_RECOD.set_downstream(CDE02_M_X_PRIOR_PRB_RECOD)

# CDE01_M_X_PRIORITISE_POLICY.set_downstream(CDE02_M_X_LIMIT_FACTORS)

#CDE02_M_J_APS_FLOW
	
#CDE02_M_J_LIM = BashOperator(task_id='CDE02_M_J_LIM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('XXXXXX')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_J_LIM.py UBN CDE02_M_J_APS_FLOW -y,", dag=dag)
# commented and added for code tuning - running jobs through sh script, single task
# CDE02_M_X_EXCESS_COMB_LIMITS = BashOperator(task_id='CDE02_M_X_EXCESS_COMB_LIMITS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_X_EXCESS_COMB_LIMITS')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_X_EXCESS_COMB_LIMITS.py UBN CDE02_M_X_EXCESS_COMB_LIMITS CDE02_M_J_APS_FLOW -y,", dag=dag)
# CDE02_M_X_EXCESS_LIMITS = BashOperator(task_id='CDE02_M_X_EXCESS_LIMITS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_X_EXCESS_LIMITS')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_X_EXCESS_LIMITS.py UBN CDE02_M_X_EXCESS_LIMITS CDE02_M_J_APS_FLOW -y,", dag=dag)
# CDE02_M_X_EXCESS_LIM_UNS = BashOperator(task_id='CDE02_M_X_EXCESS_LIM_UNS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_X_EXCESS_LIM_UNS')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_X_EXCESS_LIM_UNS.py UBN CDE02_M_X_EXCESS_LIM_UNS CDE02_M_J_APS_FLOW -y,", dag=dag)
# CDE02_M_X_EXCESS_LIM_UNS.set_downstream(CDE02_M_X_EXCESS_LIMITS)
# CDE02_M_X_EXCESS_LIMITS.set_downstream(CDE02_M_X_EXCESS_COMB_LIMITS)

# CDE02_M_X_PRIOR_PRB_RECOD.set_downstream(CDE02_M_X_EXCESS_LIM_UNS)
#CDE02_M_J_LIM.set_downstream(CDE02_M_X_EXCESS_LIMITS)

#CDE02_M_J_AOD_FLOW
# commented and added for code tuning - running jobs through sh script, single task
# CDE02_M_X_AOD = BashOperator(task_id='CDE02_M_X_AOD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE02_M_X_AOD')+" "+cmd_part+"\" "+JOB_PATH+"CDE02_M_X_AOD.py UBN CDE02_M_X_AOD CDE02_M_J_AOD_FLOW -y,", dag=dag)

# CDE02_M_X_PRIOR_PRB_RECOD.set_downstream(CDE02_M_X_AOD)

#CDE04_M_J_OUTPUT_MAP_FLOW

##Dependency check for CMS scorecard [SDA]
DEPENDENCY_CMS_SCORECARD = BashOperator(task_id='DEPENDENCY_CMS_SCORECARD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE01_M_G_SDA_CMS_FLOW "+get_polling_time('CDE01_M_G_SDA_CMS_FLOW')+" -y,", dag=dag)

#CDE04_M_X_CLOSED_ACC_POP.set_downstream(DEPENDENCY_CMS_SCORECARD)
DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN.set_downstream(DEPENDENCY_CMS_SCORECARD)

CDE01_M_X_ACCOUNT_POLICY = BashOperator(task_id='CDE01_M_X_ACCOUNT_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_ACCOUNT_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_ACCOUNT_POLICY.py UBN CDE01_M_X_ACCOUNT_POLICY CDE99_M_J_PROBE_LOGIC_POST_GURN_FLOW -y,", dag=dag)

DEPENDENCY_CMS_SCORECARD.set_downstream(CDE01_M_X_ACCOUNT_POLICY)
CDE01_M_X_ACCOUNT_POLICY.set_downstream(CDE01_M_X_CUSTOMER_POLICY)

CDE01_M_X_PROBE_ACTIVE_WRITE = BashOperator(task_id='CDE01_M_X_PROBE_ACTIVE_WRITE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_X_PROBE_ACTIVE_WRITE')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_X_PROBE_ACTIVE_WRITE.py UBN CDE01_M_X_PROBE_ACTIVE_WRITE CDE04_M_J_OUTPUT_MAP_FLOW -y,", dag=dag)
#CDE04_M_X_PROBE_FBACK_MAP = BashOperator(task_id='CDE04_M_X_PROBE_FBACK_MAP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_X_PROBE_FBACK_MAP')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_X_PROBE_FBACK_MAP.py UBN CDE04_M_X_PROBE_FBACK_MAP CDE04_M_J_OUTPUT_MAP_FLOW -y,", dag=dag)
#CDE04_M_X_PROBE_RESULTS_MAP = BashOperator(task_id='CDE04_M_X_PROBE_RESULTS_MAP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_X_PROBE_RESULTS_MAP')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_X_PROBE_RESULTS_MAP.py UBN CDE04_M_X_PROBE_RESULTS_MAP CDE04_M_J_OUTPUT_MAP_FLOW -y,", dag=dag)
CDE04_M_X_PROBE_RESULTS = BashOperator(task_id='CDE04_M_X_PROBE_RESULTS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ BASE_PATH+script_loc+script_name+" "+JOB_PATH+" UBN CDE04_M_X_PROBE_RESULTS "+BASE_PATH+script_loc+"CDE04_M_X_PROBE_RESULTS.ini"+" " +TRANSFORMATION_LOC+" "+CDE_CONTROL+" -y,", dag=dag)
CDE04_M_X_PROBE_FBACK = BashOperator(task_id='CDE04_M_X_PROBE_FBACK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ BASE_PATH+script_loc+script_name+" "+JOB_PATH+" UBN CDE04_M_X_PROBE_FBACK "+BASE_PATH+script_loc+"CDE04_M_X_PROBE_FBACK.ini"+" " +TRANSFORMATION_LOC+" "+CDE_CONTROL+" -y,", dag=dag)
#CDE04_M_X_PROBE_RESULTS_MAP.set_downstream(CDE04_M_X_CLOSED_ACC_RESULTS)
#CDE04_M_X_PROBE_RESULTS_MAP.set_downstream(CDE04_M_X_PROBE_FBACK_MAP)
# commented and added for code tuning - running jobs through sh script, single task
CDE02_M_X_PRB_RECOD_APS_AOD_FLOW.set_downstream(CDE04_M_X_CLOSED_ACC_POP)
#CDE02_M_X_PRB_RECOD_APS_AOD_FLOW.set_downstream(CDE04_M_X_PROBE_RESULTS_MAP)
#CDE04_M_X_CLOSED_ACC_POP.set_downstream(CDE04_M_X_CLOSED_ACC_RESULTS)
#CDE04_M_X_CLOSED_ACC_POP.set_downstream(CDE04_M_X_PROBE_FBACK_MAP)
CDE04_M_X_CLOSED_ACC_POP.set_downstream(CDE04_M_X_PROBE_RESULTS)
#DEPENDENCY_CMS_SCORECARD.set_downstream(CDE04_M_X_PROBE_RESULTS)
CDE04_M_X_PROBE_RESULTS.set_downstream(CDE04_M_X_PROBE_FBACK)

#CDE04_M_X_CLOSED_ACC_RESULTS.set_downstream(CDE04_M_X_CLOSED_ACC_FEEDBACK)
#CDE04_M_X_CLOSED_ACC_RESULTS.set_downstream(CDE01_M_X_PROBE_ACTIVE_WRITE)
CDE04_M_X_PROBE_FBACK.set_downstream(CDE01_M_X_PROBE_ACTIVE_WRITE)

# CDE02_M_X_EXCESS_COMB_LIMITS.set_downstream(CDE04_M_X_PROBE_RESULTS_MAP)
# CDE02_M_X_AOD.set_downstream(CDE04_M_X_PROBE_RESULTS_MAP)

#CDE04_M_X_PROBE_FBACK_MAP.set_downstream(CDE01_M_X_PROBE_ACTIVE_WRITE)
CDE01_M_X_PROBE_ACTIVE_WRITE.set_downstream(CDE99_M_X_PRB_REMOVE_OK)

CDE01_M_X_PROBE_ACTIVE_WRITE.set_downstream(CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY)

#CDE04_M_X_PROBE_FBACK_MAP.set_downstream(CDE04_M_X_CLOSED_ACC_FEEDBACK)

#CDE04_M_X_CLOSED_ACC_FEEDBACK.set_downstream(CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY)

#CDE04_M_X_CLOSED_ACC_FEEDBACK.set_downstream(CDE99_M_X_PRB_REMOVE_OK)


#CDE05_M_J_PROBE_DIST_FLOW
# commented and added for code tuning - merge jobs 
CDE05_M_X_PROBE_DIST_FLOW = BashOperator(task_id='CDE05_M_X_PROBE_DIST_FLOW' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_PROBE_DIST_FLOW')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_PROBE_DIST_FLOW.py UBN CDE05_M_X_PROBE_DIST_FLOW CDE05_M_K_PROBE_DIST_FLOW -y,", dag=dag)
TRIGGER_SS_SCORECARD = TriggerDagRunOperator(task_id='TRIGGER_SS_SCORECARD',
                                 trigger_dag_id='CDE04_SS_SCORECARD_CLASSIFICATION_J_FLOW',
                                 dag=dag)

##Trigger DAG for CL22 scorecard [SDA]
TRIGGER_CL22_SCORECARD = TriggerDagRunOperator(task_id='TRIGGER_CL22_SCORECARD',
                                 trigger_dag_id='CDE04_SDA_CL22_J_FLOW',
                                 dag=dag)

CDE01_M_X_PROBE_ACTIVE_WRITE.set_downstream(CDE05_M_X_PROBE_DIST_FLOW)
#CDE04_M_X_CLOSED_ACC_FEEDBACK.set_downstream(CDE05_M_X_PROBE_DIST_FLOW)
CDE05_M_X_PROBE_DIST_FLOW.set_downstream(TRIGGER_SS_SCORECARD)

TRIGGER_SS_SCORECARD.set_downstream(END)

CDE05_M_X_PROBE_DIST_FLOW.set_downstream(TRIGGER_CL22_SCORECARD)
TRIGGER_CL22_SCORECARD.set_downstream(END)

# CDE05_M_X_LIM_PRB_DIST  = BashOperator(task_id='CDE05_M_X_LIM_PRB_DIST' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_LIM_PRB_DIST')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_LIM_PRB_DIST.py UBN CDE05_M_X_LIM_PRB_DIST CDE05_M_J_PROBE_DIST_FLOW -y,", dag=dag)
# CDE05_M_X_LIM_PRB_SWAPS  = BashOperator(task_id='CDE05_M_X_LIM_PRB_SWAPS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE05_M_X_LIM_PRB_SWAPS')+" "+cmd_part+"\" "+JOB_PATH+"CDE05_M_X_LIM_PRB_SWAPS.py UBN CDE05_M_X_LIM_PRB_SWAPS CDE05_M_J_PROBE_DIST_FLOW -y,", dag=dag)

# CDE05_M_X_LIM_PRB_DIST.set_downstream(CDE05_M_X_LIM_PRB_SWAPS)
# CDE01_M_X_PROBE_ACTIVE_WRITE.set_downstream(CDE05_M_X_LIM_PRB_DIST)
# CDE04_M_X_PROBE_FBACK_MAP.set_downstream(CDE05_M_X_LIM_PRB_DIST)

#CDE03_M_J_ML01_FLOW
# commented and added for code tuning - merge jobs 
#CDE03_M_X_ML01_FLOW = BashOperator(task_id='CDE03_M_X_ML01_FLOW' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_X_ML01_FLOW')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_X_ML01_FLOW.py UBN CDE03_M_X_ML01_FLOW CDE03_M_J_ML01_FLOW -y,", dag=dag)
#CDE01_M_X_PROBE_ACTIVE_WRITE.set_downstream(CDE03_M_X_ML01_FLOW)
#CDE04_M_X_PROBE_FBACK_MAP.set_downstream(CDE03_M_X_ML01_FLOW)
#CDE03_M_X_ML01_FLOW.set_downstream(EXECUTE_MODEL)
#EXECUTE_MODEL.set_downstream(END)

# CDE03_M_X_ML01_INPUT  = BashOperator(task_id='CDE03_M_X_ML01_INPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE03_M_X_ML01_INPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE03_M_X_ML01_INPUT.py UBN CDE03_M_X_ML01_INPUT CDE03_M_J_ML01_FLOW -y,", dag=dag)
# CDE07_M_X_ML01_INPUT  = BashOperator(task_id='CDE07_M_X_ML01_INPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_ML01_INPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_ML01_INPUT.py UBN CDE07_M_X_ML01_INPUT CDE03_M_J_ML01_FLOW -y,", dag=dag)

# CDE03_M_X_ML01_INPUT.set_downstream(CDE07_M_X_ML01_INPUT)
# CDE01_M_X_PROBE_ACTIVE_WRITE.set_downstream(CDE03_M_X_ML01_INPUT)
# CDE04_M_X_PROBE_FBACK_MAP.set_downstream(CDE03_M_X_ML01_INPUT)

#JUBUK_PROBE_NPROBESM_FEEDBACK 
# adjusting dependencies for removed subflows
#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(NPROBESM_SOURCING_CHECK)
#NPROBESM_SOURCING_CHECK.set_downstream(CDE06_M_X_PROBE_RESULTS)
#NPROBESM_SOURCING_CHECK.set_downstream(CDE06_M_X_PROBE_FBACK)

# CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(subDag_jubuk_probe_nprobesm_result)
# subDag_jubuk_probe_nprobesm_result
#JUBUK_PROBE_NPROBESM_RESULT 
# CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(subDag_jubuk_probe_nprobesm_feedback)

# subDag_jubuk_probe_nprobesm_feedback.set_downstream(CDE06_M_X_PROBE_FBACK)
# subDag_jubuk_probe_nprobesm_result.set_downstream(CDE06_M_X_PROBE_RESULTS)
CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE99_M_X_PRB_REMOVE_OK)
#CDE07_M_J_PRB_RMART_LOAD_FLOW 

#CDE07_M_X_PRB_INPUT = BashOperator(task_id='CDE07_M_X_PRB_INPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PRB_INPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PRB_INPUT.py UBN CDE07_M_X_PRB_INPUT CDE07_M_J_PRB_RMART_LOAD_FLOW -y,", dag=dag)
#CDE07_M_X_CUST_POLICY = BashOperator(task_id='CDE07_M_X_CUST_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_CUST_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_CUST_POLICY.py UBN CDE07_M_X_CUST_POLICY CDE07_M_J_PRB_RMART_LOAD_FLOW -y,", dag=dag)
#CDE07_M_X_PRTY_POLICY = BashOperator(task_id='CDE07_M_X_PRTY_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PRTY_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PRTY_POLICY.py UBN CDE07_M_X_PRTY_POLICY CDE07_M_J_PRB_RMART_LOAD_FLOW -y,", dag=dag)
#CDE07_M_X_PRB_OUT = BashOperator(task_id='CDE07_M_X_PRB_OUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PRB_OUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PRB_OUT.py UBN CDE07_M_X_PRB_OUT CDE07_M_J_PRB_RMART_LOAD_FLOW -y,", dag=dag)
#CDE07_M_X_PRB_INS_SCL = BashOperator(task_id='CDE07_M_X_PRB_INS_SCL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PRB_INS_SCL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PRB_INS_SCL.py UBN CDE07_M_X_PRB_INS_SCL CDE07_M_J_PRB_RMART_LOAD_FLOW -y,", dag=dag)
#CDE07_M_X_PRB_EAR_SCL = BashOperator(task_id='CDE07_M_X_PRB_EAR_SCL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PRB_EAR_SCL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PRB_EAR_SCL.py UBN CDE07_M_X_PRB_EAR_SCL CDE07_M_J_PRB_RMART_LOAD_FLOW -y,", dag=dag)
#CDE07_M_X_PRB_CDE_SCL = BashOperator(task_id='CDE07_M_X_PRB_CDE_SCL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PRB_CDE_SCL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PRB_CDE_SCL.py UBN CDE07_M_X_PRB_CDE_SCL CDE07_M_J_PRB_RMART_LOAD_FLOW -y,", dag=dag)
#CDE07_M_X_PRB_BEH_SCL = BashOperator(task_id='CDE07_M_X_PRB_BEH_SCL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PRB_BEH_SCL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PRB_BEH_SCL.py UBN CDE07_M_X_PRB_BEH_SCL CDE07_M_J_PRB_RMART_LOAD_FLOW -y,", dag=dag)
#CDE07_M_X_PRB_AOD = BashOperator(task_id='CDE07_M_X_PRB_AOD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PRB_AOD')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PRB_AOD.py UBN CDE07_M_X_PRB_AOD CDE07_M_J_PRB_RMART_LOAD_FLOW -y,", dag=dag)
#CDE07_M_X_ACCT_POLICY = BashOperator(task_id='CDE07_M_X_ACCT_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_ACCT_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_ACCT_POLICY.py UBN CDE07_M_X_ACCT_POLICY CDE07_M_J_PRB_RMART_LOAD_FLOW -y,", dag=dag)

#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE07_M_X_PRB_INPUT)
#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE07_M_X_CUST_POLICY)	
#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE07_M_X_ACCT_POLICY)
#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE07_M_X_PRB_AOD)
#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE07_M_X_PRB_OUT)
#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE07_M_X_PRB_INS_SCL)
#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE07_M_X_PRB_EAR_SCL)
#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE07_M_X_PRB_CDE_SCL)
#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE07_M_X_PRB_BEH_SCL)
#CDE99_M_X_PRB_CREATE_TRIGGER_ENTRY.set_downstream(CDE07_M_X_PRTY_POLICY)

# commented for code tuning - merge jobs tasks
# CDE05_M_X_LIM_PRB_SWAPS.set_downstream(END)
# CDE07_M_X_ML01_INPUT.set_downstream(END)
#CDE07_M_X_ACCT_POLICY.set_downstream(END)
#CDE07_M_X_PRB_AOD.set_downstream(END)
#CDE07_M_X_PRB_OUT.set_downstream(END)
#CDE07_M_X_PRB_INS_SCL.set_downstream(END)
#CDE07_M_X_PRB_EAR_SCL.set_downstream(END)
#CDE07_M_X_PRB_CDE_SCL.set_downstream(END)
#CDE07_M_X_PRB_BEH_SCL.set_downstream(END)
#CDE07_M_X_PRTY_POLICY.set_downstream(END)
#CDE07_M_X_PRB_INPUT.set_downstream(END)
#CDE07_M_X_CUST_POLICY.set_downstream(END)
#CDE06_M_X_PROBE_FBACK.set_downstream(END)
#CDE06_M_X_PROBE_RESULTS.set_downstream(END)
CDE99_M_X_PRB_REMOVE_OK.set_downstream(END)
RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)
