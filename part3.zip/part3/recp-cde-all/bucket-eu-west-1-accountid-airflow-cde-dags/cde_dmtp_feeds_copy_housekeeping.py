import json
import logging
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.utils.helpers import chain
from datetime import datetime, timedelta
import boto3

#######################################################################
AIRFLOW_FLOW_NAME='cde_dmtp_feeds_copy_housekeeping'
#######################################################################

default_args = {
    'owner': 'kaspp',
    'depends_on_past': False,
    'email': ['piotr.kasprowicz@rbs.co.uk'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'queue': 'sqs-airflow-cde',
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2021, 3, 1),
    'end_date': datetime(2099,12,31),
}

dag = DAG(AIRFLOW_FLOW_NAME, default_args=default_args, schedule_interval="0 10 * * 1-5", catchup=False)

### ARIFLOW DAG SETUP CODE ** END ###

### PORTION FOR DAG SUBMISSION START ####
s3 = boto3.client('s3')

### Get EMR key

KEY_FILE = "/usr/local/airflow/ssh/cde-emr-ec2-key.pem"

with open("/usr/local/airflow/ssh/cde-emr-ip.txt", "r") as dmo_emr_ip:
    IP = dmo_emr_ip.read()

### Get AWS Account ID

#Extract the AWS account id
with open('/usr/local/airflow/ssh/variables.json') as json_file:
    data = json.load(json_file) 
aws_account_id = data['AccountId']
json_file.close()

def check_for_holiday_files():
    import subprocess
    cmd = "ls -l /home/hadoop/dmo/ | awk '{print $9}'"
    running_status = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    return_list = running_status.communicate()[0].decode('utf-8').split()
    holiday_files = [f for f in return_list if f.split(".")[-1]=="OK"]
    holiday_brands = [f.split("_")[0] for f in holiday_files]
    return holiday_brands

prev_run_date = "{{ (dag_run.start_date-macros.dateutil.relativedelta.relativedelta(days=1)).strftime('%Y-%m-%d') }}"
run_date = "{{ (dag_run.start_date).strftime('%Y-%m-%d') }}"

### Task definition - one per brand

holidays_list = check_for_holiday_files()

SYNC_CODE = BashOperator(task_id='SYNC_CODE' , bash_command="ssh -o StrictHostKeyChecking=no -t -i "+KEY_FILE+" hadoop@" + IP + " sudo aws s3 sync s3://bucket-eu-west-1-{AWS_ACCOUNT_ID}-risk-cicd/cde/code/DMTP/release_dmtp_data_sourcing_1.0 /home/hadoop/dmo ".format(AWS_ACCOUNT_ID=aws_account_id), dag=dag)
HOLIDAY_CHECK = BashOperator(task_id='HOLIDAY_CHECK' , bash_command="ssh -o StrictHostKeyChecking=no -t -i "+KEY_FILE+" hadoop@" + IP + " spark-submit -v --executor-memory=500m --driver-memory=500m --conf spark.executor.memoryOverhead=100m --conf spark.executor.cores=1 --conf spark.driver.memoryOverhead=100m --conf spark.dynamicAllocation.initialExecutors=1 --conf spark.dynamicAllocation.minExecutors=1 --conf spark.executor.instances=1 --conf spark.dynamicAllocation.maxExecutors=1 --conf spark.default.parallelism=10 --conf spark.sql.shuffle.partitions=10 /home/hadoop/dmo/scripts/feeds_copy_housekeeping.py {aws_account_id} {run_date} ".format(aws_account_id=aws_account_id,prev_run_date=prev_run_date, run_date=run_date), dag=dag)
FEEDS_COPY_HOUSEKEEPING = BashOperator(task_id='FEEDS_COPY_HOUSEKEEPING' , bash_command="ssh -o StrictHostKeyChecking=no -t -i "+KEY_FILE+" hadoop@" + IP + " sh /home/hadoop/dmo/scripts/feeds_copy_housekeeping.sh {aws_account_id} {prev_run_date} ".format(aws_account_id=aws_account_id,prev_run_date=prev_run_date, run_date=run_date), dag=dag)

### Tasks flow

SYNC_CODE >> HOLIDAY_CHECK
HOLIDAY_CHECK >> FEEDS_COPY_HOUSEKEEPING