try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO
import botocore.session # pylint: disable=import-error
from os.path import join, abspath
import traceback
from collections import namedtuple
import yaml
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from airflow.operators.python_operator import BranchPythonOperator
import os
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
import boto3
import botocore.session 
import json
import yaml
import os



SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date':  datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)
flow_name='CDE_TRANSFER_PROD_POST_ETL_DATA_TO_PREPROD'

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"
LANDING_ZONE = "s3://bucket-eu-west-1-"+account_id+"-landing-zone/data-in/cde"
TRANSFORMATION_LOC = "s3://bucket-eu-west-1-"+account_id+"-processed-data/transformation/cde"
PRESENTATION_LOC = "s3://bucket-eu-west-1-"+account_id+"-processed-data/presentation/cde"
LANDING_BUCKET="s3://bucket-eu-west-1-"+account_id+"-landing-zone"

DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
ENV = DAG_CONFIG_DICT["CDE_ENV"]
dag_job_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
DAG_JOB_CONFIG_FILE = read_s3_file(dag_job_config_yaml_path)
DAG_JOB_CONFIG_DICT = yaml.safe_load(DAG_JOB_CONFIG_FILE)
cde_env = DAG_JOB_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_JOB_CONFIG_DICT[BASE_PATH_ENV]
FLOW_DEPENDENCY = BASE_PATH+DAG_JOB_CONFIG_DICT["FLOW_DEPENDENCY"]

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name	
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key] 
    return str(polling_time)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param


script_loc="scripts/airflow/"
job_loc="batch-framework/teradata-migration/"
job_name="transfer_prod_data_to_preprod.sh"
athena_script="athena_data_trasfer_to_preprod.py"
data_transfer_job="transfer_cde_prod_data_to_preprod.sh"
data_transfer_cde_process_job="transfer_cde_process_prod_data_to_preprod.sh"
staging_rmart_transfer_job="staging_to_riskmart_load.py"
bac_Config_file_loc='batch-framework/teradata-migration/bac_layer_data_table_info.ini'
bac_data_transfer_job="transfer_prod_bac_data_to_preprod.sh"

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]
CDE_FILE_LOC=DAG_CONFIG_DICT["CDE_FILE_LOC"]
SOURCING_SCRIPT_PATH=DAG_CONFIG_DICT["SOURCING_SCRIPT_PATH"]
spark_config_param = DAG_CONFIG_DICT["SPARK_CONFIG_PARAM_3G"]

file = open(MASTER_IP,"r")
IP = file.read()
file.close

dag = DAG('CDE_TRANSFER_PROD_POST_ETL_DATA_TO_PREPROD' , default_args=default_args, schedule_interval='30 06 * * 1-6', catchup=False, max_active_runs=1)


CDE_PROCESS = BashOperator(task_id='CDE_PROCESS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+data_transfer_cde_process_job +" cde_process na na "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

CDE_PROCESS_AA = BashOperator(task_id='CDE_PROCESS_AA' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+data_transfer_cde_process_job +" cde_process.aa na na "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

CDE_PROCESS_AB = BashOperator(task_id='CDE_PROCESS_AB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+data_transfer_cde_process_job +" cde_process.ab na na "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

CDE_PROCESS_AC = BashOperator(task_id='CDE_PROCESS_AC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+data_transfer_cde_process_job +" cde_process.ac na na "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

TRANSFER_ATHENA_PROD_DATA_TO_PREPROD = BashOperator(task_id='TRANSFER_ATHENA_PROD_DATA_TO_PREPROD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param+" "+ CDE_FILE_LOC+ job_loc + athena_script +" -y,", dag=dag)

RBS_BACKUP = BashOperator(task_id='RBS_BACKUP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+data_transfer_job +" cde_bod_rbs cde_bod_rbs_m cde_bop_batch_rbs "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

NWB_BACKUP = BashOperator(task_id='NWB_BACKUP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+data_transfer_job +" cde_bod_nwb cde_bod_nwb_m cde_bop_batch_nwb "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

JUBUK_BACKUP = BashOperator(task_id='JUBUK_BACKUP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+data_transfer_job +" cde_bod_jubuk cde_bod_jubuk_m cde_bop_batch_jubuk "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

KUBIE_BACKUP = BashOperator(task_id='KUBIE_BACKUP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+data_transfer_job +" cde_bod_kubie cde_bod_kubie_m cde_bop_batch_kubie "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

GRP_BACKUP = BashOperator(task_id='GRP_BACKUP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+data_transfer_job +" cde_bod_grp cde_bod_grp_m cde_bop_batch_grp "+TRANSFORMATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

#CDE_BAC_RISK_DECISIONING_MART = BashOperator(task_id='CDE_BAC_RISK_DECISIONING_MART' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+data_transfer_job +" cde_bac_risk_decisioning_mart na na "+PRESENTATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

CDE_BAC_RISK_DECISIONING_MART = BashOperator(task_id='CDE_BAC_RISK_DECISIONING_MART' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+bac_data_transfer_job +" "+bac_Config_file_loc+" "+CDE_FILE_LOC+" "+PRESENTATION_LOC+" "+LANDING_ZONE+" -y,", dag=dag)

STAGING_RMART_LOAD = BashOperator(task_id='STAGING_RMART_LOAD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('STAGING_RMART_LOAD')+" "+cmd_part+"\" "+CDE_FILE_LOC+script_loc+staging_rmart_transfer_job+" CDE_STAGING CDE_BAC_RISK_DECISIONING_MART -y,", dag=dag)

PROCESS_RMART_LOAD = BashOperator(task_id='PROCESS_RMART_LOAD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('PROCESS_RMART_LOAD')+" "+cmd_part+"\" "+CDE_FILE_LOC+script_loc+staging_rmart_transfer_job+" CDE_PROCESS CDE_BAC_RISK_DECISIONING_MART -y,", dag=dag)

STAGING_RMART_LOAD.set_downstream(PROCESS_RMART_LOAD)

CDE_PROCESS.set_downstream(CDE_PROCESS_AA)
CDE_PROCESS.set_downstream(CDE_PROCESS_AB)
CDE_PROCESS.set_downstream(CDE_PROCESS_AC)

def get_BucketNkey(input_loc):
    full_path = input_loc[5:]
    #print(full_path)
    bucket_name=full_path.split("/")[0]
    #print(bucket_name)
    full_path_list = full_path.split("/")
    key = ''
    len1 = len(full_path_list)
    k=1
    while k < len1 :
        #print(list_1[k])
        #print(k)
        key= key + "/" + full_path_list[k]
        k=k+1
    length = len(key)
    Key = key[1:length]
    myDict = {}
    myDict['bucket_name'] = Key
    return bucket_name,Key

import yaml
import boto3
import botocore
from botocore.session import Session

def readFile(bucket_name,key) :
    session = Session()
    client = session.create_client('s3')
    obj_dict = client.get_object(Bucket=bucket_name,Key=key)
    yaml_res= obj_dict['Body'].read().decode('utf-8')
    my_dict=yaml.safe_load(yaml_res)
    return my_dict

def get_brand(file_name):
    file_name=file_name.upper()
    if 'RBS_' in file_name or '_RBS' in file_name or '_R_' in file_name:
        return 'R'
    elif 'NWB_' in file_name or '_NWB' in file_name or '_N_' in file_name:
        return 'N'
    elif 'JUBUK_' in file_name or '_JUBUK' in file_name or 'UBN_' in file_name or '_UBN' in file_name or '_J_' in file_name:
        return 'J'
    elif 'KUBIE_' in file_name or '_KUBIE' in file_name or 'UBS_' in file_name or '_UBS' in file_name or 'UBR_' in file_name or '_UBR' in file_name or '_K_' in file_name:
        return 'K'
    elif 'GRP_' in file_name or '_GRP' in file_name or '_G_' in file_name:
        return 'G'
    else:
        return 'INVALID'

dep_config_file_loc = "s3://bucket-eu-west-1-{}-risk-cicd/cde/dags/config/dependency_daily.yaml".format(account_id)
bucket_name,key=get_BucketNkey(dep_config_file_loc)
ret_dict=readFile(bucket_name,key)
dependencies=ret_dict[flow_name]

dep_config_file_loc = "s3://bucket-eu-west-1-{}-risk-cicd/cde/dags/config/dependency_master.yaml".format(account_id)
bucket_name,key=get_BucketNkey(dep_config_file_loc)
ret_dict=readFile(bucket_name,key)
all_dep=ret_dict[flow_name]

#dependencies=['CDE99_D_K_PAL_LOGIC_FLOW','CDE99_D_R_PAL_LOGIC_FLOW']

# if len(dependencies)==0:
    # DEPENDENCY_CHECK_HOLIDAY_MISS = DummyOperator(
        # task_id='DEPENDENCY_CHECK_HOLIDAY_MISS',
        # dag=dag,)
    # # SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_HOLIDAY_MISS)
    # # DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(CDE04_D_G_BBCONNECT_EXT)
    # DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(RBS_BACKUP)
    # DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(NWB_BACKUP)
    # DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(JUBUK_BACKUP)
    # DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(GRP_BACKUP)
    # DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(KUBIE_BACKUP)
    # DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(CDE_BAC_RISK_DECISIONING_MART)
# else:
for dependency in dependencies:
    task_id_dth = "DEPENDENCY_CHECK_{}".format(dependency)
    task_dth= BashOperator(task_id=task_id_dth , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" "+dependency+" "+get_polling_time(dependency)+" -y,", dag=dag)
    # task_dth= BashOperator(task_id=task_id_dth , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" "+dependency+" "+get_polling_time(dependency)+" -y,", dag=dag)
    brnd=get_brand(dependency)
    if brnd=='R':
        task_dth.set_downstream(RBS_BACKUP)
    elif brnd=='N':
        task_dth.set_downstream(NWB_BACKUP)
    elif brnd=='J':
        task_dth.set_downstream(JUBUK_BACKUP)
    elif brnd=='K':
        task_dth.set_downstream(KUBIE_BACKUP)
    else:
        pass
    task_dth.set_downstream(GRP_BACKUP)
    task_dth.set_downstream(CDE_BAC_RISK_DECISIONING_MART)
for dep in all_dep:
    if dep not in dependencies:
        DEPENDENCY_CHECK_HOLIDAY_MISS = DummyOperator(
            task_id='DEPENDENCY_{}_HOLIDAY_MISS'.format(dep),
            dag=dag,)
        brnd=get_brand(dep)
        if brnd=='R':
            DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(RBS_BACKUP)
        elif brnd=='N':
            DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(NWB_BACKUP)
        elif brnd=='J':
            DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(JUBUK_BACKUP)
        elif brnd=='K':
            DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(KUBIE_BACKUP)
        else:
            pass
        DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(GRP_BACKUP)
        DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(CDE_BAC_RISK_DECISIONING_MART)
