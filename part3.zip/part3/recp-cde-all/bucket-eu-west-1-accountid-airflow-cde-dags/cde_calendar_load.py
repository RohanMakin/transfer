try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO
import botocore.session # pylint: disable=import-error
from os.path import join, abspath
import traceback
from collections import namedtuple

import yaml
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
import json
import os
import sys

START_DATE = datetime.now() - timedelta(minutes=1470)
SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': START_DATE,
    'end_date': datetime(2099,12,31),
}

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()
	
dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"

DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
#cde_year = datetime.now().strftime("%Y")
cde_year = DAG_CONFIG_DICT["CALENDAR_YEAR"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]

CALENDAR_BUSINESS_DAY_FILE = BASE_PATH+DAG_CONFIG_DICT["CALENDAR_BUSINESS_DAY_SCRIPT"]
CALENDAR_LAST_BUSINESS_DAY_FILE = BASE_PATH+DAG_CONFIG_DICT["CALENDAR_LAST_BUSINESS_DAY_SCRIPT"]

print('\n year'+cde_year+'\n CALENDAR_BUSINESS_DAY_FILE'+CALENDAR_BUSINESS_DAY_FILE+'\n CALENDAR_LAST_BUSINESS_DAY_FILE'+CALENDAR_LAST_BUSINESS_DAY_FILE)

file = open(MASTER_IP,"r")
IP = file.read()
file.close

dag = DAG('CDE_CALENDAR_LOAD' , default_args=default_args, schedule_interval=None, catchup=False, max_active_runs=1)

LOAD_BUSINESS_DAYS = BashOperator(task_id='LOAD_BUSINESS_DAYS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+CALENDAR_BUSINESS_DAY_FILE+" "+ cde_year +" -y,", dag=dag)
LOAD_LAST_BUSINESS_DAY = BashOperator(task_id='LOAD_LAST_BUSINESS_DAY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+CALENDAR_LAST_BUSINESS_DAY_FILE+" "+ cde_year +" -y,", dag=dag)

LOAD_BUSINESS_DAYS.set_downstream(LOAD_LAST_BUSINESS_DAY)


