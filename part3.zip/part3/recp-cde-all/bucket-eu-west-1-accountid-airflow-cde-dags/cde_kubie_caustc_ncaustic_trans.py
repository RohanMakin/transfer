try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO
import botocore.session # pylint: disable=import-error
from os.path import join, abspath
import traceback
from collections import namedtuple

import yaml
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 

import os
import sys
import json


SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

job_name="KUBIE_CAUSTC_NCAUSTIC_TRANS"



with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

sourcing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/sourcing_config.yaml"
dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"


DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]
POLLING_FILE = BASE_PATH+DAG_CONFIG_DICT["POLLING_FILE"]
POLLING_MULTI_FILE = BASE_PATH+DAG_CONFIG_DICT["POLLING_MULTI_FILE"]
LOG_STATUS_START = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_STATUS_END = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
SOURCING_SCRIPT_PATH = DAG_CONFIG_DICT["SOURCING_SCRIPT_PATH"]
LANDING_ZONE_ENV = "LANDING_ZONE_BUCKET_"+cde_env
LANDING_ZONE_BUCKET = DAG_CONFIG_DICT[LANDING_ZONE_ENV]
LANDING_ZONE_PATH = LANDING_ZONE_BUCKET+DAG_CONFIG_DICT["LANDING_ZONE_BUCKET_PATH"]
spark_config_param = DAG_CONFIG_DICT["SPARK_CONFIG_PARAM_1G"]

spark_config_param_gen = DAG_CONFIG_DICT["SPARK_CONFIG_PARAM_GEN"]

file = open(MASTER_IP,"r")
IP = file.read()
file.close

CONFIG_FILE = read_s3_file(sourcing_yaml_path)
CONFIG_DICT = yaml.safe_load(CONFIG_FILE)
staging_str = "STAGING_"+job_name
process_str = "PROCESS_"+job_name
file_str = "FILE_"+job_name
brand_str = "BRAND_"+job_name
schedule_str = "SCHEDULE_"+job_name

FEED_COUNT_CHECK_SCRIPT = BASE_PATH+SOURCING_SCRIPT_PATH+'cde_mainframe_split_feed_count_check.py'
STAGING_PATH = BASE_PATH+SOURCING_SCRIPT_PATH+CONFIG_DICT[staging_str]
PROCESS_PATH = BASE_PATH+SOURCING_SCRIPT_PATH+CONFIG_DICT[process_str]
FILE_NAME = CONFIG_DICT[file_str]
BRAND_NAME = CONFIG_DICT[brand_str]
SCHEDULE_INT = CONFIG_DICT[schedule_str]
LANDING_ZONE_FILE_NAME = LANDING_ZONE_PATH + FILE_NAME
SCHEDULE_INT = CONFIG_DICT[schedule_str]
LANDING_ZONE_FILE_NAME = LANDING_ZONE_PATH + FILE_NAME


print("\n ENV: "+cde_env+"\nPOLLING_FILE: "+POLLING_FILE+"\n STAGING_PATH: "+STAGING_PATH+"\n PROCESS_PATH: "+PROCESS_PATH+"\n FILE_NAME: "+LANDING_ZONE_FILE_NAME+"\n BRAND_NAME: "+BRAND_NAME+"\n SCHEDULE_INT: "+SCHEDULE_INT+"\n LOG_STATUS_END: "+LOG_STATUS_END)

dag = DAG('KUBIE_CAUSTC_NCAUSTIC_TRANS' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1)


FILE_STATUS_CHECK=BashOperator(task_id='FILE_STATUS_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ FEED_COUNT_CHECK_SCRIPT +" "+ job_name +" "+ FILE_NAME +" "+ BRAND_NAME +" -y,", dag=dag)
#FILE_POLLING = BashOperator(task_id='FILE_POLLING' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+ POLLING_FILE+" "+ job_name +" "+ LANDING_ZONE_FILE_NAME +" -y,", dag=dag)
STAGING_LAYER_LOAD = BashOperator(task_id='STAGING_LAYER_LOAD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param+" "+ STAGING_PATH +" "+ job_name +" "+ FILE_NAME +" "+ BRAND_NAME +" -y,", dag=dag)
PROCESS_LAYER_LOAD = BashOperator(task_id='PROCESS_LAYER_LOAD' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param+" "+ PROCESS_PATH +" "+ job_name +" "+ FILE_NAME +" "+ BRAND_NAME +" -y,", dag=dag)
LOG_STATUS= BashOperator(task_id='LOG_STATUS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " spark-submit "+spark_config_param_gen+" "+LOG_STATUS_END+" "+ job_name +" -y,", dag=dag)

FILE_STATUS_CHECK.set_downstream(STAGING_LAYER_LOAD)
STAGING_LAYER_LOAD.set_downstream(PROCESS_LAYER_LOAD)
PROCESS_LAYER_LOAD.set_downstream(LOG_STATUS)

