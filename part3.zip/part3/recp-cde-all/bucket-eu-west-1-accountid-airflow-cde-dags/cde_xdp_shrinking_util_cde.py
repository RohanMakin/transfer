from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from datetime import date, datetime, time, timedelta
from airflow.utils.decorators import apply_defaults
from os.path import join, abspath
import os
from airflow import DAG
# from airflow.operators import SimpleHttpOperator, HttpSensor,   BashOperator, EmailOperator, S3KeySensor
from datetime import datetime, timedelta
#import settings as st
import glob
from datetime import date, datetime, time, timedelta
import random
import yaml
import botocore
import airflow
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import BranchPythonOperator
import json
from botocore.session import Session
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow import configuration as conf
from airflow.models import DagBag, TaskInstance
from botocore.exceptions import ClientError, ParamValidationError
from airflow.utils.state import State
from airflow.utils.trigger_rule import TriggerRule


#START_DATE = datetime.now() - timedelta(minutes=10)
START_DATE = datetime(2019, 10, 12, hour=10,minute=30)

args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'queue': 'sqs-airflow-cde',
    'retry_delay': timedelta(minutes=1),
    'start_date': START_DATE,
    'end_date': datetime(2099,12,31),
    'max_active_runs' : 1 ,
    'concurrency' : 1,
}



with open('/usr/local/airflow/ssh/variables.json') as json_file:
    data = json.load(json_file) 
account_id = data['AccountId']
json_file.close()

DAG_NAME = "XDP_Shrink_util_cde"

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

dag_job_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
DAG_JOB_CONFIG_FILE = read_s3_file(dag_job_config_yaml_path)
DAG_JOB_CONFIG_DICT = yaml.safe_load(DAG_JOB_CONFIG_FILE)
cde_env = DAG_JOB_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
EMR_LOCAL_PATH = DAG_JOB_CONFIG_DICT[BASE_PATH_ENV]
MASTER_IP_FILE = DAG_JOB_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_JOB_CONFIG_DICT["KEY_FILE"]

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
ENV = DAG_CONFIG_DICT["CDE_ENV"]
TRANSFORMATION_LOC=DAG_CONFIG_DICT["TRANSFORMATION_LOC_"+ENV]
PRESENTATION_LOC=DAG_CONFIG_DICT["PRESENTATION_LOC_"+ENV]
CDE_HIVE_LOC=DAG_CONFIG_DICT["CDE_HIVE_LOC"]
SOURCING_SCRIPT_PATH=DAG_CONFIG_DICT["SOURCING_SCRIPT_PATH"]
ACS_EDW_TIER1 = DAG_CONFIG_DICT["ACS_EDW_TIER1"]
#CDE_PROCESS = DAG_CONFIG_DICT["CDE_PROCESS"]
CDE_CONTROL = DAG_CONFIG_DICT["CDE_CONTROL"]
CONTROL = DAG_CONFIG_DICT["CONTROL"]
BOP_CDE_BATCH_GRP = DAG_CONFIG_DICT["BOP_CDE_BATCH_GRP"]
BOP_CDE_BATCH_RBS = DAG_CONFIG_DICT["BOP_CDE_BATCH_RBS"]
BOP_CDE_BATCH_NWB = DAG_CONFIG_DICT["BOP_CDE_BATCH_NWB"]
BOP_CDE_BATCH_JUBUK = DAG_CONFIG_DICT["BOP_CDE_BATCH_JUBUK"]
BOP_CDE_BATCH_KUBIE = DAG_CONFIG_DICT["BOP_CDE_BATCH_KUBIE"]
BOD_CDE_GRP = DAG_CONFIG_DICT["BOD_CDE_GRP"]
BOD_CDE_RBS = DAG_CONFIG_DICT["BOD_CDE_RBS"]
BOD_CDE_NWB = DAG_CONFIG_DICT["BOD_CDE_NWB"]
BOD_CDE_JUBUK = DAG_CONFIG_DICT["BOD_CDE_JUBUK"]
BOD_CDE_KUBIE = DAG_CONFIG_DICT["BOD_CDE_KUBIE"]
BOD_CDE_GRP_M = DAG_CONFIG_DICT["BOD_CDE_GRP_M"]
BOD_CDE_RBS_M = DAG_CONFIG_DICT["BOD_CDE_RBS_M"]
BOD_CDE_NWB_M = DAG_CONFIG_DICT["BOD_CDE_NWB_M"]
BOD_CDE_JUBUK_M = DAG_CONFIG_DICT["BOD_CDE_JUBUK_M"]
BOD_CDE_KUBIE_M = DAG_CONFIG_DICT["BOD_CDE_KUBIE_M"]
BAC_RISK_DECISIONING_MART = DAG_CONFIG_DICT["BAC_RISK_DECISIONING_MART"]

dag = DAG(
    dag_id=DAG_NAME,
    default_args=args,
    catchup=False,
    schedule_interval=DAG_JOB_CONFIG_DICT["SHRINK_DATA_DAG_SCHEDULE"]
)

MASTER_IP = open(MASTER_IP_FILE,"r").read()
STATIC_CONFIG = ''
AIRFLOW_CONFIG = ''



DAG_LOCAL_PATH = '/usr/local/airflow/dags/'

SSH_COMMAND = "ssh -o StrictHostKeyChecking=no -t -i {key} hadoop@{master_ip} ".format(key=KEY_FILE, master_ip=MASTER_IP)
SPARK_ARGS = {
    'app': 'Framework',
    'argument':'spark-submit -v --executor-memory=6g --executor-cores=2  --driver-memory=3g --conf spark.executor.memoryOverhead=300m  --conf spark.executor.cores=2 --conf spark.driver.memoryOverhead=300m --conf spark.dynamicAllocation.initialExecutors=2  --conf spark.dynamicAllocation.minExecutors=2   --conf  spark.executor.instances=2    --conf spark.dynamicAllocation.maxExecutors=5  --conf spark.default.parallelism=20  --conf spark.sql.shuffle.partitions=20  --conf spark.serializer=org.apache.spark.serializer.KryoSerializer --conf spark.sql.sources.commitProtocolClass=org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol'
    }


arg_spark = '{}'.format(str(SPARK_ARGS['argument']))

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'
SPARK_SUBMIT_COMMAND = SSH_COMMAND + "\"{arg_sparks} {cmd_part} {emr_lcl}\"".format(arg_sparks = arg_spark, cmd_part = cmd_part, emr_lcl=EMR_LOCAL_PATH)
SHELL_COMMAND = SSH_COMMAND + "sudo sh {emr_lcl}".format(emr_lcl=EMR_LOCAL_PATH)
#first_task =  dag start  


dag_start_op_0 = DummyOperator(
    task_id='START',
    dag=dag,)

cde_versioning_table_recreation = BashOperator(task_id='CDE_VERSIONING_TABLE_RECREATION' , bash_command="""{shell_command}scripts/table_view_creation/recreate_cde_versioning_table.sh """.format(shell_command=SHELL_COMMAND)+TRANSFORMATION_LOC+" "+PRESENTATION_LOC+" "+CDE_HIVE_LOC+" "+CDE_CONTROL+" "+CONTROL+" "+BOP_CDE_BATCH_GRP+" -y,", dag=dag, trigger_rule='all_success')

shrink_action = BashOperator(task_id='SHRINK_LOGGING_TABLES',
    bash_command="""{spark_submit}batch-framework/mdf-sourcing/shrink_logging_tables.py""".format(spark_submit=SPARK_SUBMIT_COMMAND),
    dag=dag, trigger_rule='all_success')

dag_stop_op_0 = DummyOperator(
    task_id='END',
    dag=dag,
    trigger_rule='all_success')


dag_start_op_0 >> cde_versioning_table_recreation >> shrink_action >> dag_stop_op_0