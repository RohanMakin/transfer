try:
    # for Python 2.x
    from StringIO import StringIO
except ImportError:
    # for Python 3.x
    from io import StringIO

import botocore.session # pylint: disable=import-error
import csv
from datetime import datetime, timedelta
from os.path import join, abspath
import traceback
from collections import namedtuple
import yaml
import fnmatch
from airflow import DAG, utils # pylint: disable=import-error
from airflow.operators.bash_operator import BashOperator # pylint: disable=import-error
from airflow.operators.dummy_operator import DummyOperator # pylint: disable=import-error
import json
import sys 
import json

from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from datetime import date, datetime, time, timedelta
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"
with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/xdp_logger_a.yaml"

CONFIG_FILE = read_s3_file(yaml_path)
CONFIG_DICT = yaml.safe_load(CONFIG_FILE)
MASTER_IP = CONFIG_DICT["MASTER_IP"]
LOGGER_DIR_PATH = CONFIG_DICT["LOGGER_DIR_PATH"]
LOGGER_BIN_PATH = CONFIG_DICT["LOGGER_BIN_PATH"]
LOGGER_HOME_PATH = CONFIG_DICT["LOGGER_HOME_PATH"]
LOGGING_SERVICE1 = CONFIG_DICT["LOGGING_SERVICE1"]
LOGGING_SERVICE2 = CONFIG_DICT["LOGGING_SERVICE2"]
LOGGING_SERVICE3 = CONFIG_DICT["LOGGING_SERVICE3"]
KEY_FILE = CONFIG_DICT["KEY_FILE"]

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_config.yaml"

DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
ENV = DAG_CONFIG_DICT["CDE_ENV"]

script_loc="scripts/airflow/"
job_name="modify_limits_conf.sh"

CDE_FILE_LOC=DAG_CONFIG_DICT["CDE_FILE_LOC"]

file = open(MASTER_IP,"r")
IP = file.read()
file.close


default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': False, 
    'email_on_retry': False,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

dag = DAG('cde_Logger_air' , default_args=default_args, schedule_interval="45 19 * * 0-6", catchup=False, max_active_runs=1)


Loggger_Monitoring_Service = BashOperator(task_id='Loggger_Monitoring_Service' , bash_command="ssh -o StrictHostKeyChecking=no -t -i {} hadoop@".format(KEY_FILE) + IP + " sudo sh {}/mon_air.sh {} {} {} {} -y,".format(LOGGER_BIN_PATH,LOGGER_DIR_PATH,LOGGING_SERVICE1,LOGGING_SERVICE2,LOGGING_SERVICE3), dag=dag)

#CDE_MODIFY_LIMITS_CONFIG = BashOperator(task_id='CDE_MODIFY_LIMITS_CONFIG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+ CDE_FILE_LOC+script_loc+job_name+ " -y,", dag=dag)


#JOB1 = BashOperator(task_id='JOB1' , bash_command="ssh -o StrictHostKeyChecking=no -t -i /usr/local/airflow/ssh/wsl-core-emr-ec2-key.pem hadoop@" + IP + " sh {}/runlogger_airflow.sh {} -y,".format(LOGGER_BIN_PATH,LOGGER_HOME_PATH), dag=dag)
#JOB2 = BashOperator(task_id='JOB2' , bash_command="ssh -o StrictHostKeyChecking=no -t -i /usr/local/airflow/ssh/wsl-core-emr-ec2-key.pem hadoop@" + IP + " python  {}/loggingService.py &  -y,".format(LOGGER_HOME_PATH), dag=dag)
#JOB3 = BashOperator(task_id='JOB3' , bash_command="ssh -o StrictHostKeyChecking=no -t -i /usr/local/airflow/ssh/wsl-core-emr-ec2-key.pem hadoop@" + IP + " python  {}/loggingService_fallback.py  -y,".format(LOGGER_HOME_PATH), dag=dag)
#JOB4 = BashOperator(task_id='JOB4' , bash_command="ssh -o StrictHostKeyChecking=no -t -i /usr/local/airflow/ssh/wsl-core-emr-ec2-key.pem hadoop@" + IP + " python  {}/mon.sh -y,".format(LOGGER_HOME_PATH), dag=dag)


