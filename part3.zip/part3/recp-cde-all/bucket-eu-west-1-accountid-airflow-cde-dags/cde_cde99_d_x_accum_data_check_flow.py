from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from datetime import date, datetime, time, timedelta
import os
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
from airflow.operators.subdag_operator import SubDagOperator
import boto3
import botocore.session 
import json
import yaml

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]
JOB_PATH_XDPSCRIPT= BASE_PATH+DAG_CONFIG_DICT["JOB_PATH_XDPSCRIPT"]
FLOW_DEPENDENCY = BASE_PATH+DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]

save_location = "s3://bucket-eu-west-1-"+account_id+"-user/data_support_cde/test_results/"
MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	
processing_dt = str(date.today())
print("Today's processing_dt:", processing_dt)

file = open(MASTER_IP,"r")
IP = file.read()
file.close
# Dependency Code check 
def call_dagbag(*op_args):
    flow_name = op_args[0]
    print('Check DAG '+str(flow_name))
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    
    dag_bag_list = dagbag.dags[flow_name] #dagid     
    call_status_check(dag_bag_list) # last dag state
   

def call_status_check(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_state = last_instance.get_state() # last dag state
        print('\n Last Execution state'+str(dag_state))

        if(str(dag_state) == 'success') :
            print ('Dependency Met')    
        else :
            print ('Dependency Not Met')
            call_wait(dag_bag_list)  
  
def call_wait(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(300)    # Sleep
    call_status_check(dag_bag_list)
	
flow_name="CDE99_D_X_ACCUM_DATA_CHECK_FLOW"
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name	
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key] 
    return str(polling_time)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val
		
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

dag = DAG('CDE99_D_X_ACCUM_DATA_CHECK_FLOW' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
	
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)



START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)

#CDER-5685
# DEPENDENCY_CHECK_D_R_PROBE_ACCUM= BashOperator(task_id='DEPENDENCY_CHECK_D_R_PROBE_ACCUM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_D_R_PROBE_ACCUM_FLOW "+get_polling_time('CDE99_D_R_PROBE_ACCUM_FLOW')+" -y,", dag=dag)
# DEPENDENCY_CHECK_D_N_PROBE_ACCUM= BashOperator(task_id='DEPENDENCY_CHECK_D_N_PROBE_ACCUM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_D_N_PROBE_ACCUM_FLOW "+get_polling_time('CDE99_D_N_PROBE_ACCUM_FLOW')+" -y,", dag=dag)
# DEPENDENCY_CHECK_D_J_PROBE_ACCUM= BashOperator(task_id='DEPENDENCY_CHECK_D_J_PROBE_ACCUM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_D_J_PROBE_ACCUM_FLOW "+get_polling_time('CDE99_D_J_PROBE_ACCUM_FLOW')+" -y,", dag=dag)
# DEPENDENCY_CHECK_D_K_PROBE_ACCUM= BashOperator(task_id='DEPENDENCY_CHECK_D_K_PROBE_ACCUM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_D_K_PROBE_ACCUM_FLOW "+get_polling_time('CDE99_D_K_PROBE_ACCUM_FLOW')+" -y,", dag=dag)

SOURCING_CHECK= BashOperator(task_id='SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)

# NACCUM_DATA_LOAD_RBS = BashOperator(task_id='NACCUM_DATA_LOAD_RBS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_NACCUM_DATA_LOAD')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_NACCUM_DATA_LOAD.py RBS CDE06_D_X_NACCUM_DATA_LOAD CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)
# ACCUM_DATA_RECON_RBS = BashOperator(task_id='ACCUM_DATA_RECON_RBS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ACCUM_DATA_RECON_RBS')+" "+cmd_part+"\" "+JOB_PATH_XDPSCRIPT+"optimized_validation_script.py cde_bod_rbs.accumulation cde_bod_rbs.accumulation_mfdata accum_trans_branch_no-accum_trans_account_no-processing_batch_cycle  "+save_location+" "+processing_dt+"  PROCESSING_DT  "+processing_dt+" PROCESSING_DT  last_updated_dt-last_updated_tm  -y,", dag=dag)

# NACCUM_DATA_LOAD_NWB = BashOperator(task_id='NACCUM_DATA_LOAD_NWB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_NACCUM_DATA_LOAD')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_NACCUM_DATA_LOAD.py NWB CDE06_D_X_NACCUM_DATA_LOAD CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)
# ACCUM_DATA_RECON_NWB = BashOperator(task_id='ACCUM_DATA_RECON_NWB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ACCUM_DATA_RECON_NWB')+" "+cmd_part+"\" "+JOB_PATH_XDPSCRIPT+"optimized_validation_script.py cde_bod_nwb.accumulation cde_bod_nwb.accumulation_mfdata accum_trans_branch_no-accum_trans_account_no-processing_batch_cycle  "+save_location+" "+processing_dt+"  PROCESSING_DT  "+processing_dt+" PROCESSING_DT  last_updated_dt-last_updated_tm  -y,", dag=dag)

# NACCUM_DATA_LOAD_UBN = BashOperator(task_id='NACCUM_DATA_LOAD_UBN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_NACCUM_DATA_LOAD')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_NACCUM_DATA_LOAD.py UBN CDE06_D_X_NACCUM_DATA_LOAD CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)
# ACCUM_DATA_RECON_UBN = BashOperator(task_id='ACCUM_DATA_RECON_UBN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ACCUM_DATA_RECON_UBN')+" "+cmd_part+"\" "+JOB_PATH_XDPSCRIPT+"optimized_validation_script.py cde_bod_jubuk.accumulation cde_bod_jubuk.accumulation_mfdata accum_trans_branch_no-accum_trans_account_no-processing_batch_cycle  "+save_location+" "+processing_dt+"  PROCESSING_DT  "+processing_dt+" PROCESSING_DT  last_updated_dt-last_updated_tm  -y,", dag=dag)

# NACCUM_DATA_LOAD_UBS = BashOperator(task_id='NACCUM_DATA_LOAD_UBS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_NACCUM_DATA_LOAD')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_NACCUM_DATA_LOAD.py UBS CDE06_D_X_NACCUM_DATA_LOAD CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)
# ACCUM_DATA_RECON_UBS = BashOperator(task_id='ACCUM_DATA_RECON_UBS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ACCUM_DATA_RECON_UBS')+" "+cmd_part+"\" "+JOB_PATH_XDPSCRIPT+"optimized_validation_script.py cde_bod_kubie.accumulation cde_bod_kubie.accumulation_mfdata accum_trans_branch_no-accum_trans_account_no-processing_batch_cycle  "+save_location+" "+processing_dt+"  PROCESSING_DT  "+processing_dt+" PROCESSING_DT  last_updated_dt-last_updated_tm  -y,", dag=dag)

START.set_downstream(SOURCING_CHECK)

# SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_D_R_PROBE_ACCUM)
# SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_D_N_PROBE_ACCUM)
# SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_D_J_PROBE_ACCUM)
# SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_D_K_PROBE_ACCUM)


# DEPENDENCY_CHECK_D_R_PROBE_ACCUM.set_downstream(NACCUM_DATA_LOAD_RBS)
# DEPENDENCY_CHECK_D_N_PROBE_ACCUM.set_downstream(NACCUM_DATA_LOAD_NWB)
# DEPENDENCY_CHECK_D_J_PROBE_ACCUM.set_downstream(NACCUM_DATA_LOAD_UBN)
# DEPENDENCY_CHECK_D_K_PROBE_ACCUM.set_downstream(NACCUM_DATA_LOAD_UBS)

def get_BucketNkey(input_loc):
    full_path = input_loc[5:]
    #print(full_path)
    bucket_name=full_path.split("/")[0]
    #print(bucket_name)
    full_path_list = full_path.split("/")
    key = ''
    len1 = len(full_path_list)
    k=1
    while k < len1 :
        #print(list_1[k])
        #print(k)
        key= key + "/" + full_path_list[k]
        k=k+1
    length = len(key)
    Key = key[1:length]
    myDict = {}
    myDict['bucket_name'] = Key
    return bucket_name,Key

import yaml
import boto3
import botocore
from botocore.session import Session

def readFile(bucket_name,key) :
    session = Session()
    client = session.create_client('s3')
    obj_dict = client.get_object(Bucket=bucket_name,Key=key)
    yaml_res= obj_dict['Body'].read().decode('utf-8')
    my_dict=yaml.safe_load(yaml_res)
    return my_dict

def get_brand(file_name):
    file_name=file_name.upper()
    if 'RBS_' in file_name or '_RBS' in file_name or '_R_' in file_name:
        return 'R'
    elif 'NWB_' in file_name or '_NWB' in file_name or '_N_' in file_name:
        return 'N'
    elif 'JUBUK_' in file_name or '_JUBUK' in file_name or 'UBN_' in file_name or '_UBN' in file_name or '_J_' in file_name:
        return 'J'
    elif 'KUBIE_' in file_name or '_KUBIE' in file_name or 'UBS_' in file_name or '_UBS' in file_name or 'UBR_' in file_name or '_UBR' in file_name or '_K_' in file_name:
        return 'K'
    elif 'GRP_' in file_name or '_GRP' in file_name or '_G_' in file_name:
        return 'G'
    else:
        return 'INVALID'

dep_config_file_loc = "s3://bucket-eu-west-1-{}-risk-cicd/cde/dags/config/dependency_daily.yaml".format(account_id)
bucket_name,key=get_BucketNkey(dep_config_file_loc)
ret_dict=readFile(bucket_name,key)
dependencies=ret_dict[flow_name]

dep_config_file_loc = "s3://bucket-eu-west-1-{}-risk-cicd/cde/dags/config/dependency_master.yaml".format(account_id)
bucket_name,key=get_BucketNkey(dep_config_file_loc)
ret_dict=readFile(bucket_name,key)
all_dep=ret_dict[flow_name]

#dependencies=['CDE99_D_K_PAL_LOGIC_FLOW','CDE99_D_R_PAL_LOGIC_FLOW']

if len(dependencies)==0:
    DEPENDENCY_CHECK_HOLIDAY_MISS = DummyOperator(
        task_id='DEPENDENCY_CHECK_HOLIDAY_MISS',
        dag=dag,)
    SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_HOLIDAY_MISS)
    DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(END)
else:
    for dependency in dependencies:
        task_id_dth = "DEPENDENCY_CHECK_{}".format(dependency)
        task_dth= BashOperator(task_id=task_id_dth , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" "+dependency+" "+get_polling_time(dependency)+" -y,", dag=dag)
        SOURCING_CHECK.set_downstream(task_dth)
        # task_dth= BashOperator(task_id=task_id_dth , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_D_R_PROBE_ACCUM_FLOW "+get_polling_time('CDE99_D_R_PROBE_ACCUM_FLOW')+" -y,", dag=dag)
        brnd=get_brand(dependency)
        if brnd=='R':
            NACCUM_DATA_LOAD_RBS = BashOperator(task_id='NACCUM_DATA_LOAD_RBS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_NACCUM_DATA_LOAD')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_NACCUM_DATA_LOAD.py RBS CDE06_D_X_NACCUM_DATA_LOAD CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)
            ACCUM_DATA_RECON_RBS = BashOperator(task_id='ACCUM_DATA_RECON_RBS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ACCUM_DATA_RECON_RBS')+" "+cmd_part+"\" "+JOB_PATH_XDPSCRIPT+"optimized_validation_script.py cde_bod_rbs.accumulation cde_bod_rbs.accumulation_mfdata accum_trans_branch_no-accum_trans_account_no-processing_batch_cycle  "+save_location+" "+processing_dt+"  PROCESSING_DT  "+processing_dt+" PROCESSING_DT  last_updated_dt-last_updated_tm  -y,", dag=dag)
            NACCUM_DATA_LOAD_RBS.set_downstream(ACCUM_DATA_RECON_RBS)
            task_dth.set_downstream(NACCUM_DATA_LOAD_RBS)
            ACCUM_DATA_RECON_RBS.set_downstream(END)
        elif brnd=='N':
            NACCUM_DATA_LOAD_NWB = BashOperator(task_id='NACCUM_DATA_LOAD_NWB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_NACCUM_DATA_LOAD')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_NACCUM_DATA_LOAD.py NWB CDE06_D_X_NACCUM_DATA_LOAD CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)
            ACCUM_DATA_RECON_NWB = BashOperator(task_id='ACCUM_DATA_RECON_NWB' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ACCUM_DATA_RECON_NWB')+" "+cmd_part+"\" "+JOB_PATH_XDPSCRIPT+"optimized_validation_script.py cde_bod_nwb.accumulation cde_bod_nwb.accumulation_mfdata accum_trans_branch_no-accum_trans_account_no-processing_batch_cycle  "+save_location+" "+processing_dt+"  PROCESSING_DT  "+processing_dt+" PROCESSING_DT  last_updated_dt-last_updated_tm  -y,", dag=dag)
            NACCUM_DATA_LOAD_NWB.set_downstream(ACCUM_DATA_RECON_NWB)
            task_dth.set_downstream(NACCUM_DATA_LOAD_NWB)
            ACCUM_DATA_RECON_NWB.set_downstream(END)
        elif brnd=='J':
            NACCUM_DATA_LOAD_UBN = BashOperator(task_id='NACCUM_DATA_LOAD_UBN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_NACCUM_DATA_LOAD')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_NACCUM_DATA_LOAD.py UBN CDE06_D_X_NACCUM_DATA_LOAD CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)
            ACCUM_DATA_RECON_UBN = BashOperator(task_id='ACCUM_DATA_RECON_UBN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ACCUM_DATA_RECON_UBN')+" "+cmd_part+"\" "+JOB_PATH_XDPSCRIPT+"optimized_validation_script.py cde_bod_jubuk.accumulation cde_bod_jubuk.accumulation_mfdata accum_trans_branch_no-accum_trans_account_no-processing_batch_cycle  "+save_location+" "+processing_dt+"  PROCESSING_DT  "+processing_dt+" PROCESSING_DT  last_updated_dt-last_updated_tm  -y,", dag=dag)
            NACCUM_DATA_LOAD_UBN.set_downstream(ACCUM_DATA_RECON_UBN)
            task_dth.set_downstream(NACCUM_DATA_LOAD_UBN)
            ACCUM_DATA_RECON_RBS.set_downstream(END)
        elif brnd=='K':
            NACCUM_DATA_LOAD_UBS = BashOperator(task_id='NACCUM_DATA_LOAD_UBS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_NACCUM_DATA_LOAD')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_NACCUM_DATA_LOAD.py UBS CDE06_D_X_NACCUM_DATA_LOAD CDE99_D_X_ACCUM_DATA_CHECK_FLOW -y,", dag=dag)
            ACCUM_DATA_RECON_UBS = BashOperator(task_id='ACCUM_DATA_RECON_UBS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('ACCUM_DATA_RECON_UBS')+" "+cmd_part+"\" "+JOB_PATH_XDPSCRIPT+"optimized_validation_script.py cde_bod_kubie.accumulation cde_bod_kubie.accumulation_mfdata accum_trans_branch_no-accum_trans_account_no-processing_batch_cycle  "+save_location+" "+processing_dt+"  PROCESSING_DT  "+processing_dt+" PROCESSING_DT  last_updated_dt-last_updated_tm  -y,", dag=dag)
            NACCUM_DATA_LOAD_UBS.set_downstream(ACCUM_DATA_RECON_UBS)
            task_dth.set_downstream(NACCUM_DATA_LOAD_UBS)
            ACCUM_DATA_RECON_UBS.set_downstream(END)
        else:
            pass
    for dep in all_dep:
        if dep not in dependencies:
            DEPENDENCY_CHECK_HOLIDAY_MISS = DummyOperator(
                task_id='DEPENDENCY_{}_HOLIDAY_MISS'.format(dep),
                dag=dag,)
            SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_HOLIDAY_MISS)
            DEPENDENCY_CHECK_HOLIDAY_MISS.set_downstream(END)
# NACCUM_DATA_LOAD_RBS.set_downstream(ACCUM_DATA_RECON_RBS)
# NACCUM_DATA_LOAD_NWB.set_downstream(ACCUM_DATA_RECON_NWB)
# NACCUM_DATA_LOAD_UBN.set_downstream(ACCUM_DATA_RECON_UBN)
# NACCUM_DATA_LOAD_UBS.set_downstream(ACCUM_DATA_RECON_UBS)


# ACCUM_DATA_RECON_RBS.set_downstream(END)
# ACCUM_DATA_RECON_NWB.set_downstream(END)
# ACCUM_DATA_RECON_UBN.set_downstream(END)
# ACCUM_DATA_RECON_UBS.set_downstream(END)

RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)