from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from datetime import date, datetime, time, timedelta
import os
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
from airflow.operators.subdag_operator import SubDagOperator
'''from cde_cde04_m_n_powerc_acc_lvl_flow import child_dag_cde04_m_n_powerc_acc_lvl_flow
from cde_cde09_m_n_cb_data_extract_flow import child_dag_cde09_m_n_cb_data_extract_flow
from cde_cde10_m_n_bus_risk_bands_flow import child_dag_cde10_m_n_bus_risk_bands_flow
from cde_cde10_m_n_pers_risk_bands_flow import child_dag_cde10_m_n_pers_risk_bands_flow
from cde_cde10_m_n_risk_bands import child_dag_cde10_m_n_risk_bands
from cde_cde11_m_n_bus_pal_limits_flow import child_dag_cde11_m_n_bus_pal_limits_flow
from cde_cde11_m_n_rbsi_pal_limits_flow import child_dag_cde11_m_n_rbsi_pal_limits_flow'''
import boto3
import botocore.session 
import json
import yaml

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
    
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
    
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
    data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]
FLOW_DEPENDENCY = BASE_PATH+DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
CONCURRENCY_BUS_LOGIC_FLOW = DAG_CONFIG_DICT["CONCURRENCY_BUS_LOGIC_FLOW"]
SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]    

file = open(MASTER_IP,"r")
IP = file.read()
file.close
# Dependency Code check 
def call_dagbag(*op_args):
    flow_name = op_args[0]
    print('Check DAG '+str(flow_name))
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    
    dag_bag_list = dagbag.dags[flow_name] #dagid     
    call_status_check(dag_bag_list) # last dag state
   

def call_status_check(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_state = last_instance.get_state() # last dag state
        print('\n Last Execution state'+str(dag_state))

        if(str(dag_state) == 'success') :
            print ('Dependency Met')    
        else :
            print ('Dependency Not Met')
            call_wait(dag_bag_list)  
  
def call_wait(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(300)    # Sleep
    call_status_check(dag_bag_list)
    
flow_name="CDE99_M_N_BUS_LOGIC_FLOW"

SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'    
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name	
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key] 
    return str(polling_time)
    
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]        
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]        
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'    
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val
    
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

dag = DAG('CDE99_M_N_BUS_LOGIC_FLOW' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1, concurrency = CONCURRENCY_BUS_LOGIC_FLOW)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
    
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)

# Child DAG Definitions

'''subDag_cde04_m_n_powerc_acc_lvl_flow = SubDagOperator(
    subdag=child_dag_cde04_m_n_powerc_acc_lvl_flow('CDE99_M_N_BUS_LOGIC_FLOW', 'CDE04_M_N_POWERC_ACC_LVL_FLOW', default_args, dag.schedule_interval),
    task_id='CDE04_M_N_POWERC_ACC_LVL_FLOW',
    default_args=default_args,
    dag=dag)
    
subDag_cde09_m_n_cb_data_extract_flow = SubDagOperator(
    subdag=child_dag_cde09_m_n_cb_data_extract_flow('CDE99_M_N_BUS_LOGIC_FLOW', 'CDE09_M_N_CB_DATA_EXTRACT_FLOW', default_args, dag.schedule_interval),
    task_id='CDE09_M_N_CB_DATA_EXTRACT_FLOW',
    default_args=default_args,
    dag=dag)

subDag_cde10_m_n_bus_risk_bands_flow = SubDagOperator(
    subdag=child_dag_cde10_m_n_bus_risk_bands_flow('CDE99_M_N_BUS_LOGIC_FLOW', 'CDE10_M_N_BUS_RISK_BANDS_FLOW', default_args, dag.schedule_interval),
    task_id='CDE10_M_N_BUS_RISK_BANDS_FLOW',
    default_args=default_args,
    dag=dag)
    
subDag_cde10_m_n_pers_risk_bands_flow = SubDagOperator(
    subdag=child_dag_cde10_m_n_pers_risk_bands_flow('CDE99_M_N_BUS_LOGIC_FLOW', 'CDE10_M_N_PERS_RISK_BANDS_FLOW', default_args, dag.schedule_interval),
    task_id='CDE10_M_N_PERS_RISK_BANDS_FLOW',
    default_args=default_args,
    dag=dag)
    
subDag_cde10_m_n_risk_bands = SubDagOperator(
    subdag=child_dag_cde10_m_n_risk_bands('CDE99_M_N_BUS_LOGIC_FLOW', 'CDE10_M_N_RISK_BANDS', default_args, dag.schedule_interval),
    task_id='CDE10_M_N_RISK_BANDS',
    default_args=default_args,
    dag=dag)
    
subDag_cde11_m_n_bus_pal_limits_flow = SubDagOperator(
    subdag=child_dag_cde11_m_n_bus_pal_limits_flow('CDE99_M_N_BUS_LOGIC_FLOW', 'CDE11_M_N_BUS_PAL_LIMITS_FLOW', default_args, dag.schedule_interval),
    task_id='CDE11_M_N_BUS_PAL_LIMITS_FLOW',
    default_args=default_args,
    dag=dag)
    
subDag_cde11_m_n_rbsi_pal_limits_flow = SubDagOperator(
    subdag=child_dag_cde11_m_n_rbsi_pal_limits_flow('CDE99_M_N_BUS_LOGIC_FLOW', 'CDE11_M_N_RBSI_PAL_LIMITS_FLOW', default_args, dag.schedule_interval),
    task_id='CDE11_M_N_RBSI_PAL_LIMITS_FLOW',
    default_args=default_args,
    dag=dag)'''
	
# CDE04_M_N_POWERC_ACC_LVL_FLOW
CDE04_M_X_PROBE_ACCT_POWERCR = BashOperator(task_id='CDE04_M_X_PROBE_ACCT_POWERCR' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_X_PROBE_ACCT_POWERCR')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_X_PROBE_ACCT_POWERCR.py NWB CDE04_M_X_PROBE_ACCT_POWERCR CDE04_M_N_POWERC_ACC_LVL_FLOW -y,", dag=dag)
#CDE06_D_X_APS_ACC_RULE = BashOperator(task_id='CDE06_D_X_APS_ACC_RULE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_APS_ACC_RULE')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_APS_ACC_RULE.py NWB CDE04_M_N_POWERC_ACC_LVL_FLOW -y,", dag=dag)
#CDE06_D_X_APS_ACC_RULE.set_downstream(CDE04_M_X_PROBE_ACCT_POWERCR)

# CDE09_M_N_CB_DATA_EXTRACT_FLOW
CDE07_M_X_CB_ACC_ANNUAL_CTO = BashOperator(task_id='CDE07_M_X_CB_ACC_ANNUAL_CTO' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_CB_ACC_ANNUAL_CTO')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_CB_ACC_ANNUAL_CTO.py NWB CDE07_M_X_CB_ACC_ANNUAL_CTO CDE09_M_N_CB_DATA_EXTRACT_FLOW -y,", dag=dag)
CDE07_M_X_CB_BIN_ANNUAL_CTO = BashOperator(task_id='CDE07_M_X_CB_BIN_ANNUAL_CTO' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_CB_BIN_ANNUAL_CTO')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_CB_BIN_ANNUAL_CTO.py NWB CDE07_M_X_CB_BIN_ANNUAL_CTO CDE09_M_N_CB_DATA_EXTRACT_FLOW -y,", dag=dag)
CDE09_M_X_CB_ANNUAL_CTO = BashOperator(task_id='CDE09_M_X_CB_ANNUAL_CTO' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE09_M_X_CB_ANNUAL_CTO')+" "+cmd_part+"\" "+JOB_PATH+"CDE09_M_X_CB_ANNUAL_CTO.py NWB CDE09_M_X_CB_ANNUAL_CTO CDE09_M_N_CB_DATA_EXTRACT_FLOW -y,", dag=dag)
CDE09_M_X_COMMERCIAL_POP = BashOperator(task_id='CDE09_M_X_COMMERCIAL_POP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE09_M_X_COMMERCIAL_POP')+" "+cmd_part+"\" "+JOB_PATH+"CDE09_M_X_COMMERCIAL_POP.py NWB CDE09_M_X_COMMERCIAL_POP CDE09_M_N_CB_DATA_EXTRACT_FLOW -y,", dag=dag)
CDE09_M_X_CB_ANNUAL_CTO.set_downstream(CDE07_M_X_CB_ACC_ANNUAL_CTO)
CDE09_M_X_CB_ANNUAL_CTO.set_downstream(CDE07_M_X_CB_BIN_ANNUAL_CTO)
CDE09_M_X_COMMERCIAL_POP.set_downstream(CDE09_M_X_CB_ANNUAL_CTO)

dag_end_data_extract_flow= DummyOperator(task_id='END_CDE09_M_N_CB_DATA_EXTRACT_FLOW',dag=dag,)
CDE07_M_X_CB_ACC_ANNUAL_CTO.set_downstream(dag_end_data_extract_flow)
CDE07_M_X_CB_BIN_ANNUAL_CTO.set_downstream(dag_end_data_extract_flow)


# CDE10_M_N_BUS_RISK_BANDS_FLOW
#CDE06_M_X_RBAND_TAC_RESULT = BashOperator(task_id='CDE06_M_X_RBAND_TAC_RESULT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_RBAND_TAC_RESULT')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_RBAND_TAC_RESULT.py NWB CDE06_M_X_RBAND_TAC_RESULT CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE07_M_X_BUSINESS_RISK_BANDS = BashOperator(task_id='CDE07_M_X_BUSINESS_RISK_BANDS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_BUSINESS_RISK_BANDS')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_BUSINESS_RISK_BANDS.py NWB CDE07_M_X_BUSINESS_RISK_BANDS CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE07_M_X_BUS_AND_RP_POP = BashOperator(task_id='CDE07_M_X_BUS_AND_RP_POP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_BUS_AND_RP_POP')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_BUS_AND_RP_POP.py NWB CDE07_M_X_BUS_AND_RP_POP CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE07_M_X_BUS_RISK_BANDS_SCL = BashOperator(task_id='CDE07_M_X_BUS_RISK_BANDS_SCL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_BUS_RISK_BANDS_SCL')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_BUS_RISK_BANDS_SCL.py NWB CDE07_M_X_BUS_RISK_BANDS_SCL CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_BUSINESS_RISK_BANDS = BashOperator(task_id='CDE10_M_X_BUSINESS_RISK_BANDS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUSINESS_RISK_BANDS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUSINESS_RISK_BANDS.py NWB CDE10_M_X_BUSINESS_RISK_BANDS CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_BUS_RB_BUS_AGGS = BashOperator(task_id='CDE10_M_X_BUS_RB_BUS_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUS_RB_BUS_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUS_RB_BUS_AGGS.py NWB CDE10_M_X_BUS_RB_BUS_AGGS CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_BUS_RB_COMMCC_AGGS = BashOperator(task_id='CDE10_M_X_BUS_RB_COMMCC_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUS_RB_COMMCC_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUS_RB_COMMCC_AGGS.py NWB CDE10_M_X_BUS_RB_COMMCC_AGGS CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_BUS_RB_COMMEQ_AGGS = BashOperator(task_id='CDE10_M_X_BUS_RB_COMMEQ_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUS_RB_COMMEQ_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUS_RB_COMMEQ_AGGS.py NWB CDE10_M_X_BUS_RB_COMMEQ_AGGS CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_BUS_RB_POPULATION = BashOperator(task_id='CDE10_M_X_BUS_RB_POPULATION' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUS_RB_POPULATION')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUS_RB_POPULATION.py NWB CDE10_M_X_BUS_RB_POPULATION CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_BUS_RB_RPACC_AGGS = BashOperator(task_id='CDE10_M_X_BUS_RB_RPACC_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUS_RB_RPACC_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUS_RB_RPACC_AGGS.py NWB CDE10_M_X_BUS_RB_RPACC_AGGS CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
#CDE10_M_X_BUS_RB_RPCIN_AGGS = BashOperator(task_id='CDE10_M_X_BUS_RB_RPCIN_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUS_RB_RPCIN_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUS_RB_RPCIN_AGGS.py NWB CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_BUS_RB_RP_POPULATION = BashOperator(task_id='CDE10_M_X_BUS_RB_RP_POPULATION' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUS_RB_RP_POPULATION')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUS_RB_RP_POPULATION.py NWB CDE10_M_X_BUS_RB_RP_POPULATION CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_BUS_NON_BANKED_POP = BashOperator(task_id='CDE10_M_X_BUS_NON_BANKED_POP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUS_NON_BANKED_POP')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUS_NON_BANKED_POP.py NWB CDE10_M_X_BUS_NON_BANKED_POP CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_BUS_RB_BUREAU_AGGS = BashOperator(task_id='CDE10_M_X_BUS_RB_BUREAU_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUS_RB_BUREAU_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUS_RB_BUREAU_AGGS.py NWB CDE10_M_X_BUS_RB_BUREAU_AGGS CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)
CDE07_M_X_BUS_PRB_INPUT = BashOperator(task_id='CDE07_M_X_BUS_PRB_INPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_BUS_PRB_INPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_BUS_PRB_INPUT.py NWB CDE07_M_X_BUS_PRB_INPUT CDE10_M_N_BUS_RISK_BANDS_FLOW -y,", dag=dag)

#CDE06_M_X_RBAND_TAC_RESULT.set_downstream(CDE10_M_X_BUS_RB_POPULATION)
CDE10_M_X_BUS_RB_POPULATION.set_downstream(CDE10_M_X_BUS_RB_BUS_AGGS)
CDE10_M_X_BUS_RB_POPULATION.set_downstream(CDE10_M_X_BUS_RB_COMMCC_AGGS)
CDE10_M_X_BUS_RB_POPULATION.set_downstream(CDE10_M_X_BUS_RB_COMMEQ_AGGS)
CDE10_M_X_BUS_RB_POPULATION.set_downstream(CDE10_M_X_BUS_RB_RP_POPULATION)
CDE10_M_X_BUS_RB_BUS_AGGS.set_downstream(CDE10_M_X_BUSINESS_RISK_BANDS)
CDE10_M_X_BUS_RB_COMMEQ_AGGS.set_downstream(CDE10_M_X_BUSINESS_RISK_BANDS)
CDE10_M_X_BUS_RB_COMMCC_AGGS.set_downstream(CDE10_M_X_BUSINESS_RISK_BANDS)	
CDE10_M_X_BUS_RB_RP_POPULATION.set_downstream(CDE10_M_X_BUS_NON_BANKED_POP)
CDE10_M_X_BUS_RB_RP_POPULATION.set_downstream(CDE10_M_X_BUS_RB_RPACC_AGGS)	
CDE10_M_X_BUS_RB_RPACC_AGGS.set_downstream(CDE10_M_X_BUSINESS_RISK_BANDS)
CDE10_M_X_BUS_NON_BANKED_POP.set_downstream(CDE10_M_X_BUS_RB_BUREAU_AGGS)
CDE10_M_X_BUS_RB_BUREAU_AGGS.set_downstream(CDE10_M_X_BUSINESS_RISK_BANDS)
CDE10_M_X_BUSINESS_RISK_BANDS.set_downstream(CDE07_M_X_BUSINESS_RISK_BANDS)
CDE07_M_X_BUSINESS_RISK_BANDS.set_downstream(CDE07_M_X_BUS_RISK_BANDS_SCL)
CDE07_M_X_BUS_RISK_BANDS_SCL.set_downstream(CDE07_M_X_BUS_AND_RP_POP)
CDE07_M_X_BUS_AND_RP_POP.set_downstream(CDE07_M_X_BUS_PRB_INPUT)

# CDE10_M_N_PERS_RISK_BANDS_FLOW
CDE07_M_X_PERSONAL_RISK_BANDS = BashOperator(task_id='CDE07_M_X_PERSONAL_RISK_BANDS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_PERSONAL_RISK_BANDS')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_PERSONAL_RISK_BANDS.py NWB CDE07_M_X_PERSONAL_RISK_BANDS CDE10_M_N_PERS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_PERSONAL_RISK_BANDS = BashOperator(task_id='CDE10_M_X_PERSONAL_RISK_BANDS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_PERSONAL_RISK_BANDS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_PERSONAL_RISK_BANDS.py NWB CDE10_M_X_PERSONAL_RISK_BANDS CDE10_M_N_PERS_RISK_BANDS_FLOW -y,", dag=dag)
CDE10_M_X_PERSONAL_RISK_BANDS.set_downstream(CDE07_M_X_PERSONAL_RISK_BANDS)

# CDE10_M_N_RISK_BANDS
CDE04_M_X_BUSINESS_RISK_BANDS = BashOperator(task_id='CDE04_M_X_BUSINESS_RISK_BANDS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_X_BUSINESS_RISK_BANDS')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_X_BUSINESS_RISK_BANDS.py NWB CDE04_M_X_BUSINESS_RISK_BANDS CDE10_M_N_RISK_BANDS -y,", dag=dag)
CDE06_M_X_CUST_CUST_REL = BashOperator(task_id='CDE06_M_X_CUST_CUST_REL' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_M_X_CUST_CUST_REL')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_M_X_CUST_CUST_REL.py NWB CDE06_M_X_CUST_CUST_REL CDE10_M_N_RISK_BANDS -y,", dag=dag)
CDE07_M_X_CUST_CONN_RISK_BANDS_HST = BashOperator(task_id='CDE07_M_X_CUST_CONN_RISK_BANDS_HST' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_CUST_CONN_RISK_BANDS_HST')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_CUST_CONN_RISK_BANDS_HST.py NWB CDE07_M_X_CUST_CONN_RISK_BANDS_HST CDE10_M_N_RISK_BANDS -y,", dag=dag)
CDE10_M_X_BUS_RB_LEAD_RELATED = BashOperator(task_id='CDE10_M_X_BUS_RB_LEAD_RELATED' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_BUS_RB_LEAD_RELATED')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_BUS_RB_LEAD_RELATED.py NWB CDE10_M_X_BUS_RB_LEAD_RELATED CDE10_M_N_RISK_BANDS -y,", dag=dag)
CDE10_M_X_CONN_RISK_BANDS = BashOperator(task_id='CDE10_M_X_CONN_RISK_BANDS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_CONN_RISK_BANDS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_CONN_RISK_BANDS.py NWB CDE10_M_X_CONN_RISK_BANDS CDE10_M_N_RISK_BANDS -y,", dag=dag)
CDE10_M_X_CUST_CONN_RISK_BANDS = BashOperator(task_id='CDE10_M_X_CUST_CONN_RISK_BANDS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_CUST_CONN_RISK_BANDS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_CUST_CONN_RISK_BANDS.py NWB CDE10_M_X_CUST_CONN_RISK_BANDS CDE10_M_N_RISK_BANDS -y,", dag=dag)
CDE10_M_X_CUST_RISK_BANDS = BashOperator(task_id='CDE10_M_X_CUST_RISK_BANDS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_X_CUST_RISK_BANDS')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_X_CUST_RISK_BANDS.py NWB CDE10_M_X_CUST_RISK_BANDS CDE10_M_N_RISK_BANDS -y,", dag=dag)
CDE10_M_X_CUST_CONN_RISK_BANDS.set_downstream(CDE04_M_X_BUSINESS_RISK_BANDS)
CDE10_M_X_CUST_CONN_RISK_BANDS.set_downstream(CDE07_M_X_CUST_CONN_RISK_BANDS_HST)
CDE06_M_X_CUST_CUST_REL.set_downstream(CDE10_M_X_BUS_RB_LEAD_RELATED)
CDE10_M_X_CUST_RISK_BANDS.set_downstream(CDE10_M_X_CONN_RISK_BANDS)
CDE10_M_X_CONN_RISK_BANDS.set_downstream(CDE10_M_X_CUST_CONN_RISK_BANDS)
CDE10_M_X_BUS_RB_LEAD_RELATED.set_downstream(CDE10_M_X_CUST_RISK_BANDS)

dag_end_risk_bands= DummyOperator(task_id='END_CDE10_M_N_RISK_BANDS',dag=dag,)
CDE04_M_X_BUSINESS_RISK_BANDS.set_downstream(dag_end_risk_bands)
CDE07_M_X_CUST_CONN_RISK_BANDS_HST.set_downstream(dag_end_risk_bands)

# CDE11_M_N_BUS_PAL_LIMITS_FLOW
CDE07_M_X_BUS_PAL_INPUT = BashOperator(task_id='CDE07_M_X_BUS_PAL_INPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_BUS_PAL_INPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_BUS_PAL_INPUT.py NWB CDE07_M_X_BUS_PAL_INPUT CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE07_M_X_BUS_PAL_LIMITS = BashOperator(task_id='CDE07_M_X_BUS_PAL_LIMITS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_BUS_PAL_LIMITS')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_BUS_PAL_LIMITS.py NWB CDE07_M_X_BUS_PAL_LIMITS CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE07_M_X_BUS_PAL_POLICY = BashOperator(task_id='CDE07_M_X_BUS_PAL_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_BUS_PAL_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_BUS_PAL_POLICY.py NWB CDE07_M_X_BUS_PAL_POLICY CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_X_BUS_PAL_BUSACC_AGGS = BashOperator(task_id='CDE11_M_X_BUS_PAL_BUSACC_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_X_BUS_PAL_BUSACC_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_X_BUS_PAL_BUSACC_AGGS.py NWB CDE11_M_X_BUS_PAL_BUSACC_AGGS CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_X_BUS_PAL_INPUT = BashOperator(task_id='CDE11_M_X_BUS_PAL_INPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_X_BUS_PAL_INPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_X_BUS_PAL_INPUT.py NWB CDE11_M_X_BUS_PAL_INPUT CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_X_BUS_PAL_LIMITS = BashOperator(task_id='CDE11_M_X_BUS_PAL_LIMITS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_X_BUS_PAL_LIMITS')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_X_BUS_PAL_LIMITS.py NWB CDE11_M_X_BUS_PAL_LIMITS CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_X_BUS_PAL_POLICY = BashOperator(task_id='CDE11_M_X_BUS_PAL_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_X_BUS_PAL_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_X_BUS_PAL_POLICY.py NWB CDE11_M_X_BUS_PAL_POLICY CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
#CDE11_M_X_BUS_PAL_RP_CIN_AGGS = BashOperator(task_id='CDE11_M_X_BUS_PAL_RP_CIN_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_X_BUS_PAL_RP_CIN_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_X_BUS_PAL_RP_CIN_AGGS.py NWB CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_X_BUS_PAL_BUREAU_AGGS = BashOperator(task_id='CDE11_M_X_BUS_PAL_BUREAU_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_X_BUS_PAL_BUREAU_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_X_BUS_PAL_BUREAU_AGGS.py NWB CDE11_M_X_BUS_PAL_BUREAU_AGGS CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_X_BUS_PAL_DB_TRANS_AGG = BashOperator(task_id='CDE11_M_X_BUS_PAL_DB_TRANS_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_X_BUS_PAL_DB_TRANS_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_X_BUS_PAL_DB_TRANS_AGG.py NWB CDE11_M_X_BUS_PAL_DB_TRANS_AGG CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_X_BUS_GRANULAR_TRANS = BashOperator(task_id='CDE11_M_X_BUS_GRANULAR_TRANS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_X_BUS_GRANULAR_TRANS')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_X_BUS_GRANULAR_TRANS.py NWB CDE11_M_X_BUS_GRANULAR_TRANS CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_X_BUS_PAL_BUSAPPS_AGGS = BashOperator(task_id='CDE11_M_X_BUS_PAL_BUSAPPS_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_X_BUS_PAL_BUSAPPS_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_X_BUS_PAL_BUSAPPS_AGGS.py NWB CDE11_M_X_BUS_PAL_BUSAPPS_AGGS CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_X_BUS_PAL_MAN_SHADLIM = BashOperator(task_id='CDE11_M_X_BUS_PAL_MAN_SHADLIM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_X_BUS_PAL_MAN_SHADLIM')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_X_BUS_PAL_MAN_SHADLIM.py NWB CDE11_M_X_BUS_PAL_MAN_SHADLIM CDE11_M_N_BUS_PAL_LIMITS_FLOW -y,", dag=dag)

CDE11_M_X_BUS_PAL_BUSACC_AGGS.set_downstream(CDE11_M_X_BUS_PAL_BUREAU_AGGS)
CDE11_M_X_BUS_PAL_BUREAU_AGGS.set_downstream(CDE11_M_X_BUS_PAL_BUSAPPS_AGGS)
CDE11_M_X_BUS_PAL_BUREAU_AGGS.set_downstream(CDE11_M_X_BUS_PAL_DB_TRANS_AGG)
CDE11_M_X_BUS_PAL_BUREAU_AGGS.set_downstream(CDE11_M_X_BUS_PAL_MAN_SHADLIM)
CDE11_M_X_BUS_PAL_BUSAPPS_AGGS.set_downstream(CDE11_M_X_BUS_PAL_INPUT)
CDE11_M_X_BUS_PAL_DB_TRANS_AGG.set_downstream(CDE11_M_X_BUS_GRANULAR_TRANS)
CDE11_M_X_BUS_PAL_MAN_SHADLIM.set_downstream(CDE11_M_X_BUS_PAL_INPUT)
CDE11_M_X_BUS_GRANULAR_TRANS.set_downstream(CDE11_M_X_BUS_PAL_INPUT)
CDE11_M_X_BUS_PAL_INPUT.set_downstream(CDE11_M_X_BUS_PAL_POLICY)
CDE11_M_X_BUS_PAL_POLICY.set_downstream(CDE11_M_X_BUS_PAL_LIMITS)
CDE11_M_X_BUS_PAL_LIMITS.set_downstream(CDE07_M_X_BUS_PAL_INPUT)
CDE11_M_X_BUS_PAL_LIMITS.set_downstream(CDE07_M_X_BUS_PAL_POLICY)		
CDE11_M_X_BUS_PAL_LIMITS.set_downstream(CDE07_M_X_BUS_PAL_LIMITS)

dag_end_bus_pal_limits= DummyOperator(task_id='END_CDE11_M_N_BUS_PAL_LIMITS_FLOW',dag=dag,)
CDE07_M_X_BUS_PAL_INPUT.set_downstream(dag_end_bus_pal_limits)
CDE07_M_X_BUS_PAL_POLICY.set_downstream(dag_end_bus_pal_limits)		
CDE07_M_X_BUS_PAL_LIMITS.set_downstream(dag_end_bus_pal_limits)

# CDE11_M_N_RBSI_PAL_LIMITS_FLOW
CDE10_M_N_RBSI_POPULATION = BashOperator(task_id='CDE10_M_N_RBSI_POPULATION' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE10_M_N_RBSI_POPULATION')+" "+cmd_part+"\" "+JOB_PATH+"CDE10_M_N_RBSI_POPULATION.py NWB CDE10_M_N_RBSI_POPULATION CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_N_RBSI_PAL_BUSACC_AGGS = BashOperator(task_id='CDE11_M_N_RBSI_PAL_BUSACC_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_N_RBSI_PAL_BUSACC_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_N_RBSI_PAL_BUSACC_AGGS.py NWB CDE11_M_N_RBSI_PAL_BUSACC_AGGS CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_N_RBSI_PAL_DB_TRANS_AGG = BashOperator(task_id='CDE11_M_N_RBSI_PAL_DB_TRANS_AGG' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_N_RBSI_PAL_DB_TRANS_AGG')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_N_RBSI_PAL_DB_TRANS_AGG.py NWB CDE11_M_N_RBSI_PAL_DB_TRANS_AGG CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_N_RBSI_PAL_MAN_SHADLIM = BashOperator(task_id='CDE11_M_N_RBSI_PAL_MAN_SHADLIM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_N_RBSI_PAL_MAN_SHADLIM')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_N_RBSI_PAL_MAN_SHADLIM.py NWB CDE11_M_N_RBSI_PAL_MAN_SHADLIM CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_N_RBSI_PAL_BUREAU_AGGS = BashOperator(task_id='CDE11_M_N_RBSI_PAL_BUREAU_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_N_RBSI_PAL_BUREAU_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_N_RBSI_PAL_BUREAU_AGGS.py NWB CDE11_M_N_RBSI_PAL_BUREAU_AGGS CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_N_RBSI_PAL_BUSAPPS_AGGS = BashOperator(task_id='CDE11_M_N_RBSI_PAL_BUSAPPS_AGGS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_N_RBSI_PAL_BUSAPPS_AGGS')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_N_RBSI_PAL_BUSAPPS_AGGS.py NWB CDE11_M_N_RBSI_PAL_BUSAPPS_AGGS CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_N_RBSI_PAL_INPUT = BashOperator(task_id='CDE11_M_N_RBSI_PAL_INPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_N_RBSI_PAL_INPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_N_RBSI_PAL_INPUT.py NWB CDE11_M_N_RBSI_PAL_INPUT CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_N_RBSI_PAL_POLICY = BashOperator(task_id='CDE11_M_N_RBSI_PAL_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_N_RBSI_PAL_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_N_RBSI_PAL_POLICY.py NWB CDE11_M_N_RBSI_PAL_POLICY CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE11_M_N_RBSI_PAL_LIMITS = BashOperator(task_id='CDE11_M_N_RBSI_PAL_LIMITS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE11_M_N_RBSI_PAL_LIMITS')+" "+cmd_part+"\" "+JOB_PATH+"CDE11_M_N_RBSI_PAL_LIMITS.py NWB CDE11_M_N_RBSI_PAL_LIMITS CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE07_M_N_RBSI_PAL_INPUT = BashOperator(task_id='CDE07_M_N_RBSI_PAL_INPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_N_RBSI_PAL_INPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_N_RBSI_PAL_INPUT.py NWB CDE07_M_N_RBSI_PAL_INPUT CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE07_M_N_RBSI_PAL_POLICY = BashOperator(task_id='CDE07_M_N_RBSI_PAL_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_N_RBSI_PAL_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_N_RBSI_PAL_POLICY.py NWB CDE07_M_N_RBSI_PAL_POLICY CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE07_M_N_RBSI_PAL_LIMITS = BashOperator(task_id='CDE07_M_N_RBSI_PAL_LIMITS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_N_RBSI_PAL_LIMITS')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_N_RBSI_PAL_LIMITS.py NWB CDE07_M_N_RBSI_PAL_LIMITS CDE11_M_N_RBSI_PAL_LIMITS_FLOW -y,", dag=dag)
CDE10_M_N_RBSI_POPULATION.set_downstream(CDE11_M_N_RBSI_PAL_BUSACC_AGGS)
CDE10_M_N_RBSI_POPULATION.set_downstream(CDE11_M_N_RBSI_PAL_DB_TRANS_AGG)
CDE10_M_N_RBSI_POPULATION.set_downstream(CDE11_M_N_RBSI_PAL_MAN_SHADLIM)
CDE11_M_N_RBSI_PAL_BUSACC_AGGS.set_downstream(CDE11_M_N_RBSI_PAL_BUREAU_AGGS)
CDE11_M_N_RBSI_PAL_BUREAU_AGGS.set_downstream(CDE11_M_N_RBSI_PAL_BUSAPPS_AGGS)
CDE11_M_N_RBSI_PAL_BUSAPPS_AGGS.set_downstream(CDE11_M_N_RBSI_PAL_INPUT)
CDE11_M_N_RBSI_PAL_DB_TRANS_AGG.set_downstream(CDE11_M_N_RBSI_PAL_INPUT)
CDE11_M_N_RBSI_PAL_MAN_SHADLIM.set_downstream(CDE11_M_N_RBSI_PAL_INPUT)
CDE11_M_N_RBSI_PAL_INPUT.set_downstream(CDE11_M_N_RBSI_PAL_POLICY)
CDE11_M_N_RBSI_PAL_POLICY.set_downstream(CDE11_M_N_RBSI_PAL_LIMITS)
CDE11_M_N_RBSI_PAL_LIMITS.set_downstream(CDE07_M_N_RBSI_PAL_INPUT)
CDE11_M_N_RBSI_PAL_LIMITS.set_downstream(CDE07_M_N_RBSI_PAL_POLICY)
CDE11_M_N_RBSI_PAL_LIMITS.set_downstream(CDE07_M_N_RBSI_PAL_LIMITS) 

dag_end_rbsi_pal_limits_flow= DummyOperator(task_id='END_CDE11_M_N_RBSI_PAL_LIMITS_FLOW',dag=dag,)
CDE07_M_N_RBSI_PAL_INPUT.set_downstream(dag_end_rbsi_pal_limits_flow)
CDE07_M_N_RBSI_PAL_POLICY.set_downstream(dag_end_rbsi_pal_limits_flow)		
CDE07_M_N_RBSI_PAL_LIMITS.set_downstream(dag_end_rbsi_pal_limits_flow)

#CDE09_M_N_ELI_FLOW
CDE09_M_X_ELI_PRBEXT_01 = BashOperator(task_id='CDE09_M_X_ELI_PRBEXT_01' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE09_M_X_ELI_PRBEXT_01')+" "+cmd_part+"\" "+JOB_PATH+"CDE09_M_X_ELI_PRBEXT_01.py NWB CDE09_M_X_ELI_PRBEXT_01 CDE09_M_N_ELI_FLOW -y,", dag=dag)
CDE09_M_X_ELI_PRBEXT_HISVAR_02 = BashOperator(task_id='CDE09_M_X_ELI_PRBEXT_HISVAR_02' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE09_M_X_ELI_PRBEXT_HISVAR_02')+" "+cmd_part+"\" "+JOB_PATH+"CDE09_M_X_ELI_PRBEXT_HISVAR_02.py NWB CDE09_M_X_ELI_PRBEXT_HISVAR_02 CDE09_M_N_ELI_FLOW -y,", dag=dag)
CDE07_M_X_ELI_OUTPUT = BashOperator(task_id='CDE07_M_X_ELI_OUTPUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_ELI_OUTPUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_ELI_OUTPUT.py NWB CDE07_M_X_ELI_OUTPUT CDE09_M_N_ELI_FLOW -y,", dag=dag)

CDE09_M_X_ELI_PRBEXT_01.set_downstream(CDE09_M_X_ELI_PRBEXT_HISVAR_02)
CDE09_M_X_ELI_PRBEXT_HISVAR_02.set_downstream(CDE07_M_X_ELI_OUTPUT)

START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE99_M_N_BUS_LOGIC_FLOW -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE99_M_N_BUS_LOGIC_FLOW -y,", dag=dag)    
#CDER-5685
DEPENDENCY_CHECK_M_N_PROBE_LOGIC= BashOperator(task_id='DEPENDENCY_CHECK_M_N_PROBE_LOGIC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_N_PROBE_LOGIC_POST_GURN_FLOW "+get_polling_time('CDE99_M_N_PROBE_LOGIC_POST_GURN_FLOW')+" -y,", dag=dag)

CDE04_M_X_RCM_LIMITS_MAP = BashOperator(task_id='CDE04_M_X_RCM_LIMITS_MAP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE04_M_X_RCM_LIMITS_MAP')+" "+cmd_part+"\" "+JOB_PATH+"CDE04_M_X_RCM_LIMITS_MAP.py NWB CDE04_M_X_RCM_LIMITS_MAP CDE99_M_N_BUS_LOGIC_FLOW -y,", dag=dag)
CDE07_M_X_SPEARMINT = BashOperator(task_id='CDE07_M_X_SPEARMINT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_X_SPEARMINT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_X_SPEARMINT.py NWB CDE07_M_X_SPEARMINT CDE99_M_N_BUS_LOGIC_FLOW -y,", dag=dag)
CDE09_M_X_SPEARMINT_EWI_RULES = BashOperator(task_id='CDE09_M_X_SPEARMINT_EWI_RULES' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE09_M_X_SPEARMINT_EWI_RULES')+" "+cmd_part+"\" "+JOB_PATH+"CDE09_M_X_SPEARMINT_EWI_RULES.py NWB CDE09_M_X_SPEARMINT_EWI_RULES CDE99_M_N_BUS_LOGIC_FLOW -y,", dag=dag)
CDE99_M_X_CREATE_TRIGGER_RCM_LIMITS = BashOperator(task_id='CDE99_M_X_CREATE_TRIGGER_RCM_LIMITS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE99_M_X_CREATE_TRIGGER_RCM_LIMITS')+" "+cmd_part+"\" "+JOB_PATH+"CDE99_M_X_CREATE_TRIGGER_RCM_LIMITS.py NWB CDE99_M_X_CREATE_TRIGGER_RCM_LIMITS CDE99_M_N_BUS_LOGIC_FLOW -y,", dag=dag)

# added for [master flow sourcing check]
SOURCING_CHECK= BashOperator(task_id='SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE99_M_N_BUS_LOGIC_FLOW -y,", dag=dag)

START.set_downstream(SOURCING_CHECK)
SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_M_N_PROBE_LOGIC)

NWB_CDE_TDECRLM_CREDIT_LIM = BashOperator(task_id='NWB_CDE_TDECRLM_CREDIT_LIM' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('NWB_CDE_TDECRLM_CREDIT_LIM')+" "+cmd_part+"\" "+JOB_PATH+"CDE_CORE_CREDIT_RCM_DOTDAT.py NWB CDE04_M_X_RCM_LIMITS_MAP CDE99_M_N_BUS_LOGIC_FLOW CDE04_M_RCM_LIMITS -y,", dag=dag)
NWB_CDE_TDECTCR_CTC_RSKBND = BashOperator(task_id='NWB_CDE_TDECTCR_CTC_RSKBND' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('NWB_CDE_TDECTCR_CTC_RSKBND')+" "+cmd_part+"\" "+JOB_PATH+"CDE_CORE_CREDIT_RCM_DOTDAT.py NWB CDE04_M_X_RCM_LIMITS_MAP CDE99_M_N_BUS_LOGIC_FLOW CDE04_M_BUS_RISK_BANDS_NEW -y,", dag=dag)
NWB_CDE_TDECONN_RISK_BAND = BashOperator(task_id='NWB_CDE_TDECONN_RISK_BAND' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('NWB_CDE_TDECONN_RISK_BAND')+" "+cmd_part+"\" "+JOB_PATH+"CDE_CORE_CREDIT_RCM_DOTDAT.py NWB CDE04_M_X_RCM_LIMITS_MAP CDE99_M_N_BUS_LOGIC_FLOW CDE04_M_BUS_RISK_BANDS_OLD -y,", dag=dag)

# START.set_downstream(DEPENDENCY_CHECK_M_N_PROBE_LOGIC)
DEPENDENCY_CHECK_M_N_PROBE_LOGIC.set_downstream(CDE10_M_X_BUS_RB_POPULATION)
CDE07_M_X_BUS_PRB_INPUT.set_downstream(CDE06_M_X_CUST_CUST_REL)
CDE07_M_X_BUS_PRB_INPUT.set_downstream(CDE11_M_X_BUS_PAL_BUSACC_AGGS)
dag_end_bus_pal_limits.set_downstream(CDE09_M_X_COMMERCIAL_POP)
dag_end_rbsi_pal_limits_flow.set_downstream(CDE04_M_X_RCM_LIMITS_MAP)
dag_end_bus_pal_limits.set_downstream(CDE09_M_X_SPEARMINT_EWI_RULES)
dag_end_bus_pal_limits.set_downstream(CDE10_M_N_RBSI_POPULATION)
CDE04_M_X_RCM_LIMITS_MAP.set_downstream(CDE99_M_X_CREATE_TRIGGER_RCM_LIMITS)
dag_end_risk_bands.set_downstream(CDE99_M_X_CREATE_TRIGGER_RCM_LIMITS)
dag_end_data_extract_flow.set_downstream(CDE04_M_X_PROBE_ACCT_POWERCR )
CDE04_M_X_PROBE_ACCT_POWERCR.set_downstream(CDE10_M_X_PERSONAL_RISK_BANDS)
CDE09_M_X_SPEARMINT_EWI_RULES.set_downstream(CDE07_M_X_SPEARMINT)
CDE04_M_X_RCM_LIMITS_MAP.set_downstream(NWB_CDE_TDECRLM_CREDIT_LIM)
CDE04_M_X_BUSINESS_RISK_BANDS.set_downstream(NWB_CDE_TDECTCR_CTC_RSKBND)
CDE04_M_X_BUSINESS_RISK_BANDS.set_downstream(NWB_CDE_TDECONN_RISK_BAND)
NWB_CDE_TDECRLM_CREDIT_LIM.set_downstream(END)
NWB_CDE_TDECTCR_CTC_RSKBND.set_downstream(END)
NWB_CDE_TDECONN_RISK_BAND.set_downstream(END)
CDE07_M_X_PERSONAL_RISK_BANDS.set_downstream(END)
CDE07_M_X_SPEARMINT.set_downstream(END)
CDE99_M_X_CREATE_TRIGGER_RCM_LIMITS.set_downstream(END)
#dag_end_rbsi_pal_limits_flow.set_downstream(END)
dag_end_bus_pal_limits.set_downstream(CDE09_M_X_ELI_PRBEXT_01)
CDE07_M_X_ELI_OUTPUT.set_downstream(END)


RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)