from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.hive_operator import HiveOperator
from airflow.utils.db import provide_session
from datetime import  date, datetime, time, timedelta
import airflow.settings
from airflow.models import DagModel
import boto3
import botocore.session 
import json
import yaml
#from smart_open import open



def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    #print('Path'+str(path))
    bucket = path[0]
    #print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    #print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': False, 
    'email_on_retry': False,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
dag_list_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/master_flows.csv"
dag_list_enable_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"

DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]

MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	

SCHEDULER_FILE = BASE_PATH+DAG_CONFIG_DICT["DAILY_SCHEDULER_SCRIPT"]
COPY_FILE = BASE_PATH+DAG_CONFIG_DICT["FILE_COPY_SCRIPT"]

SCHEDULER_OUTPUT_FILE =  BASE_PATH+DAG_CONFIG_DICT["SCHEDULER_OUTPUT_FILE"] 
SCHEDULER_OUTPUT_YAML_FILE = BASE_PATH+DAG_CONFIG_DICT["SCHEDULER_OUTPUT_YAML_FILE"]

COPY_FLOWS_ENV = "COPY_FLOWS_PATH_"+cde_env
COPY_FLOWS_PATH = DAG_CONFIG_DICT[COPY_FLOWS_ENV]
COPY_YAML_FILES_ENV = "COPY_YAML_FILES_PATH_"+cde_env
COPY_YAML_FILES_PATH = DAG_CONFIG_DICT[COPY_YAML_FILES_ENV]

file = open(MASTER_IP,"r")
IP = file.read()
file.close

 
with DAG('CDE_DAILY_SCHEDULE_GENERATOR', description='CDE_DAILY_SCHEDULE_GENERATOR', default_args=default_args, schedule_interval='30 20 * * 0-6', catchup=False, max_active_runs=1) as dag:    

    set_permission = BashOperator(task_id='SET_PERMISSION' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sudo chown -R hadoop:hadoop /home/hadoop/cde", dag=dag)	
    generate_schedule = BashOperator(task_id='GENERATE_SCHEDULE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sudo spark-submit "+SCHEDULER_FILE+" "+SCHEDULER_OUTPUT_FILE+" -y,", dag=dag)
    copy_files =  BashOperator(task_id='COPY_FILES' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " sh "+COPY_FILE+" "+SCHEDULER_OUTPUT_FILE+" "+COPY_FLOWS_PATH+" -y,", dag=dag)    
		
    set_permission.set_downstream(generate_schedule)	
    generate_schedule.set_downstream(copy_files)

    
