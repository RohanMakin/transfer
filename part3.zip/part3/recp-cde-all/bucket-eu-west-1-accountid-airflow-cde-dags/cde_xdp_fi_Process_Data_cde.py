from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from datetime import date, datetime, time, timedelta
from airflow.utils.decorators import apply_defaults
from os.path import join, abspath
import os
from airflow import DAG
from datetime import datetime, timedelta
#import settings as st
import glob
from datetime import date, datetime, time, timedelta
import random
import yaml
import boto3
import botocore
import airflow
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import BranchPythonOperator
import json
from botocore.session import Session
from airflow.utils.trigger_rule import TriggerRule
from airflow.utils.state import State
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from airflow import configuration as conf
from airflow.models import DagBag, TaskInstance
from botocore.exceptions import ClientError, ParamValidationError


with open('/usr/local/airflow/ssh/variables.json') as json_file:
    data = json.load(json_file) 
account_id = data['AccountId']
json_file.close()

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)


#config_file_loc='s3://bucket-eu-west-1-{}-user/data_support_cde/namit/config_file_loc/keep_alive_file.yaml'.format(account_id)
config_file_loc = 's3://bucket-eu-west-1-{}-risk-cicd/cde/dags/config/keep_alive_file.yaml'.format(account_id)

SPARK_ARGS = {
    'app': 'Framework',
    'parameter':'--driver-memory=3g --executor-memory=6g'
    }

START_DATE = datetime.now() - timedelta(minutes=10)
DAG_NAME = "XDP_FI_ProcessData_cde"

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
EMR_LOCAL_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
MASTER_IP_FILE = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]
CONCURRENCY_XDP_PROCESS_DATA = DAG_CONFIG_DICT["CONCURRENCY_XDP_PROCESS_DATA"]

MASTER_IP = open(MASTER_IP_FILE,"r").read()

STATIC_CONFIG = ''
AIRFLOW_CONFIG = ''
DAG_LOCAL_PATH = '/usr/local/airflow/dags/'
DYNAMIC_DAG_PATH = abspath(join(DAG_LOCAL_PATH, 'rsr_airflow_config.yaml'))

#utilpath = "{}/bin/".format(EMR_LOCAL_PATH)
#utilfile1 = '{}DQutility.py'.format(utilpath)
#utilfile2 = '{}utilities.py'.format(utilpath)
#dq_addn_arg = 'spark-submit {arg} --py-files {pyfile1},{pyfile2} '.format(arg=SPARK_ARGS['parameter'] ,pyfile1= utilfile1,pyfile2=utilfile2)

SSH_COMMAND = "ssh -o StrictHostKeyChecking=no -t -i {key} hadoop@{master_ip} ".format(key=KEY_FILE, master_ip=MASTER_IP)

SPARK_ARGUS = {
    'app': 'Framework',
    'argumentspark':'spark-submit -v --executor-memory=3g --executor-cores=2  --driver-memory=3g --conf spark.executor.memoryOverhead=300m  --conf spark.executor.cores=2 --conf spark.driver.memoryOverhead=300m --conf spark.dynamicAllocation.initialExecutors=2  --conf spark.dynamicAllocation.minExecutors=2   --conf  spark.executor.instances=2    --conf spark.dynamicAllocation.maxExecutors=5  --conf spark.default.parallelism=20  --conf spark.sql.shuffle.partitions=20  --conf spark.serializer=org.apache.spark.serializer.KryoSerializer --conf spark.sql.sources.commitProtocolClass=org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol'
    }


arg_spark1 = '{}'.format(str(SPARK_ARGUS['argumentspark']))

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'
SPARK_SUBMIT_COMMAND = SSH_COMMAND + "\"{arg_sparks} {cmd_part} {emr_lcl}\"".format(arg_sparks = arg_spark1, cmd_part = cmd_part, emr_lcl=EMR_LOCAL_PATH)





args = {
    'owner': 'jalotan',
    'depends_on_past': False,
    'email': ['namit.jalota@rbs.co.uk'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'queue': 'sqs-airflow-cde',
    'retry_delay': timedelta(minutes=1),
    'start_date': START_DATE,
    'end_date': datetime(2099,12,31),
}


dag = DAG(
    dag_id=DAG_NAME,
    default_args=args,
    catchup=False,
    schedule_interval=None,max_active_runs=1 ,
    concurrency = CONCURRENCY_XDP_PROCESS_DATA
)



def get_BucketNkey(input_loc):
    full_path = input_loc[5:]
    #print(full_path)
    bucket_name=full_path.split("/")[0]
    #print(bucket_name)
    full_path_list = full_path.split("/")
    key = ''
    len1 = len(full_path_list)
    k=1
    while k < len1 :
        #print(list_1[k])
        #print(k)
        key= key + "/" + full_path_list[k]
        k=k+1
    length = len(key)
    Key = key[1:length]
    myDict = {}
    myDict['bucket_name'] = Key
    return bucket_name,Key


def readFile(bucket_name,key) :
    session = Session()
    client = session.create_client('s3')
    #config_file_loc=app_config.config_file_loc
    #processing_dir="s3://bucket-eu-west-1-897144472116-wsl-risrmart-data/framework_test/Release2_Testing_Env/Testing_Processing_Zone/"
    #bucket_name,key=get_BucketNkey(config_file_loc)
    obj_dict = client.get_object(Bucket=bucket_name,Key=key)
    yaml_res= obj_dict['Body'].read().decode('utf-8')
    my_dict=yaml.safe_load(yaml_res)
    return my_dict


#first_task =  DummyOperator(task_id='Start_of_Flow',dag=dag)
FileProcessingStarts = DummyOperator(
    task_id='FileProcessingStarts',
    dag=dag,)

def conditionally_trigger(context, dag_run_obj):
    """This function decides whether or not to Trigger the remote DAG"""
    c_p = context['params']['condition_param']
    print("Controller DAG : conditionally_trigger = {}".format(c_p))
    if context['params']['condition_param']:
        dag_run_obj.payload = {'message': context['params']['message']}
        print(dag_run_obj.payload)
        return dag_run_obj
    return None


# Define the single task in this controller example DAG
trigger_op = TriggerDagRunOperator(
    task_id='Trigger_NextDag',
    trigger_dag_id="XDP_FI_PrepareFlow_cde",
    python_callable=conditionally_trigger,
    params={'condition_param': True, 'message': 'Trigger'},
    dag=dag,
)
    
def final_status(**kwargs):
    for task_instance in kwargs['dag_run'].get_task_instances():
        if task_instance.current_state() not in [State.SUCCESS,State.SKIPPED] and task_instance.task_id != kwargs['task_instance'].task_id:
            raise Exception("Task {} failed. Failing this DAG run".format(task_instance.task_id))

dag_final_status = BranchPythonOperator(
    task_id='dag_final_status',
    provide_context=True,
    python_callable=final_status,
    trigger_rule=TriggerRule.ALL_DONE, # Ensures this task runs even if upstream fails
    dag=dag,
)




def create_dag(yaml_dict):
    task_bag = {} # dictionary to keep track of all tasks
    pattern = yaml_dict['files']
    # Removal of file from Processing Zone
    bash_command_arch="{spark}batch-framework/mdf-sourcing/archive_file.py ".format(spark=SPARK_SUBMIT_COMMAND)
    task_id_arch = "Archive_Filesfrom_ProcessingZone"
    task_file_arch = BashOperator(task_id=task_id_arch,trigger_rule=TriggerRule.ALL_DONE,bash_command=bash_command_arch,dag=dag,)

    for p in pattern:
        param1=pattern[p]
        file_prefix = '{}'.format(param1['job_name'])
        arg_spark = '{}'.format(str(param1['argument']))
        file_name = '{}'.format(str(param1['file_name']))
        brand = '{}'.format(str(param1['brand']))
        brand_id = '{}'.format(str(param1['brand_id']))
        script_to_load_staging_layer = '{}'.format(str(param1['script_to_load_staging_layer']))
        script_to_load_process_layer = '{}'.format(str(param1['script_to_load_process_layer']))
        cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'
        spark_command = SSH_COMMAND + "\"{arg_sparks} {cmd_part} {emr_lcl}\"".format(arg_sparks = arg_spark, cmd_part = cmd_part, emr_lcl=EMR_LOCAL_PATH)

        #setting parameters for staging layer task
        bash_command_dth="""{spark}batch-framework/mdf-sourcing/{script_to_load_staging_layer} {file_prefix} {file_name} {brand} -y,""".format(spark=spark_command,script_to_load_staging_layer=script_to_load_staging_layer, file_prefix= file_prefix, file_name=file_name, brand=brand)
        task_id_dth = 'STAGING_LAYER_LOAD_{}'.format(param1['job_name'])
        task_dth = BashOperator(task_id=task_id_dth,bash_command=bash_command_dth,dag=dag,)
        task_dth.set_upstream(FileProcessingStarts)

        #setting parameters for process layer task
        bash_command_prcs="""{spark}batch-framework/mdf-sourcing/{script_to_load_process_layer} {file_prefix} {file_name} {brand} -y,""".format(spark=spark_command,script_to_load_process_layer=script_to_load_process_layer, file_prefix= file_prefix, file_name=file_name, brand=brand)
        task_id_prcs = 'PROCESS_LAYER_LOAD_{}'.format(param1['job_name'])
        task_prcs = BashOperator(task_id=task_id_prcs,bash_command=bash_command_prcs,dag=dag,)
        task_prcs.set_upstream(task_dth)

        #setting parameters for log task
        #bash_command_log="""{spark}scripts/airflow/sourcing_flow_status_end.py {file_prefix} -y,""".format(spark=spark_command,file_prefix= file_prefix)
        #task_id_log = 'LOG_STATUS_{}'.format(param1['job_name'])
        #task_log = BashOperator(task_id=task_id_log,bash_command=bash_command_log,dag=dag,)
        #task_log.set_upstream(task_prcs)

        #task_file_arch.set_upstream(task_log) 
        task_file_arch.set_upstream(task_prcs) 
        trigger_op.set_upstream(task_file_arch)  
        dag_final_status.set_upstream(trigger_op)


bucket_name,key=get_BucketNkey(config_file_loc)
my_dict=readFile(bucket_name,key)

create_dag(my_dict)
