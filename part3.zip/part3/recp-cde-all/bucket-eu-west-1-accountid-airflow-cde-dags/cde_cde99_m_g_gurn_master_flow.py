from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from datetime import date, datetime, time, timedelta
import os
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
from airflow.operators.subdag_operator import SubDagOperator
'''from cde_cde01_m_g_gurn_master_flow import child_dag_cde01_m_g_gurn_master_flow
from cde_cde09_m_g_ccard_cde_score_flow import child_dag_cde09_m_g_ccard_cde_score_flow'''
import boto3
import botocore.session 
import json
import yaml

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]
FLOW_DEPENDENCY = BASE_PATH+DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	
SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]
TACTICAL_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["TACTICAL_SOURCING_CHECK"]
file = open(MASTER_IP,"r")
IP = file.read()
file.close

# Dependency Code check 
def call_dagbag(*op_args):
    flow_name = op_args[0]
    print('Check DAG '+str(flow_name))
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    
    dag_bag_list = dagbag.dags[flow_name] #dagid     
    call_status_check(dag_bag_list) # last dag state
   

def call_status_check(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_state = last_instance.get_state() # last dag state
        print('\n Last Execution state'+str(dag_state))

        if(str(dag_state) == 'success') :
            print ('Dependency Met')    
        else :
            print ('Dependency Not Met')
            call_wait(dag_bag_list)     
  
def call_wait(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(9000)    # Sleep
    call_status_check(dag_bag_list)

def call_dagbag_subdag(*op_args):
    dag_name = op_args[0]
    print('Check DAG '+str(dag_name))	
    dag_name_arr = dag_name.split(".")
    master_dag = dag_name_arr[0]
    
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    

    master_dag_bag_list = dagbag.dags[master_dag] #dagid     
    check_dag_status(master_dag_bag_list,dag_name,dagbag) # last dag state 		

def call_status_check_subdag(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run

    if last_instance is not None :   
        dag_state = last_instance.get_state() # last dag state
        exec_date_str = last_instance.end_date
        execDate = exec_date_str.strftime("%Y-%m-%d")	
        print('\n Last Execution state of subFlow: '+str(dag_state)+" Execution Date: "+str(execDate))			
		
        now = datetime.now()		
        todayDate = now.strftime("%Y-%m-%d")		
        previous_date = now - timedelta(days=1)
        previousDay = previous_date.strftime("%Y-%m-%d")
				
        if(str(dag_state) == 'success') :
            if(execDate == previousDay or execDate == todayDate) :
                print ('Dependency Met')    
            else :
                call_wait_subdag(dag_bag_list)			
                print ('Dependency Not Met')	
            				
        else :
            print ('Dependency Not Met')
            call_wait_subdag(dag_bag_list)				
		
def check_dag_status(dag_bag_list,dag_name,dagbag) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_status = last_instance.get_state() # last dag state
        if(str(dag_status) == 'success') :
            print ('Dependency Met') 
        else  :	
            print('\n Dependent Master flow is either in Running state or Failed state')
            sub_dag_bag_list = dagbag.dags[dag_name] #dagid     
            call_status_check_subdag(sub_dag_bag_list)  

def call_wait_subdag(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(300)    # Sleep
    call_status_check_subdag(dag_bag_list)	
	
file = open("/usr/local/airflow/ssh/cde-emr-ip.txt","r")
IP = file.read()
file.close

flow_name="CDE99_M_G_GURN_MASTER_FLOW"
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name	
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key] 
    return str(polling_time)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val
	
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}

dag = DAG('CDE99_M_G_GURN_MASTER_FLOW' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
	
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)
	
'''subDag_cde01_m_g_gurn_master_flow = SubDagOperator(
subdag=child_dag_cde01_m_g_gurn_master_flow('CDE99_M_G_GURN_MASTER_FLOW', 'CDE01_M_G_GURN_MASTER_FLOW', default_args, dag.schedule_interval),
task_id='CDE01_M_G_GURN_MASTER_FLOW',
default_args=default_args,
dag=dag)

subDag_cde09_m_g_ccard_cde_score_flow = SubDagOperator(
subdag=child_dag_cde09_m_g_ccard_cde_score_flow('CDE99_M_G_GURN_MASTER_FLOW', 'CDE09_M_G_CCARD_CDE_SCORE_FLOW', default_args, dag.schedule_interval),
task_id='CDE09_M_G_CCARD_CDE_SCORE_FLOW',
default_args=default_args,
dag=dag)'''

#CDE01_M_G_GURN_MASTER_FLOW
CDE01_M_G_GURN_BUREAU = BashOperator(task_id='CDE01_M_G_GURN_BUREAU' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_GURN_BUREAU')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_GURN_BUREAU.py GRP CDE01_M_G_GURN_BUREAU CDE01_M_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE01_M_G_GURN_DERIVATIONS = BashOperator(task_id='CDE01_M_G_GURN_DERIVATIONS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_GURN_DERIVATIONS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_GURN_DERIVATIONS.py GRP CDE01_M_G_GURN_DERIVATIONS CDE01_M_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE01_M_G_GURN_MTA_BSCORE = BashOperator(task_id='CDE01_M_G_GURN_MTA_BSCORE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_GURN_MTA_BSCORE')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_GURN_MTA_BSCORE.py GRP CDE01_M_G_GURN_MTA_BSCORE CDE01_M_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE01_M_G_GURN_POLICY_TO_CIN = BashOperator(task_id='CDE01_M_G_GURN_POLICY_TO_CIN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_GURN_POLICY_TO_CIN')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_GURN_POLICY_TO_CIN.py GRP CDE01_M_G_GURN_POLICY_TO_CIN CDE01_M_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE01_M_G_GURN_POLICY = BashOperator(task_id='CDE01_M_G_GURN_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_GURN_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_GURN_POLICY.py GRP CDE01_M_G_GURN_POLICY CDE01_M_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE01_M_G_GURN_POPULATION = BashOperator(task_id='CDE01_M_G_GURN_POPULATION' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_GURN_POPULATION')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_GURN_POPULATION.py GRP CDE01_M_G_GURN_POPULATION CDE01_M_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE01_M_G_SEMI_BANKED_POP = BashOperator(task_id='CDE01_M_G_SEMI_BANKED_POP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_M_G_SEMI_BANKED_POP')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_M_G_SEMI_BANKED_POP.py GRP CDE01_M_G_SEMI_BANKED_POP CDE01_M_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE07_M_G_GURN_DERIVATIONS = BashOperator(task_id='CDE07_M_G_GURN_DERIVATIONS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_G_GURN_DERIVATIONS')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_G_GURN_DERIVATIONS.py GRP CDE07_M_G_GURN_DERIVATIONS CDE01_M_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE07_M_G_GURN_POLICY = BashOperator(task_id='CDE07_M_G_GURN_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_G_GURN_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_G_GURN_POLICY.py GRP CDE07_M_G_GURN_POLICY CDE01_M_G_GURN_MASTER_FLOW -y,", dag=dag)
dag_end_cde01_m_g_gurn_master_flow= DummyOperator(task_id='END_CDE01_M_G_GURN_MASTER_FLOW',dag=dag,)

##Trigger DAG for CMS scorecard [SDA]
TRIGGER_CMS_SCORECARD = TriggerDagRunOperator(task_id='TRIGGER_CMS_SCORECARD',
                                 trigger_dag_id='CDE01_M_G_SDA_CMS_FLOW',
                                 dag=dag)

CDE01_M_G_GURN_POPULATION.set_downstream(CDE01_M_G_GURN_BUREAU)
CDE01_M_G_GURN_BUREAU.set_downstream(CDE01_M_G_GURN_DERIVATIONS)
CDE01_M_G_GURN_MTA_BSCORE.set_downstream(CDE01_M_G_GURN_DERIVATIONS)

CDE01_M_G_GURN_POPULATION.set_downstream(CDE01_M_G_GURN_MTA_BSCORE)
CDE01_M_G_GURN_POLICY.set_downstream(CDE01_M_G_GURN_POLICY_TO_CIN)
CDE01_M_G_GURN_DERIVATIONS.set_downstream(CDE01_M_G_GURN_POLICY)	
CDE01_M_G_GURN_POPULATION.set_downstream(CDE01_M_G_SEMI_BANKED_POP)
CDE01_M_G_GURN_POLICY_TO_CIN.set_downstream(CDE07_M_G_GURN_DERIVATIONS)
CDE01_M_G_GURN_POLICY_TO_CIN.set_downstream(CDE07_M_G_GURN_POLICY)

CDE01_M_G_SEMI_BANKED_POP.set_downstream(dag_end_cde01_m_g_gurn_master_flow)
CDE07_M_G_GURN_DERIVATIONS.set_downstream(dag_end_cde01_m_g_gurn_master_flow)
CDE07_M_G_GURN_POLICY.set_downstream(dag_end_cde01_m_g_gurn_master_flow)



#CDE09_M_G_CCARD_CDE_SCORE_FLOW
CDE07_M_G_CCARD_CDE_SCORE = BashOperator(task_id='CDE07_M_G_CCARD_CDE_SCORE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_G_CCARD_CDE_SCORE')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_G_CCARD_CDE_SCORE.py GRP CDE07_M_G_CCARD_CDE_SCORE CDE09_M_G_CCARD_CDE_SCORE_FLOW -y,", dag=dag)
CDE09_M_G_CCARD_CDE_SCORE = BashOperator(task_id='CDE09_M_G_CCARD_CDE_SCORE' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE09_M_G_CCARD_CDE_SCORE')+" "+cmd_part+"\" "+JOB_PATH+"CDE09_M_G_CCARD_CDE_SCORE.py GRP CDE09_M_G_CCARD_CDE_SCORE CDE09_M_G_CCARD_CDE_SCORE_FLOW -y,", dag=dag)
CDE09_M_G_CCARD_LIMIT_STRAT = BashOperator(task_id='CDE09_M_G_CCARD_LIMIT_STRAT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE09_M_G_CCARD_LIMIT_STRAT')+" "+cmd_part+"\" "+JOB_PATH+"CDE09_M_G_CCARD_LIMIT_STRAT.py GRP CDE09_M_G_CCARD_LIMIT_STRAT CDE09_M_G_CCARD_CDE_SCORE_FLOW -y,", dag=dag)
CDE07_M_G_CCARD_LIMIT_STRAT_OUT = BashOperator(task_id='CDE07_M_G_CCARD_LIMIT_STRAT_OUT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_G_CCARD_LIMIT_STRAT_OUT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_G_CCARD_LIMIT_STRAT_OUT.py GRP CDE07_M_G_CCARD_LIMIT_STRAT_OUT CDE09_M_G_CCARD_CDE_SCORE_FLOW -y,", dag=dag)
CDE09_M_G_CCARD_EXCP_REP = BashOperator(task_id='CDE09_M_G_CCARD_EXCP_REP' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE09_M_G_CCARD_EXCP_REP')+" "+cmd_part+"\" "+JOB_PATH+"CDE09_M_G_CCARD_EXCP_REP.py GRP CDE09_M_G_CCARD_EXCP_REP CDE09_M_G_CCARD_CDE_SCORE_FLOW -y,", dag=dag)
CDE07_M_G_CCARD_EXCEPT = BashOperator(task_id='CDE07_M_G_CCARD_EXCEPT' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE07_M_G_CCARD_EXCEPT')+" "+cmd_part+"\" "+JOB_PATH+"CDE07_M_G_CCARD_EXCEPT.py GRP CDE07_M_G_CCARD_EXCEPT CDE09_M_G_CCARD_CDE_SCORE_FLOW -y,", dag=dag)

dag_start_ccard_cde_score_flow= DummyOperator(task_id='START_CDE09_M_G_CCARD_CDE_SCORE_FLOW',dag=dag,)
dag_end_ccard_cde_score_flow= DummyOperator(task_id='END_CDE09_M_G_CCARD_CDE_SCORE_FLOW',dag=dag,)

dag_start_ccard_cde_score_flow.set_downstream(CDE09_M_G_CCARD_CDE_SCORE)
dag_start_ccard_cde_score_flow.set_downstream(CDE09_M_G_CCARD_EXCP_REP)

CDE09_M_G_CCARD_CDE_SCORE.set_downstream(CDE09_M_G_CCARD_LIMIT_STRAT)
CDE09_M_G_CCARD_CDE_SCORE.set_downstream(CDE07_M_G_CCARD_CDE_SCORE)
CDE09_M_G_CCARD_LIMIT_STRAT.set_downstream(CDE07_M_G_CCARD_LIMIT_STRAT_OUT)
CDE09_M_G_CCARD_EXCP_REP.set_downstream(CDE07_M_G_CCARD_EXCEPT)

CDE07_M_G_CCARD_CDE_SCORE.set_downstream(dag_end_ccard_cde_score_flow)
CDE07_M_G_CCARD_LIMIT_STRAT_OUT.set_downstream(dag_end_ccard_cde_score_flow)
CDE07_M_G_CCARD_EXCEPT.set_downstream(dag_end_ccard_cde_score_flow)
#CDE01_D_G_GURN_MASTER_FLOW
#CDE01_D_G_APPLICATIONS = BashOperator(task_id='CDE01_D_G_APPLICATIONS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_APPLICATIONS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_APPLICATIONS.py GRP CDE01_D_G_APPLICATIONSCDE01_D_G_GURN_MASTER_FLOW -y,", dag=dag)
#CDE01_D_G_CAUST_ACCS_BALS = BashOperator(task_id='CDE01_D_G_CAUST_ACCS_BALS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_CAUST_ACCS_BALS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_CAUST_ACCS_BALS.py GRP CDE01_D_G_GURN_MASTER_FLOW -y,", dag=dag)
#CDE01_D_G_CCARDS_ACCS_BALS = BashOperator(task_id='CDE01_D_G_CCARDS_ACCS_BALS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_CCARDS_ACCS_BALS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_CCARDS_ACCS_BALS.py GRP CDE01_D_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE01_D_G_GURN_DERIVATIONS = BashOperator(task_id='CDE01_D_G_GURN_DERIVATIONS' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_GURN_DERIVATIONS')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_GURN_DERIVATIONS.py GRP CDE01_D_G_GURN_DERIVATIONS CDE01_D_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE01_D_G_GURN_POLICY_TO_CIN = BashOperator(task_id='CDE01_D_G_GURN_POLICY_TO_CIN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_GURN_POLICY_TO_CIN')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_GURN_POLICY_TO_CIN.py GRP CDE01_D_G_GURN_POLICY_TO_CIN CDE01_D_G_GURN_MASTER_FLOW -y,", dag=dag)
CDE01_D_G_GURN_POLICY = BashOperator(task_id='CDE01_D_G_GURN_POLICY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE01_D_G_GURN_POLICY')+" "+cmd_part+"\" "+JOB_PATH+"CDE01_D_G_GURN_POLICY.py GRP CDE01_D_G_GURN_POLICY CDE01_D_G_GURN_MASTER_FLOW -y,", dag=dag)

#CDE01_D_G_APPLICATIONS.set_downstream(CDE01_D_G_CAUST_ACCS_BALS)
#CDE01_D_G_APPLICATIONS.set_downstream(CDE01_D_G_CCARDS_ACCS_BALS)
#CDE01_D_G_CAUST_ACCS_BALS.set_downstream(CDE01_D_G_GURN_DERIVATIONS)
#CDE01_D_G_CCARDS_ACCS_BALS.set_downstream(CDE01_D_G_GURN_DERIVATIONS)
CDE01_D_G_GURN_POLICY_TO_CIN.set_downstream(CDE01_M_G_GURN_DERIVATIONS)
CDE01_D_G_GURN_POLICY.set_downstream(CDE01_D_G_GURN_POLICY_TO_CIN)
CDE01_D_G_GURN_DERIVATIONS.set_downstream(CDE01_D_G_GURN_POLICY)

CDE01_M_G_GURN_POPULATION.set_downstream(CDE01_D_G_GURN_DERIVATIONS)

START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE99_M_G_GURN_MASTER_FLOW -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE99_M_G_GURN_MASTER_FLOW -y,", dag=dag)

#CDER-5685
DEPENDENCY_CHECK_D_G_GURN_MASTER= BashOperator(task_id='DEPENDENCY_CHECK_D_G_GURN_MASTER' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_D_G_GURN_MASTER_FLOW "+get_polling_time('CDE99_D_G_GURN_MASTER_FLOW')+" -y,", dag=dag)
DEPENDENCY_M_R_PROBE_LOGIC_PRE_GURN= BashOperator(task_id='DEPENDENCY_M_R_PROBE_LOGIC_PRE_GURN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_R_PROBE_LOGIC_PRE_GURN_FLOW "+get_polling_time('CDE99_M_R_PROBE_LOGIC_PRE_GURN_FLOW')+" -y,", dag=dag)
DEPENDENCY_M_N_PROBE_LOGIC_PRE_GURN= BashOperator(task_id='DEPENDENCY_M_N_PROBE_LOGIC_PRE_GURN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_N_PROBE_LOGIC_PRE_GURN_FLOW "+get_polling_time('CDE99_M_N_PROBE_LOGIC_PRE_GURN_FLOW')+" -y,", dag=dag)
DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN= BashOperator(task_id='DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_J_PROBE_LOGIC_PRE_GURN_FLOW "+get_polling_time('CDE99_M_J_PROBE_LOGIC_PRE_GURN_FLOW')+" -y,", dag=dag)
DEPENDENCY_M_K_PROBE_LOGIC_PRE_GURN= BashOperator(task_id='DEPENDENCY_M_K_PROBE_LOGIC_PRE_GURN' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP +" python3  "+FLOW_DEPENDENCY+" CDE99_M_K_PROBE_LOGIC_PRE_GURN_FLOW "+get_polling_time('CDE99_M_K_PROBE_LOGIC_PRE_GURN_FLOW')+" -y,", dag=dag)

# added for [master flow tactical check] CDER-5651
TACTICAL_SOURCING_CHECK= BashOperator(task_id='TACTICAL_SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('TACTICAL_SOURCING_CHECK')+" "+cmd_part+"\" "+TACTICAL_CHECK_PATH + " CDE99_M_G_GURN_MASTER_FLOW -y,", dag=dag)

ALL_SOURCING_DONE = DummyOperator(
    task_id='ALL_SOURCING_DONE',
    dag=dag,)

# CDER 5651
ALL_SOURCING_DONE.set_downstream(DEPENDENCY_CHECK_D_G_GURN_MASTER)
ALL_SOURCING_DONE.set_downstream(DEPENDENCY_M_R_PROBE_LOGIC_PRE_GURN)
ALL_SOURCING_DONE.set_downstream(DEPENDENCY_M_N_PROBE_LOGIC_PRE_GURN)
ALL_SOURCING_DONE.set_downstream(DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN)
ALL_SOURCING_DONE.set_downstream(DEPENDENCY_M_K_PROBE_LOGIC_PRE_GURN)

TACTICAL_SOURCING_CHECK.set_downstream(ALL_SOURCING_DONE)


# added for [master flow sourcing check]
SOURCING_CHECK= BashOperator(task_id='SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE99_M_G_GURN_MASTER_FLOW -y,", dag=dag)
SOURCING_CHECK.set_downstream(ALL_SOURCING_DONE)
# CDER 5651
#SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_D_G_GURN_MASTER)
#SOURCING_CHECK.set_downstream(DEPENDENCY_M_R_PROBE_LOGIC_PRE_GURN)
#SOURCING_CHECK.set_downstream(DEPENDENCY_M_N_PROBE_LOGIC_PRE_GURN)
#SOURCING_CHECK.set_downstream(DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN)
#SOURCING_CHECK.set_downstream(DEPENDENCY_M_K_PROBE_LOGIC_PRE_GURN)

#START.set_downstream(DEPENDENCY_CHECK_D_G_GURN_MASTER)
#START.set_downstream(DEPENDENCY_M_R_PROBE_LOGIC_PRE_GURN)
#START.set_downstream(DEPENDENCY_M_N_PROBE_LOGIC_PRE_GURN)
#START.set_downstream(DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN)
#START.set_downstream(DEPENDENCY_M_K_PROBE_LOGIC_PRE_GURN)
#DEPENDENCY_CHECK_D_G_GURN_MASTER.set_downstream(CDE01_M_G_GURN_POPULATION)
#DEPENDENCY_M_R_PROBE_LOGIC_PRE_GURN.set_downstream(CDE01_M_G_GURN_POPULATION)
#DEPENDENCY_M_N_PROBE_LOGIC_PRE_GURN.set_downstream(CDE01_M_G_GURN_POPULATION)
#DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN.set_downstream(CDE01_M_G_GURN_POPULATION)
#DEPENDENCY_M_K_PROBE_LOGIC_PRE_GURN.set_downstream(CDE01_M_G_GURN_POPULATION)

DEPENDENCY_CHECK_D_G_GURN_MASTER.set_downstream(TRIGGER_CMS_SCORECARD)
DEPENDENCY_M_R_PROBE_LOGIC_PRE_GURN.set_downstream(TRIGGER_CMS_SCORECARD)
DEPENDENCY_M_N_PROBE_LOGIC_PRE_GURN.set_downstream(TRIGGER_CMS_SCORECARD)
DEPENDENCY_M_J_PROBE_LOGIC_PRE_GURN.set_downstream(TRIGGER_CMS_SCORECARD)
DEPENDENCY_M_K_PROBE_LOGIC_PRE_GURN.set_downstream(TRIGGER_CMS_SCORECARD)

TRIGGER_CMS_SCORECARD.set_downstream(CDE01_M_G_GURN_POPULATION)

dag_end_cde01_m_g_gurn_master_flow.set_downstream(dag_start_ccard_cde_score_flow)
dag_end_ccard_cde_score_flow.set_downstream(END)

START.set_downstream(SOURCING_CHECK)
# CDER -5651
START.set_downstream(TACTICAL_SOURCING_CHECK)

RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)