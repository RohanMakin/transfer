from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from datetime import date, datetime, time, timedelta
from airflow.utils.decorators import apply_defaults
from os.path import join, abspath
import os
from airflow import DAG
# from airflow.operators import SimpleHttpOperator, HttpSensor,   BashOperator, EmailOperator, S3KeySensor
from datetime import datetime, timedelta
#import settings as st
import glob
from datetime import date, datetime, time, timedelta
import random
import yaml
import botocore
import airflow
from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import BranchPythonOperator
import json
from botocore.session import Session
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow import configuration as conf
from airflow.models import DagBag, TaskInstance
from botocore.exceptions import ClientError, ParamValidationError
from airflow.utils.state import State
from airflow.utils.trigger_rule import TriggerRule


#START_DATE = datetime.now() - timedelta(minutes=10)
START_DATE = datetime(2019, 10, 12, hour=10,minute=30)

args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'queue': 'sqs-airflow-cde',
    'retry_delay': timedelta(minutes=1),
    'start_date': START_DATE,
    'end_date': datetime(2099,12,31),
    'concurrency' : 1,
}



with open('/usr/local/airflow/ssh/variables.json') as json_file:
    data = json.load(json_file) 
account_id = data['AccountId']
json_file.close()

DAG_NAME = "XDP_FI_FileArrivalNAction_cde"

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')

def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """
    if not path.startswith('s3://'):
        raise ValueError('Given path is not a proper s3 path please check again: ' + path)
    path = path[5:].split('/')
    bucket = path[0]
    key = '/'.join(path[1:])
    return bucket, key

def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
EMR_LOCAL_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
MASTER_IP_FILE = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]

dag = DAG(
    dag_id=DAG_NAME,
    default_args=args,
    catchup=False,
    max_active_runs=1 ,
    schedule_interval= DAG_CONFIG_DICT["FILE_ARRIVAL_DAG_SCHEDULE"]
)

MASTER_IP = open(MASTER_IP_FILE,"r").read()
STATIC_CONFIG = ''
AIRFLOW_CONFIG = ''



DAG_LOCAL_PATH = '/usr/local/airflow/dags/'

SSH_COMMAND = "ssh -o StrictHostKeyChecking=no -t -i {key} hadoop@{master_ip} ".format(key=KEY_FILE, master_ip=MASTER_IP)
SPARK_ARGS = {
    'app': 'Framework',
    'argument':'spark-submit -v --executor-memory=6g --executor-cores=2  --driver-memory=3g --conf spark.executor.memoryOverhead=300m  --conf spark.executor.cores=2 --conf spark.driver.memoryOverhead=300m --conf spark.dynamicAllocation.initialExecutors=2  --conf spark.dynamicAllocation.minExecutors=2   --conf  spark.executor.instances=2    --conf spark.dynamicAllocation.maxExecutors=5  --conf spark.default.parallelism=20  --conf spark.sql.shuffle.partitions=20  --conf spark.serializer=org.apache.spark.serializer.KryoSerializer'
    }


arg_spark = '{}'.format(str(SPARK_ARGS['argument']))

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'
SPARK_SUBMIT_COMMAND = SSH_COMMAND + "\"{arg_sparks} {cmd_part} {emr_lcl}\"".format(arg_sparks = arg_spark, cmd_part = cmd_part, emr_lcl=EMR_LOCAL_PATH)
SHELL_COMMAND = SSH_COMMAND + "sudo sh {emr_lcl}".format(emr_lcl=EMR_LOCAL_PATH)
#first_task =  dag start  


dag_start_op_0 = DummyOperator(
    task_id='START',
    dag=dag,)


file_action = BashOperator(task_id='File_Arrival_and_Action',
    bash_command="""{shell}batch-framework/mdf-sourcing/file_arrival_and_action.sh {emr_lcl}batch-framework/mdf-sourcing""".format(shell=SHELL_COMMAND, emr_lcl=EMR_LOCAL_PATH),
    dag=dag, trigger_rule='all_success')

dag_stop_op_0 = DummyOperator(
    task_id='END',
    dag=dag,
    trigger_rule='all_success')


dag_start_op_0 >> file_action >> dag_stop_op_0