from airflow import DAG, utils
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from datetime import date, datetime, time, timedelta
import os
import sys
import airflow.settings
from airflow.models import DagModel
from airflow.configuration import conf 
from airflow.models import DagBag, TaskInstance 
from time import sleep
import boto3
import botocore.session 
import json
import yaml

def get_session():
    """
    Get a AWS Session object
    """
    return botocore.session.get_session()

def get_s3_client():
    """
    Get AWS S3 session client object
    """
    return get_session().create_client('s3')
	
def path_to_bucket_key(path):
    """
    Split a filename or path to bucket and key format
    """

    path = path[5:].split('/')
    print('Path'+str(path))
    bucket = path[0]
    print('bucket'+str(bucket))
    key = '/'.join(path[1:])
    print('key'+str(key))
    return bucket, key
	
def read_s3_file(filepath, encoding='utf8'):
    """
    Read the S3 bucket file and return data as string
    """
    client = get_s3_client()
    bucket, key = path_to_bucket_key(filepath)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read().decode(encoding)

SSH_CMD="ssh -o StrictHostKeyChecking=no -t -i"

with open('/usr/local/airflow/ssh/variables.json') as json_file:
	data = json.load(json_file)
account_id = data['AccountId']
json_file.close()

dag_config_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/cde_dag_job_config.yaml"
schedule_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flows_config.yaml"
DAG_CONFIG_FILE = read_s3_file(dag_config_yaml_path)
DAG_CONFIG_DICT = yaml.safe_load(DAG_CONFIG_FILE)
cde_env = DAG_CONFIG_DICT["CDE_ENV"]
BASE_PATH_ENV = "BASE_PATH_"+cde_env
BASE_PATH = DAG_CONFIG_DICT[BASE_PATH_ENV]
LOG_START_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_START"]
LOG_END_PATH = BASE_PATH+DAG_CONFIG_DICT["LOG_STATUS_END"]
JOB_PATH = BASE_PATH+DAG_CONFIG_DICT["JOB_PATH"]
FLOW_DEPENDENCY = BASE_PATH+DAG_CONFIG_DICT["FLOW_DEPENDENCY"]
MASTER_IP = DAG_CONFIG_DICT["MASTER_IP"]
KEY_FILE = DAG_CONFIG_DICT["KEY_FILE"]	
SOURCING_CHECK_PATH=BASE_PATH+DAG_CONFIG_DICT["FLOW_SOURCING_CHECK"]

file = open(MASTER_IP,"r")
IP = file.read()
file.close

# Dependency Code check 
def call_dagbag(*op_args):
    flow_name = op_args[0]
    print('Check DAG '+str(flow_name))
    dag_folder = conf.get('core','DAGS_FOLDER')    
    dagbag = DagBag(dag_folder)    
    dag_bag_list = dagbag.dags[flow_name] #dagid     
    call_status_check(dag_bag_list) # last dag state
   

def call_status_check(dag_bag_list) :
    last_instance = dag_bag_list.get_last_dagrun(include_externally_triggered=True) #last dag run
    if last_instance is not None :        
        dag_state = last_instance.get_state() # last dag state
        print('\n Last Execution state'+str(dag_state))

        if(str(dag_state) == 'success') :
            print ('Dependency Met')    
        else :
            print ('Dependency Not Met')
            call_wait(dag_bag_list)  
  
def call_wait(dag_bag_list) :
    print('Waiting - Dependency Check')
    sleep(300)    # Sleep
    call_status_check(dag_bag_list)
	
flow_name="CDE06_D_N_PAL_P1_Day0_Extract"
SCHEDULE_CONFIG_FILE = read_s3_file(schedule_yaml_path)
SCHEDULE_CONFIG_DICT = yaml.safe_load(SCHEDULE_CONFIG_FILE)
schedule_str = "SCHEDULE_"+flow_name
SCHEDULE_INT = SCHEDULE_CONFIG_DICT[schedule_str]

cmd_part =  '--conf spark.executor.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"  --conf spark.driver.extraJavaOptions=\\"-XX:+UseG1GC -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError=\'kill -9 %p\' \\"'	
job_sizing_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/spark_job_sizing.yaml"
JOB_SIZE_MAPPING = read_s3_file(job_sizing_yaml_path)
JOB_SIZE_MAPPING_DICT = yaml.safe_load(JOB_SIZE_MAPPING)

polling_time_yaml_path = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/dependency_polling_time.yaml"
POLLING_TIME_MAPPING = read_s3_file(polling_time_yaml_path)
POLLING_TIME_MAPPING_DICT = yaml.safe_load(POLLING_TIME_MAPPING)

def get_polling_time(dependent_flow_name):
    polling_dict_key = flow_name+"."+dependent_flow_name    
    polling_time = POLLING_TIME_MAPPING_DICT[polling_dict_key]     
    return str(polling_time)
	
def get_spark_param_job(job_name):
    dict_key = flow_name+"."+job_name    
    job_size = JOB_SIZE_MAPPING_DICT[dict_key]    	
    spark_config_str = "SPARK_CONFIG_PARAM_"+job_size
    spark_config_param = DAG_CONFIG_DICT[spark_config_str]    	
    return spark_config_param

check_dag_file = "s3://bucket-eu-west-1-"+account_id+"-risk-cicd/cde/dags/config/flow_list_enable.csv"
def run_check_fun(**kwargs):
    return_val = 'STOP'	
    dagList = read_s3_file(check_dag_file)
    print(str(dagList))
    lines = dagList.split('\n')
    for x in lines:
        st = x.strip()
        dagItem = str(st)
        print(dagItem)
        if dagItem == flow_name:
            print("\n DAG scheduled for today")
            return_val = 'START'    
    return return_val
	
default_args = {
    'owner': 'CDER',
    'depends_on_past': False,
    'email': ['#CDEReplatforming@rbos.co.uk'],
    'email_on_failure': True, 
    'email_on_retry': True,
    'queue': 'sqs-airflow-cde',
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2019,11,1),
    'end_date': datetime(2099,12,31),
}
dag = DAG('CDE06_D_N_PAL_P1_Day0_Extract' , default_args=default_args, schedule_interval=SCHEDULE_INT, catchup=False, max_active_runs=1)

RUN_CHECK =  BranchPythonOperator(task_id='RUN_CHECK',python_callable=run_check_fun,dag = dag,provide_context=True)
	
STOP = DummyOperator(
    task_id='STOP',
    dag=dag,)
	
START= BashOperator(task_id='START' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+LOG_START_PATH+" CDE06_D_N_PAL_P1_Day0_Extract -y,", dag=dag)
END= BashOperator(task_id='END' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('END')+" "+cmd_part+"\" "+LOG_END_PATH+" CDE06_D_N_PAL_P1_Day0_Extract -y,", dag=dag)
CDE06_D_X_KYCDATA = BashOperator(task_id='CDE06_D_X_KYCDATA' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE06_D_X_KYCDATA')+" "+cmd_part+"\" "+JOB_PATH+"CDE06_D_X_KYCDATA.py NWB CDE06_D_X_KYCDATA CDE06_D_N_PAL_P1_Day0_Extract -y,", dag=dag)
#CDE99_D_X_NOTIFY = BashOperator(task_id='CDE99_D_X_NOTIFY' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('CDE99_D_X_NOTIFY')+" "+cmd_part+"\" "+JOB_PATH+"CDE99_D_X_NOTIFY.py NWB CDE99_D_X_NOTIFY CDE06_D_N_PAL_P1_Day0_Extract -y,", dag=dag)
#DEPENDENCY_CHECK_M_N_PROBE_LOGIC  = PythonOperator(task_id='DEPENDENCY_CHECK_M_N_PROBE_LOGIC', python_callable=call_dagbag, op_args =['CDE99_M_N_PROBE_LOGIC_POST_GURN_FLOW'], trigger_rule="all_success", dag=dag)
#DEPENDENCY_CHECK_M_N_PAL_P1_LOGIC  = PythonOperator(task_id='DEPENDENCY_CHECK_M_N_PAL_P1_LOGIC', python_callable=call_dagbag, op_args =['CDE99_M_N_PAL_P1_LOGIC_FLOW'], trigger_rule="all_success", dag=dag)

#DEPENDENCY_CHECK_M_N_PROBE_LOGIC= BashOperator(task_id='DEPENDENCY_CHECK_M_N_PROBE_LOGIC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+FLOW_DEPENDENCY+" CDE99_M_N_PROBE_LOGIC_POST_GURN_FLOW "+get_polling_time('CDE99_M_N_PROBE_LOGIC_POST_GURN_FLOW')+" -y,", dag=dag)
#DEPENDENCY_CHECK_M_N_PAL_P1_LOGIC= BashOperator(task_id='DEPENDENCY_CHECK_M_N_PAL_P1_LOGIC' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + " \"spark-submit "+get_spark_param_job('START')+" "+cmd_part+"\" "+FLOW_DEPENDENCY+" CDE99_M_N_PAL_P1_LOGIC_FLOW "+get_polling_time('CDE99_M_N_PAL_P1_LOGIC_FLOW')+" -y,", dag=dag)

# added for [master flow sourcing check]
SOURCING_CHECK= BashOperator(task_id='SOURCING_CHECK' , bash_command=SSH_CMD+" "+KEY_FILE+" hadoop@" + IP + "  python3 "+SOURCING_CHECK_PATH + " CDE06_D_N_PAL_P1_Day0_Extract -y,", dag=dag)
START.set_downstream(SOURCING_CHECK)
#SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_M_N_PROBE_LOGIC)
#SOURCING_CHECK.set_downstream(DEPENDENCY_CHECK_M_N_PAL_P1_LOGIC)
SOURCING_CHECK.set_downstream(CDE06_D_X_KYCDATA)

# START.set_downstream(DEPENDENCY_CHECK_M_N_PROBE_LOGIC)
# START.set_downstream(DEPENDENCY_CHECK_M_N_PAL_P1_LOGIC)
#DEPENDENCY_CHECK_M_N_PROBE_LOGIC.set_downstream(CDE06_D_X_KYCDATA)
#DEPENDENCY_CHECK_M_N_PAL_P1_LOGIC.set_downstream(CDE06_D_X_KYCDATA)
#CDE06_D_X_KYCDATA.set_downstream(CDE99_D_X_NOTIFY)
CDE06_D_X_KYCDATA.set_downstream(END)
#CDE99_D_X_NOTIFY.set_downstream(END)

RUN_CHECK.set_downstream(START)
RUN_CHECK.set_downstream(STOP)